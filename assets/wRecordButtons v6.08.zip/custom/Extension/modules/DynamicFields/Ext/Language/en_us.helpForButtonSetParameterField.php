<?php
$mod_strings['LBL_POPHELP_PARAMETER'] = "<p>Record Type if Action given is Create Record</p>";
