<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

SugarAutoLoader::requireWithCustom('modules/ExpressionEngine/formulaHelper.php');

function get_body(&$ss, $vardef)
{
    global $dictionary, $db, $current_language, $sugar_config;
    $conn = $db->getConnection();

    $vars              = $ss->get_template_vars();
    $fields            = $vars['module']->mbvardefs->vardefs['fields'];
    $buttons           = '{"buttonsSettings": {}, "buttons": {}}';
    $fieldOptions      = array();
    $correctModuleName = $vars['module']->key_name ? $vars['module']->key_name : $vars['module']->name;
    $seed              = BeanFactory::getBean($correctModuleName);
    $fieldsData        = array();

    if ($seed) {
        $formulaHelperClass = SugarAutoLoader::customClass("FormulaHelper");

        if ($formulaHelperClass === "CustomFormulaHelper") {
            $fieldsData[$correctModuleName] = CustomFormulaHelper::cleanFields($seed->field_defs);
        } else {
            $fieldsData[$correctModuleName] = FormulaHelper::cleanFields($seed->field_defs);
        }

        $objectName    = BeanFactory::getObjectName($correctModuleName);
        $functionsDesc = array();

        // get the description of all used functions
        require_once sugar_cached('Expressions/functionmap.php');

        if (is_array($FUNCTION_MAP) || $FUNCTION_MAP instanceof Traversable) {
            foreach ($FUNCTION_MAP as $functionName => $functionData) {
                $func_def = $functionData;
                $funcPath = $func_def['src'];

                require_once 'include/upload_file.php';

                $uploadFile = new UploadFile();
                //get the file location
                $uploadFile->temp_file_location = $funcPath;
                // get contents within the file
                $doc         = $uploadFile->get_file_contents();
                $docComments = array();
                $allTokens   = token_get_all($doc);

                foreach ($allTokens as $tokenKey => $tokenValue) {
                    if ($tokenValue[0] == T_DOC_COMMENT) {
                        array_push($docComments, $tokenValue);
                    }
                }

                $fileDocComment = array_shift($docComments);

                if (!empty($fileDocComment[1])) {
                    // replace all of the new lines and unneeded chars
                    $functionDescription = preg_replace("/((\/\*+)|(\*+\/)|(\n\s*\*)[^\/])/", "", $fileDocComment[1]);
                    $functionDescription = str_replace("\n", ' ', str_replace('"', '', $functionDescription));

                    if (strpos($functionDescription, '<b>') !== false) {
                        $functionsDesc[$functionName] = str_replace("\r", ' ', $functionDescription);
                    }
                }
            }
        }

        // get all the options of the field
        foreach ($dictionary[$objectName]['fields'] as $id => $def) {
            $isValidField = false;

            if (isset($def['studio'])) {
                if (is_array($def['studio'])) {
                    if (isset($def['studio']['editField']) && $def['studio']['editField'] == true) {
                        $isValidField = true;
                    }

                    if (isset($def['studio']['required']) && $def['studio']['required']) {
                        $isValidField = true;
                    }
                } else {
                    if ($def['studio'] == 'visible') {
                        $isValidField = true;
                    }

                    if ($def['studio'] == 'hidden' || $def['studio'] == 'false' || !$def['studio']) {
                        $isValidField = false;
                    }
                }
            }

            if (empty($def['source']) || $def['source'] == 'db' || $def['source'] == 'custom_fields') {
                if (strtolower($def['type']) != 'id' && (empty($def['dbType']) || $def['dbType'] != 'id')) {
                    $isValidField = true;
                }
            }

            if ($isValidField === true) {
                $fieldOptions[$id] = translate($def['vname'], $correctModuleName);
            }
        }

        $fieldOptions = json_encode($fieldOptions);

        // get previous saved data
        if (isset($fields[$vardef['name']]['options']) && ($fields[$vardef['name']]['options'] != "")) {
            $buttons = $fields[$vardef['name']]['options'];
        }

        $controller     = new TabController();
        $tabs           = $controller->get_tabs_system();
        $modules        = $tabs[0];
        $hidden_modules = $tabs[1];

        unset($modules['Home']);
        unset($modules['Calendar']);
        unset($modules['Forecasts']);

        $rmodules = array();
        $rfields  = array();
        $links    = FormulaHelper::getLinksForModule($correctModuleName, "");

        if ($hasCustomFormulaHelper) {
            $links = CustomFormulaHelper::getLinksForModule($correctModuleName, "");
        }

        // get the modules
        foreach ($links as $lname => $link) {
            $rmodules[$lname] = $link['label'];

            if (!$fieldsData[$link['module']]) {
                $relatedModuleBean = BeanFactory::getBean($link['module']);

                if ($formulaHelperClass === "CustomFormulaHelper") {
                    $fieldsData[$link['module']] = CustomFormulaHelper::cleanFields($relatedModuleBean->field_defs);
                } else {
                    $fieldsData[$link['module']] = FormulaHelper::cleanFields($relatedModuleBean->field_defs);
                }
            }
        }

        // get the fields
        if (!empty($links)) {
            reset($links);

            foreach ($links as $link) {
                $tempModuleBean        = BeanFactory::newBean($link['module']);
                $tempModuleFieldsArray = array();

                foreach ($tempModuleBean->field_defs as $tempModuleFieldName => $tempModuleFieldData) {
                    if ($tempModuleFieldData["type"] !== "link") {
                        $tempModuleFieldsArray[$tempModuleFieldName] = translate($tempModuleFieldData['vname'], $link['module']);
                    }
                }
                $rfields[$link['label']] = $tempModuleFieldsArray;
            }
        }

        global $mod_strings;

        $mod_strings = return_module_language($current_language, 'Schedulers');
        // require_once 'modules/Schedulers/Scheduler.php';

        // get all the jobs used
        $jobsList = Scheduler::getJobsList();

        $documentsList = array();

        $checkIfDocTableExist =
            <<<EOQ
SHOW TABLES LIKE 'documents_cstm';
EOQ;
        if ($sugar_config['dbconfig']['db_type'] == "mssql") {
            $checkIfDocTableExist =
                <<<EOQ
sp_tables '%documents_cstm%'
EOQ;
        }
        $documentsResult = $conn->executeQuery($checkIfDocTableExist);
        $row             = $documentsResult->fetch();

        if ($row) {
            $documentsQuery =
                <<<EOQ
    SELECT * FROM documents
    INNER JOIN documents_cstm
    ON documents.id=documents_cstm.id_c
    INNER JOIN document_revisions
    ON document_revisions.document_id = documents.id
    AND documents.is_template=1
    AND documents.deleted=0
    AND document_revisions.deleted=0
EOQ;

            $documentsResult = $conn->executeQuery($documentsQuery);

            while ($documentRow = $documentsResult->fetch()) {
                if ($documentRow["doc_module_c"] === $correctModuleName) {
                    array_push($documentsList, $documentRow);
                }
            }
        } else {
            $documentsQuery =
                <<<EOQ
    SELECT * FROM documents
    INNER JOIN document_revisions
    ON document_revisions.document_id = documents.id
    WHERE documents.is_template=1
    AND documents.deleted=0
    AND document_revisions.deleted=0
EOQ;

            $documentsResult = $conn->executeQuery($documentsQuery);

            while ($documentRow = $documentsResult->fetch()) {
                array_push($documentsList, $documentRow);
            }
        }

        // assign vars
        $ss->assign('FUNCTIONS_DESCRIPTION', base64_encode(json_encode($functionsDesc, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)));
        $ss->assign('BUTTONS', $buttons);
        $ss->assign('MODULE_FIELDS', base64_encode($fieldOptions));
        $ss->assign('DOCUMENTS', base64_encode(json_encode($documentsList)));
        $ss->assign('JOBS', base64_encode(json_encode($jobsList)));
        $ss->assign('HIDDEN_MODULES', base64_encode(json_encode($hidden_modules)));
        $ss->assign('MODULES', base64_encode(json_encode($modules)));
        $ss->assign('FIELDS_DATA', base64_encode(json_encode($fieldsData)));
        $ss->assign('MODULE_NAME', base64_encode($correctModuleName));
        $ss->assign('RELATED_MODULE_FIELDS', base64_encode(json_encode($rfields)));
        $ss->assign('RELATED_MODULES', base64_encode(json_encode($rmodules)));
        $ss->assign('MODULE_NOT_DEPLOYED', false);
    } else {
        $ss->assign('MODULE_NOT_DEPLOYED', true);
    }

    return $ss->fetch('custom/modules/DynamicFields/templates/Fields/Forms/buttonset.tpl');
}
