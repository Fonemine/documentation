/* eslint-disable max-depth */
/* eslint-disable require-jsdoc */
class wRBRunUrl {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (actionData.calculatedField === true && window.navigator.onLine !== true) {
            app.alert.show("alert_invalid_url", {
                level          : "error",
                title          : "ErrorUrl",
                messages       : app.lang.get("LBL_WRB_OFFLINE_AVAILABLE_ALERT"),
                autoClose      : true,
                autoCloseDelay : 5000
            });
        } else {
            this.goToWebsite(actionData, model);
        }
    }

    goToWebsite(actionData, model) {
        var self = this;

        if (actionData.calculatedField === true) {
            var cleanFormula = this.replaceCharInString(actionData.formulaElement, "'", "\"");

            var successCallback = {
                success: function (expressionData) {
                    var takeCalculatedUrl = "";
                    if (actionData.showAlert === true) {
                        var userResponse = confirm("This action will open a new tab.Do you want to proceed?");

                        if (userResponse === true) {
                            takeCalculatedUrl = expressionData.buildUrlTempField.value;
                            if (!takeCalculatedUrl || takeCalculatedUrl === "") {
                                app.alert.show("alert_invalid_url", {
                                    level          : "error",
                                    title          : "This URL: " + takeCalculatedUrl + " is not valid!",
                                    messages       : "This URL: " + takeCalculatedUrl + " is not valid!",
                                    autoClose      : true,
                                    autoCloseDelay : 5000
                                });
                            } else {
                                self.openUrl(takeCalculatedUrl);
                            }
                        } else {
                            app.controller.trigger("wRBActionFinished", self);
                        }
                    } else {
                        takeCalculatedUrl = expressionData.buildUrlTempField.value;
                        if (!takeCalculatedUrl || takeCalculatedUrl === "") {
                            app.alert.show("alert_invalid_url", {
                                level          : "error",
                                title          : "This URL: " + takeCalculatedUrl + " is not valid!",
                                messages       : "This URL: " + takeCalculatedUrl + " is not valid!",
                                autoClose      : true,
                                autoCloseDelay : 5000
                            });
                        } else {
                            self.openUrl(takeCalculatedUrl);
                        }
                    }
                }
            };
            var apiUrl = app.api.buildURL("EvaluateCalculatedURL/evaluate_calculated_url", "create", {}, {});

            var takeCalculatedUrlFormula = {
                keepTempFieldForCalculatedURL: {
                    buildUrlTempField: {
                        targetField : "buildUrlTempField",
                        formula     : cleanFormula
                    }
                },
                recordType : model.module,
                recordId   : model.id
            };

            app.api.call("create", apiUrl, takeCalculatedUrlFormula, null, successCallback);
        } else {
            var completeUrl = "";
            var attributes = {};
            var protocol = false;
            
            if (actionData.showAlert === true) {
                var userResponse = confirm("This action will open a new tab.Do you want to proceed?");
                if (userResponse === true) {
                    completeUrl = actionData.finalUrl;
                    attributes = completeUrl.match(/\{.*?\}/g);

                    _.each(attributes, function replaceAttributes(attribute) {
                        var attributeName = attribute.match(/\{([^)]+)\}/)[1];
                        var fieldValue = model.get(attributeName);

                        completeUrl = completeUrl.replace(/\{.*?\}/, fieldValue);
                    });

                    completeUrl.replace(/ /g, "%20");

                    if (!completeUrl || completeUrl === "") {
                        app.alert.show("alert_invalid_url", {
                            level          : "error",
                            title          : "This URL: " + completeUrl + " is not valid!",
                            messages       : "This URL: " + completeUrl + " is not valid!",
                            autoClose      : true,
                            autoCloseDelay : 5000
                        });
                    } else {
                        protocol = completeUrl.match(/^\w+:/gi);

                        if (!protocol) {
                            completeUrl = "http://" + completeUrl;
                        }

                        self.openUrl(completeUrl);
                    }
                    app.controller.trigger("wRBActionFinished", self);
                } else {
                    app.controller.trigger("wRBActionFinished", self);
                }
            } else {
                completeUrl = actionData.finalUrl;
                attributes = completeUrl.match(/\{.*?\}/g);

                _.each(attributes, function replaceAttributes(attribute) {
                    var attributeName = attribute.match(/\{([^)]+)\}/)[1];
                    var fieldValue = model.get(attributeName);

                    completeUrl = completeUrl.replace(/\{.*?\}/, fieldValue);
                });

                completeUrl.replace(/ /g, "%20");

                if (!completeUrl || completeUrl === "") {
                    app.alert.show("alert_invalid_url", {
                        level          : "error",
                        title          : "This URL: " + completeUrl + " is not valid!",
                        messages       : "This URL: " + completeUrl + " is not valid!",
                        autoClose      : true,
                        autoCloseDelay : 5000
                    });
                } else {
                    protocol = completeUrl.match(/^\w+:/gi);

                    if (!protocol) {
                        completeUrl = "http://" + completeUrl;
                    }

                    self.openUrl(completeUrl);
                }
                app.controller.trigger("wRBActionFinished", self);
            }
        }
    }

    replaceCharInString(brokenFormula, charToReplace, newChar) {
        var formulaBody = brokenFormula;
        var regex = new RegExp("\\" + charToReplace);

        while (formulaBody.match(regex)) {
            formulaBody = formulaBody.replace(regex, newChar);
        }

        return formulaBody;
    }

    openUrl(urlToOpen) {
        SUGAR.customizationTools.deviceFeatures.openUrl(urlToOpen, {
            encode: true
        });
    }
}

module.exports.wRBRunUrl = wRBRunUrl;