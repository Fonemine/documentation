/*eslint-disable*/
class wRBAssignRecord {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        var self = this;

        if (window.navigator.onLine === true) {
            var currentUserId = actionData.assignedToUserId;
            var currentUserName = actionData.assignedToUserName;

            if (currentUserId === "currentUser") {
                currentUserId = app.user.get("id");
                currentUserName = app.user.get("full_name");
            }

            model.set("assigned_user_id", currentUserId);
            model.set("assigned_user_name", currentUserName);
            model.save(null, {
                success: function () {
                    app.controller.trigger("wRBActionFinished", self);
                },

                error: function () {
                    app.controller.trigger("wRBActionFinished", self);
                },
                fields: Object.keys(model.attributes)
            });

        } else {
            app.alert.show("alert_invalid_url", {
                level: "error",
                title: "ErrorUrl",
                messages: app.lang.get("LBL_WRB_OFFLINE_AVAILABLE_ALERT"),
                autoClose: true,
                autoCloseDelay: 5000
            });
        }
    }
}

module.exports.wRBAssignRecord = wRBAssignRecord;