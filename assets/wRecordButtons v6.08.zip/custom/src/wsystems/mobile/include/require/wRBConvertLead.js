/*eslint-disable*/
class wRBConvertLead {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        var self = this;

        if (model.get("status") === "Converted") {
            app.alert.show("alert_lead_converted", {
                level: "error",
                title: app.lang.get("LBL_WRB_RECORD_CONVERTED"),
                messages: app.lang.get("LBL_WRB_RECORD_CONVERTED"),
                autoClose: true,
                autoCloseDelay: 5000
            });
            app.controller.trigger("wRBActionFinished", this);
        } else if (model.get("converted") === false) {
            var convertMetadata = app.metadata.getModule("Leads", "layouts")["convert-main"];
            var conversionModules = convertMetadata.meta.modules;

            var leadConversionView = app.controller.loadScreen({
                isDynamic: true,
                applyMaskToList: true,
                view: app.nomad.getViewClass("lead-conversion"),
                data: {
                    leadModel: model,
                    conversionModules
                }
            })[0];

            var onConversionSuccess = leadConversionView.onConversionSuccess;

            leadConversionView.onConversionSuccess = function () {
                app.controller.trigger("wRBActionFinished", self);
                onConversionSuccess.call(leadConversionView);
            }.bind(leadConversionView);

            var onConversionError = leadConversionView.onConversionError;

            leadConversionView.onConversionError = function () {
                app.controller.trigger("wRBActionFinished", self);
                onConversionError.call(leadConversionView);
            }.bind(leadConversionView);

            var handleComponentAction = leadConversionView.layout.handleComponentAction;

            leadConversionView.layout.handleComponentAction = function (actionInitiator, action) {
                app.controller.trigger("wRBActionFinished", self);
                handleComponentAction.call(leadConversionView.layout, actionInitiator, action);
            }.bind(leadConversionView.layout);
        }
    }
}

module.exports.wRBConvertLead = wRBConvertLead;