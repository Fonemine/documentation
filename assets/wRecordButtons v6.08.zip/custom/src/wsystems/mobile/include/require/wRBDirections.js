/*eslint-disable*/
class wRBDirections {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        app.mobile.wMapsContextButtons.wMapsMobileMapManager.tryShowBingMap(true);

        this.manager.goToNextActionDelayed(this);
    }
}

module.exports.wRBDirections = wRBDirections;