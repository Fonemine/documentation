/*eslint-disable*/
class wRBCreateRecord {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (app.acl.hasAccess("edit", actionData.recordType)) {
            var recordType = actionData.recordType;
            var loadScreenOptions = {
                action: "create",
                module: recordType,
                root: ""
            };

            // check if the record is linked so we know if we create a linked record or not
            if (actionData.linkRecord === true) {
                var relation = _.filter(model.fields, function getLinks(val) {
                    return val.type == "link" && val.module === recordType;
                });

                var link = relation[relation.length - 1] ?
                    relation[relation.length - 1].name :
                    recordType.toLowerCase();

                if (app.metadata.getModule(model.module).fields[link]) {
                    loadScreenOptions = {
                        action: "create",
                        link: link,
                        parentModelId: model.id,
                        parentModule: model.module
                    };
                } else {
                    actionData.linkRecord = false;
                }
            }
            var views = app.controller._loadScreen(loadScreenOptions);
            var createView = _.filter(views, function getCreateView(viewData) {
                return viewData.options.create === true;
            })[0];

            var currentScreenContext = app.controller.getScreenContext();

            if (actionData.linkRecord === true) {
                var prefixUrl = app.navigation.history.location.hash.replace("#Search/", "#");

                this.manager.registerStepInHistory(prefixUrl + "/link/" + currentScreenContext.link + "/" + currentScreenContext.action);
            } else {
                this.manager.registerStepInHistory("#" + currentScreenContext.module + "/" + currentScreenContext.action);
            }

            var recordAttributes = _.clone(actionData.recordAttributes);
            if (
                actionData.recordAttributes.assigned_user_id === "" ||
                actionData.recordAttributes.assigned_user_id === undefined
            ) {
                // preset current user as the assigned user
                createView.model.set("assigned_user_id", app.user.id);
                createView.model.set("assigned_user_name", app.user.get("full_name"));
            }

            if (actionData.copyParentValues === true) {
                createView.model.set(model.attributes);
            }

            var attributesFromParent = actionData.attributesFromParent ?
                actionData.attributesFromParent : {};

            // taking care of the custom fields
            _.each(recordAttributes, function cleanFieldsData(attributeData, attributeKey) {
                // handling the wAttachmentsField
                if (
                    createView.model.fields[attributeKey] &&
                    createView.model.fields[attributeKey].type === "wAttachmentsField"
                ) {
                    recordAttributes[attributeKey] = window.atob(attributeData);
                }
            });

            // add the preset values from the studio
            createView.model.set(recordAttributes);

            var fieldsToBeCleanedFromModel = [];
            var forceParentTypeCopy = false;

            _.each(attributesFromParent, function fixRelatedFields(fieldData, fieldUID) {
                if (fieldData.currentRecordField === "parent_id" || fieldData.currentRecordField === "parent_name") {
                    forceParentTypeCopy = true;
                }
                var cFieldData = createView.model.fields[fieldData.currentRecordField];
                var pFieldData = model.fields[fieldData.parentRecordField];
                var cFieldName = false;
                var pFieldName = false;

                if (cFieldData && cFieldData.type === "id") {
                    if (cFieldData.link) {
                        cFieldName = cFieldData.link + "_name";
                    } else {
                        var cRFieldNameData = _.filter(createView.model.fields, function getRelField(relFieldData) {
                            return relFieldData["id_name"] === fieldData.currentRecordField;
                        })[0];

                        if (cRFieldNameData) {
                            cFieldName = cRFieldNameData.name;
                        }
                    }
                }

                if (pFieldData && pFieldData.type === "id") {
                    if (pFieldData.link) {
                        pFieldName = pFieldData.link + "_name";
                    } else {
                        var pRFieldNameData = _.filter(model.fields, function getRelField(relFieldData) {
                            return relFieldData["id_name"] === fieldData.parentRecordField;
                        })[0];

                        if (pRFieldNameData) {
                            pFieldName = pRFieldNameData.name;
                        }
                    }
                }

                if (cFieldName && pFieldName) {
                    attributesFromParent[cFieldName + pFieldName] = {
                        currentRecordField: cFieldName,
                        parentRecordField: pFieldName
                    };
                } else {
                    var _cFieldID = false;
                    var _cFieldName = false;
                    var _pFieldID = false;
                    var _pFieldName = false;
                    
                    if (cFieldData && cFieldData.type === "relate") {
                        _cFieldName = cFieldData.name;
                        _cFieldID = cFieldData.id_name;
                    }

                    if (cFieldData && cFieldData.type === "link") {
                        _cFieldName = cFieldData.name + "_name";
                        _cFieldID = cFieldData.id_name;
                    }

                    if (pFieldData && pFieldData.type === "relate") {
                        _pFieldName = pFieldData.name;
                        _pFieldID = pFieldData.id_name;
                    }

                    if (pFieldData && pFieldData.type === "link") {
                        _pFieldName = pFieldData.name + "_name";
                        _pFieldID = pFieldData.id_name;
                    }

                    if (_cFieldID && _cFieldName && _pFieldID && _pFieldName) {
                        attributesFromParent[_cFieldID + _pFieldID] = {
                            currentRecordField : _cFieldID,
                            parentRecordField  : _pFieldID
                        };
                        attributesFromParent[_cFieldName + _pFieldName] = {
                            currentRecordField : _cFieldName,
                            parentRecordField  : _pFieldName
                        };

                        fieldsToBeCleanedFromModel.push(fieldUID);
                    }
                }
            });

            _.each(fieldsToBeCleanedFromModel, function cleanParentFields(brokenFieldName){
                delete attributesFromParent[brokenFieldName];
            });

            fieldsToBeCleanedFromModel = [];

            _.each(attributesFromParent, function setAttributesOnRecord(attributesData) {
                createView.model.set(
                    attributesData.currentRecordField,
                    model.get(attributesData.parentRecordField)
                );
                var currentParentField = model.fields[attributesData.parentRecordField];
                if (currentParentField.type === "relate") {
                    var groupField = model.fields[currentParentField.id_name].group;

                    if (groupField) {
                        createView.model.set(groupField, model.get(groupField));
                    }
                    createView.model.set(currentParentField.id_name, model.get(currentParentField.id_name));
                } else if (currentParentField.name === "parent_id") {
                    createView.model.set(attributesData.currentRecordField, model.get("parent_id"));
                    //eslint-disable-next-line
                    createView.model.attributes.parent_name = model.get("parent_name");
                }
            });

            // delete the id as this is a new model
            delete createView.model.id;
            delete createView.model.attributes.id;

            var headerView = _.filter(createView._components, function getHeaderView(view) {
                return view.name === "header";
            })[0];

            if (headerView) {
                headerView.on(
                    "component:action",
                    function executeNextAction(action) {
                        if (action.name === "header:cancel:click") {
                            app.controller.trigger("wRBActionFinished", this);
                        }
                    },
                    this
                );
            }

            var editView = _.filter(createView._components, function getEditView(view) {
                return view.name === "edit";
            })[0];

            if (editView) {
                editView.on(
                    "component:action",
                    function executeNextAction(action) {
                        if (action.name === "edit:view:save") {
                            app.controller.trigger("wRBActionFinished", this);
                        }
                    },
                    this
                );
            }
        } else {
            this.manager.showNoAccessAlert();
        }

        return true;
    }
}

module.exports.wRBCreateRecord = wRBCreateRecord;