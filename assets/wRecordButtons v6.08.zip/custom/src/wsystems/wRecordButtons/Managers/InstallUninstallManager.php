<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Managers;

use DBManagerFactory;
use Doctrine\DBAL\DBALException;
use Doctrine\DBAL\Query\QueryException;
use Exception;

/**
 *
 * @package Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Managers
 */
class InstallUninstallManager
{
    /**
     *
     * @var string
     */
    private $fieldType = "";
    const SOURCE_TABLE = "fields_meta_data";

    /**
     *
     * @param string $fromTable
     * @param string $toTable
     * @param string $fieldType
     * @param string $backupTableName
     * @return void
     * @throws Exception
     * @throws DBALException
     * @throws QueryException
     */
    public function execute(string $fromTable, string $toTable, string $fieldType, string $backupTableName): void
    {
        $this->fieldType = $fieldType;

        $db = DBManagerFactory::getInstance();

        //creating the backup table if it does not exists
        if ($db->tableExists($backupTableName) === true) {
            $db->repairTableParams(
                $backupTableName,
                $db->get_columns(self::SOURCE_TABLE),
                $db->get_indices(self::SOURCE_TABLE)
            );
        } else {
            $this->createFieldsMetadataBackupTable($backupTableName);
        }

        //getting all the columns of the fieldmetadata table
        $columns      = $db->get_columns($fromTable);
        $tableColumns = array_keys($columns);

        //we then need to get all the data that is going to be backed up
        $fieldsMetadata = $this->getTargetFieldsMetadata($tableColumns, $fromTable);

        //sending over the data to the backup table
        $this->saveFieldsMetadata($fieldsMetadata, $toTable);
        //removing the data from the original table
        $this->cleanFieldsMetadata($fromTable);
    }

    /**
     * Return all fields metadata that matches type
     * @param array $tableColumns
     * @param string $fromTable
     * @return array
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    private function getTargetFieldsMetadata(array $tableColumns, string $fromTable): array
    {
        $fieldsMetadata = array();

        //building the query that returns the data we want to backup up
        $getTargetFieldsDataQB = DBManagerFactory::getConnection()->createQueryBuilder();

        $getTargetFieldsDataQB
            ->select($tableColumns)
            ->from($fromTable);

        $expression         = $getTargetFieldsDataQB->expr();
        $tableNameCondition = $expression->eq(
            "type",
            $getTargetFieldsDataQB->createPositionalParameter($this->fieldType)
        );

        $getTargetFieldsDataQB->where($tableNameCondition);
        $getTargetFieldsDataQBResult = $getTargetFieldsDataQB->execute();

        //going through all the fields metadata
        if ($getTargetFieldsDataQBResult instanceof \Doctrine\DBAL\Portability\Statement) {
            while ($fieldMetadata = $getTargetFieldsDataQBResult->fetch()) {
                $sanitizedData = array();

                //we have to escaped quotes and double quotes, otherwise the query will crash
                foreach ($fieldMetadata as $fieldName => $fieldValue) {
                    $sanitizedData[$fieldName] = "'" . addslashes($fieldValue) . "'";
                }

                $fieldsMetadata[] = $sanitizedData;
            }
        }

        return $fieldsMetadata;
    }

    /**
     * Insert fields metadata to the target table
     * @param array $fieldsMetadata
     * @param string $toTable
     * @return void
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    private function saveFieldsMetadata(array $fieldsMetadata, string $toTable): void
    {
        $insertFieldQB = DBManagerFactory::getConnection()->createQueryBuilder();

        foreach ($fieldsMetadata as $fieldMetadata) {
            $insertFieldQB
                ->insert($toTable)
                ->values(
                    $fieldMetadata
                );

            $insertFieldQB->execute();
        }
    }

    /**
     * Delete from target table fields metadata that match the type
     * @param string $fromTable
     * @return void
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    private function cleanFieldsMetadata(string $fromTable): void
    {
        $cleanFieldsMetadataQB = DBManagerFactory::getConnection()->createQueryBuilder();
        $cleanFieldsMetadataQB
            ->delete($fromTable);

        $expression         = $cleanFieldsMetadataQB->expr();
        $fieldTypeCondition = $expression->eq(
            "type",
            $cleanFieldsMetadataQB->createPositionalParameter($this->fieldType)
        );

        $cleanFieldsMetadataQB->where($fieldTypeCondition);
        $cleanFieldsMetadataQB->execute();
    }

    /**
     * Create backup table if it does not exist
     * @param string $backupTableName
     * @return void
     * @throws Exception
     * @throws DBALException
     */
    private function createFieldsMetadataBackupTable(string $backupTableName): void
    {
        $db   = DBManagerFactory::getInstance();
        $conn = $db->getConnection();

        $createCachingTable = <<<SQL
CREATE TABLE
${backupTableName}
LIKE fields_meta_data
SQL;

        if ($db->dbType === "mssql") {
            $createCachingTable = <<<SQL
SELECT TOP 0 *
INTO ${backupTableName}
FROM fields_meta_data
SQL;
        }

        $conn->executeQuery($createCachingTable);
    }
}
