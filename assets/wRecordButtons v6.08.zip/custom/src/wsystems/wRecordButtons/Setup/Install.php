<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Setup;

use Doctrine\DBAL\DBALException;
use Doctrine\DBAL\Query\QueryException;
use Exception;
use Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Managers\InstallUninstallManager;

/**
 *
 * @package Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Setup
 */
class Install
{
    const FIELD_TYPE        = "buttonset";
    const BACKUP_TABLE_NAME = "wsys_wrb_fields_metadata";
    const BASE_TABLE_NAME   = "fields_meta_data";

    /**
     *
     * @return void
     * @throws Exception
     * @throws DBALException
     * @throws QueryException
     */
    public function postInstall()
    {
        $installManager = new InstallUninstallManager();

        $installManager->execute(
            self::BACKUP_TABLE_NAME,
            self::BASE_TABLE_NAME,
            self::FIELD_TYPE,
            self::BACKUP_TABLE_NAME
        );
    }
}
