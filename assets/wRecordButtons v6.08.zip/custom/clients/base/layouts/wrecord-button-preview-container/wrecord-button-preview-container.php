<?php
$viewdefs['base']['layout']['wrecord-button-preview-container'] = array(
    'name'       => 'wrecord-button-preview-container',
    'type'       => 'wrecord-button-preview-container',
    'span'       => 3,
    'components' => array(),
);
