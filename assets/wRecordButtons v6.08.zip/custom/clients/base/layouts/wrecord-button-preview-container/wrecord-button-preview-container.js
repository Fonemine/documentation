/**
 * Class Description
 *
 * @class wrecord-button-preview-container
 */
({
    previewElement       : null,
    previewHeaderElement : null,
    buttonsGroup         : null,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.buttons = {};
        this.model = new Backbone.Model(this.model.attributes);

        this.wRecordButtonLabel = this.model.attributes.fieldLabel;
        this.moduleName = this.model.attributes.moduleName;
        this.moduleAvatarLabel = App.lang.getModuleIconLabel(this.moduleName);

        this.updatePreviewButtons(options.layout.model);

        return initResult;
    },

    /**
     * Description
     * @method updatePreviewButtons
     * @param {} model
     * @return
     */
    updatePreviewButtons: function (model) {
        // manage the preview of the buttons
        var modelData = model.attributes;
        var settingsData = modelData.buttonsSettings;
        var maxButtonsInHeader = 5;

        // delete earlier created widgets
        this.deleteExistingWidgets();

        // create the new updated widgets
        model = new Backbone.Model(modelData);
        var elementType =
            settingsData.buttonType === "dropDown" ? "wrecord-button-dropdown-preview" : "wrecord-buttons-preview";

        if (modelData.buttonsSettings.buttonType === "buttonsGroup") {
            this.$el.find("#buttonsPreviewContainer").css("overflow", "auto");
        } else if (modelData.buttonsSettings.buttonType === "dropDown") {
            this.$el.find("#buttonsPreviewContainer").css("overflow", "initial");
        }

        _.each(
            model.attributes.buttons,
            function updateLabel(buttonsData) {
                if (buttonsData.dependencyLabelField === true) {
                    buttonsData.label = "[Calculated Label]";
                }
            }.bind(this)
        );

        // hide the containers
        this.$el.find("#buttonsPreviewHeaderContainer").hide();

        this.previewElement = App.view.createView({
            name           : elementType,
            model          : model,
            parentView     : this,
            layout         : this,
            showInHeader   : false,
            selectedModule : "Home"
        });

        this.previewElement.render();

        // if we also show the buttons in header clone the element
        if (settingsData.showInHeader === true) {
            if (Object.keys(modelData.buttons).length > maxButtonsInHeader) {
                elementType = "wrecord-button-dropdown-preview";
            }
            this.$el.find("#buttonsPreviewHeaderContainer").show();
            this.previewHeaderElement = App.view.createView({
                name           : elementType,
                model          : model,
                parentView     : this,
                layout         : this,
                showInHeader   : true,
                selectedModule : "Home"
            });

            this.previewHeaderElement.render();

            this.$el.find("#buttonsPreviewHeaderContainer").append(this.previewHeaderElement.$el);
        }

        // insert the new widgets in the container
        if (settingsData.showLabelName === true) {
            this.$el
                .find("#previewFieldLabel")
                .text(this.wRecordButtonLabel)
                .show();
        } else {
            this.$el
                .find("#previewFieldLabel")
                .text(this.wRecordButtonLabel)
                .hide();
        }

        this.$el.find("#buttonsPreviewContainer").append(this.previewElement.$el);
    },

    /**
     * Description
     * @method deleteExistingWidgets
     * @return
     */
    deleteExistingWidgets: function () {
        if (this.previewElement !== null) {
            this.previewElement.remove();
        }

        if (this.previewHeaderElement !== null) {
            this.previewHeaderElement.remove();
        }
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        // register needed events
        this.options.layout.model.on("change:buttons", this.updatePreviewButtons, this);
        this.options.layout.model.on("change:buttonsSettings", this.updatePreviewButtons, this);

        var renderResult = this._super("render", arguments);

        this.styleElement();

        return renderResult;
    },

    /**
     * Description
     * @method styleElement
     * @return
     */
    styleElement: function () {
        this.$el.css("width", "37.9%");
        this.$el.css("margin-left", "62%");

        var headerAvatar = this.$el.find(".headerAvatar");

        headerAvatar.addClass("label-" + this.moduleName);
        headerAvatar.text(this.moduleAvatarLabel);
    }
});
