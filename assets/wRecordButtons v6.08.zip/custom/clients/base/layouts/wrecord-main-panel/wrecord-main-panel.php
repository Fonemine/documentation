<?php
$viewdefs['base']['layout']['wrecord-main-panel'] = array(
    'type'       => 'wrecord-main-panel',
    'name'       => 'wrecord-main-panel',
    'span'       => 8,
    'components' => array(
        array(
            'view' => 'wrecord-headerpane',
        ),
        array(
            'view' => 'wrecord-buttons-container',
        ),
        array(
            'layout' => 'wrecord-buttons-actions-container',
        ),
    ),
);
