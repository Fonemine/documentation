/**
 * Class Description
 *
 * @class wrecord-settings
 */
({
    canDeleteButtons : true,
    actions          : {},

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        this.actions = options.meta.actions;
        // parse the saved data, if it exists
        var buttonsParsed = options.def.context.model.attributes;
        var settingsModel = new Backbone.Model(buttonsParsed);

        options.def.context.model.attributes.fields = settingsModel.get("fields");

        this.options.context.model = settingsModel;
        this.options.context.model.module = "Home";
        options.def.context.model = settingsModel;

        var initResult = this._super("initialize", arguments);

        this.model = settingsModel;
        this.canDeleteButtons = true;
        this.tryAddDefaultButton();

        this.layout.changesMade = true;

        return initResult;
    },

    /**
     * Description
     * @method tryAddDefaultButton
     * @return
     */
    tryAddDefaultButton: function () {
        if (Object.keys(this.model.get("buttons")).length < 1) {
            this.addButtonData({});
        }
    },

    /**
     * Description
     * @method getButtonsNumber
     * @return MemberExpression
     */
    getButtonsNumber: function () {
        return Object.keys(this.model.attributes.buttons).length;
    },

    /**
     * Description
     * @method registerButton
     * @param {} buttonData
     * @param {} recentlyAdded
     * @return
     */
    registerButton: function (buttonData, recentlyAdded) {
        // register a new button
        // compute a unique id
        var id = buttonData.index ? buttonData.index : App.utils.generateUUID();
        var defaultTabId = App.utils.generateUUID();
        var buttonActions = {};

        buttonActions[defaultTabId] = {
            action           : "doNothing",
            actionParameters : {}
        };

        if (buttonData.actions) {
            buttonActions = buttonData.actions;
        }

        var defaultDependencyData = {
            formulaElement    : "",
            validationMessage : "",
            validFormula      : false
        };

        var translatedLabel = "Button";

        // set default values for the newly created button
        var buttonOptions = {
            orderNumber     : buttonData.orderNumber ? buttonData.orderNumber : this.getButtonsNumber() + 1,
            label           : translatedLabel,
            actions         : buttonActions,
            icon            : buttonData.icon ? buttonData.icon : "fa-cog",
            index           : id,
            showLabel       : buttonData.showLabel ? buttonData.showLabel : true,
            showIcon        : buttonData.showIcon ? buttonData.showIcon : false,
            buttonStyle     : buttonData.buttonStyle ? buttonData.buttonStyle : "btn-inverse",
            dependencyField : buttonData.dependencyField ? buttonData.dependencyField : false,
            dependencyData  : buttonData.dependencyData ? buttonData.dependencyData : defaultDependencyData
        };

        this.handleButtonDataChange(id, buttonOptions);

        this.showButtonConfig(id, recentlyAdded);
    },

    /**
     * Description
     * @method changeGeneralSettings
     * @param {} key
     * @param {} value
     * @return
     */
    changeGeneralSettings: function (key, value) {
        // change the general settings of the buttons
        var buttonsSettings = _.clone(this.model.get("buttonsSettings"));
        buttonsSettings[key] = value;

        this.model.set("buttonsSettings", buttonsSettings);
    },

    /**
     * Description
     * @method handleButtonDataChange
     * @param {} buttonId
     * @param {} buttonData
     * @return
     */
    handleButtonDataChange: function (buttonId, buttonData) {
        // change data of a button by id
        var buttons = _.clone(this.model.get("buttons"));
        buttons[buttonId] = _.clone(buttonData);

        this.model.set("buttons", buttons);
        this.model.trigger("change:buttons", this.model);
    },

    handleButtonLabelChange: function (buttonId, labelKey, labelValue) {
        // change data of a button by id
        var buttons = _.clone(this.model.get("buttons"));
        buttons[buttonId]["label"] = labelValue;
        buttons[buttonId]["labelKey"] = labelKey;

        this.model.set("buttons", buttons, {
            silent: true
        });
    },

    /**
     * Description
     * @method buttonLabelHasChanged
     * @param {} label
     * @param {} buttonId
     * @return
     */
    buttonLabelHasChanged: function (label, buttonId) {
        this.trigger("button:label:change", label, buttonId);
    },

    /**
     * Description
     * @method blockButtonRemoval
     * @param {} blockedValue
     * @return
     */
    blockButtonRemoval: function (blockedValue) {
        this.canDeleteButtons = !blockedValue;
    },

    /**
     * Description
     * @method deleteButton
     * @param {} buttonId
     * @return
     */
    deleteButton: function (buttonId) {
        // delete the button if it is allowed
        if (this.canDeleteButtons === true) {
            var buttons = _.clone(this.model.get("buttons"));
            var removedButtonOrderNumber = buttons[buttonId].orderNumber;

            delete buttons[buttonId];

            // reorder buttons after it has been deleted
            _.each(buttons, function orderButtons(buttonData) {
                if (buttonData.orderNumber > removedButtonOrderNumber) {
                    buttonData.orderNumber = buttonData.orderNumber - 1;
                }
            });

            this.model.set("buttons", buttons);
            this.model.trigger("change:buttons", this.model);

            var firstButtonId = this.getFirstButtonId();
            if (firstButtonId) {
                this.showButtonConfig(firstButtonId, true);
            }
        }
    },

    /**
     * Description
     * @method getFirstButtonId
     * @return firstButtonId
     */
    getFirstButtonId: function () {
        var firstButtonId = false;

        _.each(this.model.get("buttons"), function checkButtonOrderNumber(buttonData) {
            if (buttonData.orderNumber === 1) {
                firstButtonId = buttonData.index;
            }
        });

        return firstButtonId;
    },

    /**
     * Description
     * @method reOrderButtons
     * @param {} initialIndex
     * @param {} finalIndex
     * @return
     */
    reOrderButtons: function (initialIndex, finalIndex) {
        // when we change the order of the buttons we have to also change the orderNumber param so that we know how to order them
        var buttons = _.clone(this.model.get("buttons"));
        var buttonMoved = this.getButtonByOrderIndex(buttons, initialIndex);

        buttonMoved.orderNumber = -1;
        _.each(buttons, function orderButtons(buttonData) {
            if (buttonData.orderNumber !== -1) {
                if (
                    initialIndex > finalIndex &&
                    buttonData.orderNumber >= finalIndex &&
                    buttonData.orderNumber <= initialIndex
                ) {
                    buttonData.orderNumber = buttonData.orderNumber + 1;
                }

                if (
                    initialIndex < finalIndex &&
                    buttonData.orderNumber >= initialIndex &&
                    buttonData.orderNumber <= finalIndex
                ) {
                    buttonData.orderNumber = buttonData.orderNumber - 1;
                }
            }
        });

        buttonMoved.orderNumber = finalIndex;

        this.model.set("buttons", buttons);
        this.model.trigger("change:buttons", this.model);
    },

    /**
     * Description
     * @method getButtonByOrderIndex
     * @param {} buttons
     * @param {} orderIndex
     * @return button
     */
    getButtonByOrderIndex: function (buttons, orderIndex) {
        var button = null;

        _.each(buttons, function reOrderButtons(buttonData) {
            if (buttonData.orderNumber === orderIndex) {
                button = buttonData;
            }
        });

        return button;
    },

    /**
     * Description
     * @method addButtonData
     * @param {} data
     * @param {} recentlyAdded
     * @return
     */
    addButtonData: function (data, recentlyAdded) {
        this.registerButton(data, recentlyAdded);
    },

    /**
     * Description
     * @method showButtonConfig
     * @param {} buttonId
     * @param {} recentlyAdded
     * @return
     */
    showButtonConfig: function (buttonId, recentlyAdded) {
        this.trigger("wRecordButton-pressed", buttonId, recentlyAdded);
        this.verifyButtonCorruption(buttonId, true, true);
    },

    /**
     * Description
     * @method showTip
     * @param {} tipType
     * @return
     */
    showTip: function (tipType) {
        this.trigger("show:tip", tipType);
    },

    /**
     * Description
     * @method canSave
     * @return canSave
     */
    canSave: function () {
        // check if we can save the buttons
        this.trigger("saving:record:buttons");
        var canSave = true;

        var buttonsData = this.model.get("buttons");
        var buttonsSettings = this.model.get("buttonsSettings");

        if (canSave === true) {
            if (buttonsSettings.dependencyField === true) {
                if (buttonsSettings.dependencyData.validFormula === false) {
                    app.alert.show("alert_missing_buttons", {
                        level          : "error",
                        title          : buttonsSettings.dependencyData.validationMessage,
                        autoClose      : true,
                        autoCloseDelay : 5000
                    });
                    canSave = false;
                }
            }
        }

        if (canSave === true) {
            _.each(
                buttonsData,
                function isButtonValidForSave(buttonData, buttonId) {
                    this.trigger("clean-button-" + buttonId);

                    var validFormula = true;
                    var formulaMessage = "";

                    var corruptionData = this.verifyButtonCorruption(buttonId, canSave);

                    canSave = corruptionData.canSave;
                    validFormula = corruptionData.validFormula;
                    formulaMessage = corruptionData.formulaMessage;

                    // we can't save if the formula provided is incorect
                    if (canSave === true && validFormula === false) {
                        app.alert.show("alert_missing_buttons", {
                            level          : "error",
                            title          : formulaMessage,
                            autoClose      : true,
                            autoCloseDelay : 5000
                        });
                        canSave = false;

                        this.trigger("corrupted-button-" + buttonId);
                    }
                }.bind(this)
            );
        }

        return canSave;
    },

    /**
     * Description
     * @method verifyButtonCorruption
     * @param {} buttonId
     * @param {} canSaveData
     * @param {} forceAllChecks
     * @return ObjectExpression
     */
    verifyButtonCorruption: function (buttonId, canSaveData, forceAllChecks) {
        var buttonsData = this.model.get("buttons");
        var validButtonFormula = true;
        var buttonFormulaMessage = "";
        var buttonData = buttonsData[buttonId];

        var actions = {
            assignRecord  : 0,
            createRecord  : 0,
            editRecord    : 0,
            saveRecord    : 0,
            convertLead   : 0,
            directions    : 0,
            handleRoute   : 0,
            map           : 0,
            mergeDocument : 0,
            nearby        : 0,
            runUrl        : 0,
            updateField   : 0,
            runJob        : 0
        };

        if (buttonData.dependencyField === true) {
            if (buttonData.dependencyData.validFormula === false) {
                app.alert.show("alert_missing_buttons", {
                    level          : "error",
                    title          : buttonData.dependencyData.validationMessage,
                    autoClose      : true,
                    autoCloseDelay : 5000
                });
                canSaveData = false;

                this.trigger("corrupted-button-" + buttonId);
                this.trigger("corrupted-button-" + buttonId + "-generalSettings");
            } else {
                this.trigger("clean-button-" + buttonId + "-generalSettings");
            }
        }

        if (canSaveData === true || forceAllChecks) {
            _.each(
                buttonData.actions,
                function checkActions(actionData, actionId) {
                    if (canSaveData === true || forceAllChecks) {
                        actions[actionData.action] = actions[actionData.action] + 1;

                        // we can't save if the formula provided is incorect
                        if (actionData.action === "updateField") {
                            if (actionData.actionParameters.corruptedFieldValue === true) {
                                this.trigger("corrupted-button-" + actionId, ".fieldType");

                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "The value inserted for this type of field is not valid, please insert a valid value!";
                            } else {
                                this.trigger("clean-button-" + actionId + ".fieldType");
                            }

                            if (
                                actionData.actionParameters.validFormula === false &&
                                actionData.actionParameters.calculatedField === true
                            ) {
                                this.trigger("corrupted-button-" + actionId);
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "The formula for : " +
                                    buttonData.label +
                                    " configurations is not valid =>" +
                                    actionData.actionParameters.validationMessage;
                            } else if (actionData.actionParameters.fieldType === "") {
                                this.trigger("corrupted-button-" + actionId, ".fieldType");
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "Field Element is required for: '" + buttonData.label + "' configurations";
                            } else {
                                this.trigger("clean-button-" + actionId);
                            }
                        } else if (actionData.action === "runUrl") {
                            var completeUrl = actionData.actionParameters.finalUrl;
                            var protocol = completeUrl.match(/^\w+:/gi);
                            var inheritedUrl = false;

                            if (completeUrl[0] === "{" && completeUrl[completeUrl.length - 1] === "}") {
                                var indexOffset = 2;
                                var urlFieldName = completeUrl.substr(1, completeUrl.length - indexOffset);
                                var fieldData = App.metadata.getModule(this.model.get("moduleName")).fields[
                                    urlFieldName
                                ];

                                if (fieldData && fieldData.type === "url") {
                                    inheritedUrl = true;
                                }
                            }

                            if (
                                ((protocol && (protocol[0] === "http:" || protocol[0] === "https:")) || !protocol) &&
                                !inheritedUrl
                            ) {
                                var validUrl = /[-a-zA-Z0-9@:%_+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_+.~#?&//=]*)?/gi.test(
                                    completeUrl
                                );

                                if (actionData.actionParameters.calculatedField === true) {
                                    // eslint-disable-next-line max-depth
                                    if (actionData.actionParameters.validFormula === false) {
                                        this.trigger("corrupted-button-" + actionId);
                                        validButtonFormula = false;
                                        buttonFormulaMessage =
                                            "The formula for : " +
                                            buttonData.label +
                                            " button is not valid =>" +
                                            actionData.actionParameters.validationMessage;
                                    }
                                } else if (!validUrl) {
                                    validButtonFormula = false;
                                    buttonFormulaMessage = "This URL: " + completeUrl + " is not valid!";
                                }
                            }
                        } else if (actionData.action === "runJob") {
                            if (actionData.actionParameters.jobName === "") {
                                this.trigger("corrupted-button-" + actionId, ".jobField");
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "Select a job before saving the '" + buttonData.label + "' configurations";
                            }
                        } else if (actionData.action === "composeMail") {
                            // if (actionData.actionParameters.emailTemplate === "") {
                            //     this.trigger("corrupted-button-" + actionId, "#emailTemplateField");
                            //     validButtonFormula = false;
                            //     buttonFormulaMessage =
                            //         "Select an email template before saving the '" +
                            //         buttonData.label +
                            //         "' configurations";
                            // }
                        } else if (actionData.action === "mergeDocument") {
                            var keepMergeDocObject = actionData.actionParameters.document;
                            if (Object.keys(keepMergeDocObject).length === 0) {
                                this.trigger("corrupted-button-" + actionId, ".template");
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "Select a template before saving the '" + buttonData.label + "' configurations";
                            }
                        } else if (actionData.action === "createRecord") {
                            if (actionData.actionParameters.recordType == "") {
                                this.trigger("corrupted-button-" + actionId, ".buttonType");
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "Select a module before saving the '" + buttonData.label + "' configurations";
                            }
                        } else if (actionData.action === "assignRecord") {
                            if (!actionData.actionParameters.assignedToUserId || actionData.actionParameters.assignedToUserId == "") {
                                this.trigger("corrupted-button-" + actionId, ".buttonType");
                                validButtonFormula = false;
                                buttonFormulaMessage =
                                    "Select an user before saving the '" + buttonData.label + "' configurations";
                            }
                        } else if (actionData.action === "tabsManagement") {
                            if (actionData.actionParameters.formulaElement == "") {
                                this.trigger("corrupted-button-" + actionId, "#tabFormulaTooltip");
                                validButtonFormula = false;
                                buttonFormulaMessage = "Add Tabs/Panels Visibility conditions";
                            }
                        }
                    }
                }.bind(this)
            );
        }

        return {
            validFormula   : validButtonFormula,
            formulaMessage : buttonFormulaMessage,
            canSave        : canSaveData
        };
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        this.$el.css("overflow-y", "auto");
        this.$el.css("overflow-x", "hidden");

        app.routing.offBefore("route", this.beforeRouteChange, this);
        app.routing.before("route", this.beforeRouteChange, this);

        return renderResult;
    },

    recordChangesMade: function (changesMade) {
        this.layout.changesMade = changesMade;
    },

    beforeRouteChange: function (model) {
        if (this.layout.changesMade === true) {
            this._targetUrl = Backbone.history.getFragment();
            app.alert.show("Route Navigation", {
                level     : "confirmation",
                messages  : app.lang.get("LBL_WRB_UNSAVED_CHANGES_ALERT"),
                onConfirm : _.bind(this.navigateToTargetURL, this),
                onCancel  : function () {}
            });
            return false;
        }

        return true;
    },

    navigateToTargetURL: function () {
        app.routing.offBefore("route", this.beforeRouteChange, this);
        app.router.navigate(this._currentUrl, {
            trigger : false,
            replace : true
        });
        app.router.navigate(this._targetUrl, {
            trigger: true
        });
        return;
    }
});