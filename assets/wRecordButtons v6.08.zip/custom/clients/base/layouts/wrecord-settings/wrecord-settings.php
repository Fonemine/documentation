<?php
$viewdefs['base']['layout']['wrecord-settings'] = array(
    'name'       => 'wrecord-settings',
    'type'       => 'wrecord-settings',
    'span'       => 12,
    'actions'    => array(
        "map"            => array("viewName" => false, "label" => "Bing Map"),
        "composeMail"    => array("viewName" => "wrecord-button-compose-mail", "label" => "Compose eMail"),
        "convertLead"    => array("viewName" => false, "label" => "Convert Lead"),
        "createRecord"   => array("viewName" => "wrecord-button-create-record", "label" => "Create Record"),
        "assignRecord"   => array("viewName" => "wrecord-button-assign-record", "label" => "Assign Record"),
        "directions"     => array("viewName" => false, "label" => "Directions"),
        "doNothing"      => array("viewName" => false, "label" => "Do Nothing"),
        "editRecord"     => array("viewName" => "wrecord-button-edit-record", "label" => "Edit Record"),
        "handleRoute"    => array("viewName" => false, "label" => "Manage wMaps Route"),
        "mergeDocument"  => array("viewName" => "wrecord-button-create-mergeDocument", "label" => "Merge Document"),
        "nearby"         => array("viewName" => false, "label" => "Nearby"),
        "runUrl"         => array("viewName" => "wrecord-button-run-url", "label" => "Run URL"),
        "runJob"         => array("viewName" => "wrecord-button-run-job", "label" => "Run Job"),
        "runReport"      => array("viewName" => "wrecord-button-run-report", "label" => "Run Report"),
        "saveRecord"     => array("viewName" => "wrecord-button-save-record", "label" => "Save Record"),
        "tabsManagement" => array("viewName" => "wrecord-button-tab-management", "label" => "Tabs/Panels Visibility Control"),
        "updateField"    => array("viewName" => "wrecord-button-update-field", "label" => "Update Field"),
    ),
    'components' => array(
        array(
            'layout' => 'wrecord-main-panel',
        ),
        array(
            'layout' => 'wrecord-button-preview-container',
        ),
        array(
            'layout' => 'wrecord-button-tips',
        ),
    ),
);
