/**
 * Class Description
 *
 * @class wrecord-button-create-mergeDocument
 */
({
    events: {
        "change [name=template]"  : "handleParamsChange",
        "change [name=mergeType]" : "handleMergeTypeChange"
    },

    actionParameters: {
        document  : {},
        mergeType : "docx"
    },

    templates               : {},
    templateDocs            : {},
    currentSelectedTemplate : "DefaultTemplate.docx",

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            document  : {},
            mergeType : "docx"
        };

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.$el.find("[name=mergeType]").select2();

        this.getTemplates();

        return renderResult;
    },

    /**
     * Description
     * @method getSelect2Options
     * @return select2Options
     */
    getSelect2Options: function () {
        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this._query, this);
        select2Options.selectOnBlur = true;
        select2Options.dropdownAutoWidth = true;

        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstIcon, secondIcon) {
                if (firstIcon.text < secondIcon.text) {
                    return -1;
                }

                if (firstIcon.text > secondIcon.text) {
                    return 1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _query: function (query) {
        var templates = this.templates;
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(templates)) {
            _.each(templates, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({ id: index, text: text });
                }
            });
        } else {
            templates = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) {
        var data = [];
        var values = this.currentSelectedTemplate;

        _.each(
            _.pick(this.templates, values),
            function pushEntries(value, key) {
                data.push({ id: key, text: value });
            },
            this
        );

        if (data.length === 1) {
            callback(data[0]);
        } else {
            callback(data);
        }
    },

    /**
     * Description
     * @method getTemplates
     * @return
     */
    getTemplates: function () {
        var docsList = this.layout.layout.model.get("documentsList");
        this.templateDocs = {};
        this.templates = {};
        // compute the list of all template documents
        _.each(
            docsList,
            function insertTemplate(templateDoc) {
                if (templateDoc.for_label_merging_c !== 1) {
                    var templateKey = templateDoc.document_name;

                    if (this.templateDocs[templateKey]) {
                        templateKey = templateKey + App.utils.generateUUID();
                    }

                    this.templateDocs[templateKey] = templateDoc;
                    this.templates[templateKey] =
                        templateDoc.document_name + " - [Revision][" + templateDoc.revision + "]";
                }
            }.bind(this)
        );

        this.$el.find("[name=template]").select2(this.getSelect2Options());
        this.updateView();

        this.$el.find("[name=loadingSpinner]").remove();
    },

    /**
     * Description
     * @method handleParamsChange
     * @param {} event
     * @return
     */
    handleParamsChange: function (event) {
        // update the data in the main model
        this.actionParameters.document[event.currentTarget.name] = this.templateDocs[event.currentTarget.value];

        if (this.templateDocs[event.currentTarget.value].file_ext === "xlsx") {
            this.$el.find("[name=\"mergeType\"]").select2("val", "excel");
            this.handleMergeTypeChange({
                currentTarget: {
                    value: "excel"
                }
            });
        } else {
            this.$el.find("[name=\"mergeType\"]").select2("val", "docx");
            this.handleMergeTypeChange({
                currentTarget: {
                    value: "docx"
                }
            });
        }

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method handleMergeTypeChange
     * @param {} event
     * @return
     */
    handleMergeTypeChange: function (event) {
        if (Object.keys(this.actionParameters.document).length > 0 && ((event.currentTarget.value === "excel" 
        && this.actionParameters.document.template.file_ext !== "xlsx")
        || (
            (event.currentTarget.value !== "excel" 
        && this.actionParameters.document.template.file_ext === "xlsx")
        ))) {
            this.$el.find("[name=\"mergeType\"]").select2("val", this.actionParameters.mergeType);

            var errorMsg = "Please select Excel";

            if (event.currentTarget.value !== "excel") {
                errorMsg = "Please select Docx or PDF";
            }            

            app.alert.show("wrb-merge-error", {
                level     : "error",
                messages  : "Invalid merge type! " + errorMsg,
                autoClose : true
            });
        } else {
            this.actionParameters.mergeType = event.currentTarget.value;
            this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        }
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);
        this.updateView();
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        // update the view with the data came from the main model
        var doc = this.actionParameters.document.template;

        if (this.actionParameters.document.template) {
            var value = doc.document_name ? doc.document_name : "DefaultTemplate.docx";

            this.currentSelectedTemplate = value;

            this.$el.find("[name=\"template\"]").select2("val", value);
        } else {
            this.$el.find("[name=\"template\"]").select2("data", {
                id   : "selectTemplate",
                text : "Select Template"
            });
        }

        this.$el.find("[name=\"mergeType\"]").select2("val", this.actionParameters.mergeType);
    }
});
