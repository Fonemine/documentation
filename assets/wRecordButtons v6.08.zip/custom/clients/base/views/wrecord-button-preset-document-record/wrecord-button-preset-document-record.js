/**
 * Class Description
 *
 * @class wrecord-button-preset-document-record
 */
({
    extendsFrom : "CreateView",
    parentView  : null,

    /**
   * Description
   * @method initialize
   * @param {} options
   * @return
   */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.parentView = this.options.context.get("parentView");

        return initResult;
    },

    _render: function () {
        this.prepareModel();

        // rearrange view
        var faultyFields = [
            "filename",
            "follow",
            "favorite",
            "document_name",
            "related_doc_name",
            "related_doc_rev_number",
            "last_rev_created_name",
            "last_rev_create_date",
            "status"
        ];
        var fieldsToRemove = [];

        // get the faulty fields
        _.each(this.meta.panels, function searchForFaultyFields(
            panel,
            panelIndex
        ) {
            _.each(panel.fields, function removeFaultyField(field, fieldIndex) {
                if (
                    field &&
                    field.name &&
                    _.contains(faultyFields, field.name)
                ) {
                    fieldsToRemove.unshift({
                        fieldIndex : fieldIndex,
                        panelIndex : panelIndex
                    });
                }
            });
        });

        // remove the faulty fields
        for (var i = 0; i < fieldsToRemove.length; i++) {
            this.meta.panels[fieldsToRemove[i].panelIndex].fields.splice(
                fieldsToRemove[i].fieldIndex,
                1
            );
        }

        // add the proper fields
        this.meta.panels[0].fields.push({
            label : "LBL_DOCUMENT_NAME",
            name  : "document_name",
            type  : "text"
        });
        this.meta.panels[1].fields.unshift({
            label : "LBL_DOC_TYPE",
            name  : "doc_type",
            type  : "enum"
        });
        this.meta.panels[1].fields.unshift({
            label : "LBL_DOC_STATUS",
            name  : "status_id",
            type  : "enum"
        });

        this._super("_render");
        this.prepareView();
    },

    /**
   * Description
   * @method prepareModel
   * @return
   */
    prepareModel: function () {
        var self = this;
        var presetAttributes = _.clone(
            this.parentView.actionParameters.recordAttributes
        );

        // taking care of the custom fields
        _.each(presetAttributes, function cleanFieldsData(
            attributeData,
            attributeKey
        ) {
            // handling the wAttachmentsField
            if (
                self.model.fields[attributeKey] &&
                self.model.fields[attributeKey].type === "wAttachmentsField"
            ) {
                presetAttributes[attributeKey] = window.atob(attributeData);
            }
        });
        this.model.set(presetAttributes);
    },

    /**
   * Description
   * @method prepareView
   * @return
   */
    prepareView: function () {
        this.toggleEdit(true);
    },

    /**
   * Description
   * @method saveAndClose
   * @return
   */
    saveAndClose: function () {
        this.toggleEdit(false);
        this.parentView.presetDone(this.model);
        app.drawer.close(this.context, this.model);
    },

    /**
   * Description
   * @method cancel
   * @return
   */
    cancel: function () {
        //Clear unsaved changes on cancel.
        this.toggleEdit(false);
        app.events.trigger("create:model:changed", false);
        this.$el.off();
        app.drawer.close(this.context);
        this._dismissAllAlerts();
    }
});
