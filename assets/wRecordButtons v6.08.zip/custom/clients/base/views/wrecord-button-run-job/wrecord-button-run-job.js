/**
 * Class Description
 *
 * @class wrecord-button-run-job
 */
({
    events: {
        "change [name=jobField]": "handleParamsChange"
    },

    actionParameters: {
        jobField : "",
        jobName  : ""
    },

    jobFields: {},

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            jobField : "",
            jobName  : ""
        };

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.$el.find("[name=jobField]").select2(this.getSelect2Options());
        this.updateView();

        return renderResult;
    },

    /**
     * Description
     * @method handleParamsChange
     * @param {} event
     * @return
     */
    handleParamsChange: function (event) {
        // update the data in the main model
        this.actionParameters[event.currentTarget.name] = event.currentTarget.value;
        this.actionParameters.jobName = this.jobFields[this.actionParameters.jobField];
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);
        this.updateView();
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        var jobText = this.jobFields[this.actionParameters.jobField]
            ? this.jobFields[this.actionParameters.jobField]
            : "Select Job";

        this.$el.find("[name=\"jobField\"]").select2("data", {
            id   : this.actionParameters.jobField,
            text : jobText
        });
    },

    /**
     * Description
     * @method getSelect2Options
     * @return select2Options
     */
    getSelect2Options: function () {
        this.jobFields = this.layout.layout.model.get("jobsList");

        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_WRB_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this._query, this);
        select2Options.selectOnBlur = true;

        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstIcon, secondIcon) {
                if (firstIcon.text < secondIcon.text) {
                    return -1;
                }

                if (firstIcon.text > secondIcon.text) {
                    return 1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _query: function (query) {
        var jobFields = this.jobFields;
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(jobFields)) {
            _.each(jobFields, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({ id: index, text: text });
                }
            });
        } else {
            jobFields = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) {
        var data = [];
        var values = this.currentSelectedTemplate;

        _.each(
            _.pick(this.jobFields, values),
            function pushEntries(value, key) {
                data.push({ id: key, text: value });
            },
            this
        );

        if (data.length === 1) {
            callback(data[0]);
        } else {
            callback(data);
        }
    }
});
