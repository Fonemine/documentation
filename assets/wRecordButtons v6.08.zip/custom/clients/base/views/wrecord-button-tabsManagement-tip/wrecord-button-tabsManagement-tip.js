({
    initialize: function(options) {
        var initResult = this._super("initialize", arguments);

        return initResult;
    },

    render: function() {
        var renderResult = this._super("render", arguments);

        return renderResult;
    }
});
