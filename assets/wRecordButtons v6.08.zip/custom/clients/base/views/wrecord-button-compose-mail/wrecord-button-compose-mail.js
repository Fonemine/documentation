/**
 * Class Description
 *
 * @class wrecord-button-compose-mail
 */
({
    emailTemplateName       : "none",
    emailTemplatesListField : null,
    linkTypes               : {},
    actionParameters        : {
        emailTemplate     : "",
        emailTemplateName : "none",
        usePMSETemplates  : false,
        emailToField      : false,
        linkRecord        : false,
        linkType          : "",
        emailToData       : {
            formulaElement    : "",
            validationMessage : "",
            validFormula      : false
        }
    },
    emailToFormulaContainer: null,

    events: {
        "change [name=usePMSETemplates]" : "handleCheckboxChange",
        "change [name=emailToField]"     : "handleEmailToChange",
        "change [name=linkRecord]"       : "handleLinkCheckboxChange",
        "change [name=linkType]"         : "handleCheckboxParamsChange",
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            emailTemplate     : "",
            emailTemplateName : "none",
            usePMSETemplates  : false,
            emailToField      : false,
            emailToData       : {
                formulaElement    : "",
                validationMessage : "",
                validFormula      : false
            }
        };
        this.emailToFormulaContainer = null;

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.$el.find("[name=linkType]").select2(this.getCustomSelect2Options("LinkTypes", false));
        this.createEmailTemplateField("email_templates", "EmailTemplates", "emailTemplateField");
        this.createEmailTemplateField("pmse_emails_templates", "pmse_Emails_Templates", "pmseEmailTemplateField");

        this.updateView();

        return renderResult;
    },

    handleCheckboxChange: function (event) {
        this.actionParameters.usePMSETemplates = event.currentTarget.checked;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        this.prepareView();
    },

    handleLinkCheckboxChange: function(event){
        this.actionParameters[event.currentTarget.name] = event.currentTarget.checked;
    
        if (event.currentTarget.name === "linkRecord") {
            this.handleLinkWidget(event.currentTarget.checked);
        }
        this.resetLinkWidget();
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    
    },

    /**
     * Description
     * @method getCustomSelect2Options
     * @param {} optionsType
     * @param {} getModules
     * @return select2Options
     */
    getCustomSelect2Options: function (optionsType, getModules) {
        var layoutModel = this.layout.layout.model;

        if (getModules) {
            var modules = layoutModel.get("modules");
            var hiddenModules = layoutModel.get("hiddenModules");

            var fullModulesList = {};

            // get the hidden modules list
            _.each(hiddenModules, function createCompleteModulesList(module) {
                fullModulesList[module] = app.lang.getModuleName(module);
            });

            // compute the correct modules
            _.each(modules, function correctModuleName(module) {
                fullModulesList[module] = app.lang.getModuleName(module);
            });

            this.moduleTypes = fullModulesList;
        }

        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query" + optionsType], this);
        select2Options.selectOnBlur = true;

        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _queryLinkTypes: function (query) {
        var listName = "linkTypes";
        this._query(query, listName);
    },

    _initSelection: function ($ele, callback) {
        var data = [];
        var values = this.currentSelectedTemplate;

        _.each(
            _.pick(this.moduleTypes, values),
            function pushEntries(value, key) {
                data.push({
                    id   : key,
                    text : value
                });
            },
            this
        );

        if (data.length === 1) {
            callback(data[0]);
        } else {
            callback(data);
        }
    },

    _query: function (query, listName) {
        var listEntry = this[listName];
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listEntry)) {
            _.each(listEntry, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listEntry = null;
        }

        query.callback(data);
    },

    handleLinkWidget: function(showWidget){
        if (showWidget) {
            this.$el.find(".linkType").show();
            this.populateRelationships();
            
        } else {
            this.$el.find(".linkType").hide();
        }
    },

    resetLinkWidget: function () {
        this.actionParameters.linkType = "";
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        // set default or saved values for the elements in this view
        this.$el.find("[name=\"linkType\"]").select2("data", {
            id   : this.actionParameters.linkType,
            text : "Select Link"
        });
    },

    prepareView: function () {
        this.$el.find("#emailTemplateHeader").hide();
        this.$el.find("#emailTemplateField").hide();
        this.$el.find("#pmseEmailTemplateHeader").hide();
        this.$el.find("#pmseEmailTemplateField").hide();

        if (this.actionParameters.usePMSETemplates) {
            this.$el.find("#pmseEmailTemplateHeader").show();
            this.$el.find("#pmseEmailTemplateField").show();
        } else {
            this.$el.find("#emailTemplateHeader").show();
            this.$el.find("#emailTemplateField").show();
        }
    },

    /**
     * Description
     * @method handleParamsChange
     * @param {} eMailTemplate
     * @return
     */
    handleParamsChange: function (eMailTemplate) {
        // update the data in the main model
        var selectEmailTemplateEl = this.$el.find("#emailTemplateField .edit a span");
        var selectPMSEEmailTemplateEl = this.$el.find("#pmseEmailTemplateField .edit a span");
        var selectEmailTemplate = app.lang.get("LBL_SELECT_EMAIL_TEMPLATE");
        var selectPMSEEmailTemplate = app.lang.get("LBL_SELECT_PMSE_EMAIL_TEMPLATE");

        if (eMailTemplate && eMailTemplate.get("id") !== "") {
            eMailTemplate = eMailTemplate.attributes;
            this.actionParameters.emailTemplate = eMailTemplate.id;
            this.actionParameters.emailTemplateName = eMailTemplate.name;
            this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        } else if (eMailTemplate.changed.id === "" && eMailTemplate.changed.name === ""){
            eMailTemplate = eMailTemplate.attributes;
            this.actionParameters.emailTemplate = eMailTemplate.id;
            this.actionParameters.emailTemplateName = eMailTemplate.name;
            this.options.parentView.modifyActionData(_.clone(this.actionParameters));

            selectEmailTemplateEl.first().text(selectEmailTemplate);
            selectPMSEEmailTemplateEl.first().text(selectPMSEEmailTemplate);
        } else {
            selectEmailTemplateEl.first().text(selectEmailTemplate);
            selectPMSEEmailTemplateEl.first().text(selectPMSEEmailTemplate);
        
        }
    },

    handleCheckboxParamsChange: function (event) {
        // update the data in the main model
        this.actionParameters[event.currentTarget.name] = event.currentTarget.value;

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        if (!parameters.emailToData) {
            parameters.emailToData = {
                formulaElement    : "",
                validationMessage : "",
                validFormula      : false
            };
            parameters.emailToField = false;
        }

        this.actionParameters = _.clone(parameters);
        
        if (!this.actionParameters.linkType) {
            this.actionParameters.linkType = "";
        }
        this.populateRelationships();
        this.updateView();
    },

    populateRelationships: function () {
        var currentModuleName = this.options.manager.model.get("moduleName");
        var currentModuleFields = app.metadata.getModule(currentModuleName).fields;
        var relationships = {};
        
        _.each(currentModuleFields, function getLinks(linkData) {
            if (linkData.type == "link" && linkData.module === "Emails") {
                //eslint-disable-next-line
                relationships[linkData.name] = App.lang.get(linkData.vname, currentModuleName) + " (" + linkData.name + ")";
            }
        }.bind(this));

        this.linkTypes = relationships;
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        var targetField = this.actionParameters.usePMSETemplates ? this["pmseEmailTemplateField"] : this["emailTemplateField"];

        targetField.setValue({
            name : this.actionParameters.emailTemplateName,
            id   : this.actionParameters.emailTemplate
        });
       
        this.$el.find("[name=\"usePMSETemplates\"]").prop("checked", this.actionParameters.usePMSETemplates);

        this.$el.find("[name=\"emailToField\"]").prop("checked", this.actionParameters.emailToField);

        var hasLinkSelected = this.actionParameters.linkType !== "";
        var linkType = hasLinkSelected ? this.actionParameters.linkType : "Select Link";

        // set default or saved values for the elements in this view
        this.$el.find("[name=\"linkType\"]").select2("data", {
            id   : this.actionParameters.linkType,
            text : this.linkTypes[linkType] || linkType
        });

        this.handleLinkWidget(this.actionParameters.linkRecord === true);

        this.$el.find("[name='linkRecord']").prop("checked", this.actionParameters.linkRecord === true);

        this.prepareView();

        if (this.actionParameters.emailToField === true) {
            if (this.emailToFormulaContainer === null) {
                this.createEmailToView("wrecord-button-dependency-formula");
                this.emailToFormulaContainer.render();
            }

            this.emailToFormulaContainer.setParameters(this.actionParameters.emailToData);
        } else if (this.actionParameters.emailToField === false) {
            this.deleteEmailToView();
        }
    },

    deleteEmailToView: function () {
        this.options.manager.trigger("clean-button-" + this.options.buttonId);
        this.options.manager.trigger("clean-button-" + this.options.buttonId + "-generalSettings");

        if (this.emailToFormulaContainer !== null) {
            this.emailToFormulaContainer.remove();
            this.emailToFormulaContainer = null;
        }
    },

    handleEmailToChange: function (event) {
        if (event.currentTarget.checked === true) {
            this.createEmailToView("wrecord-button-dependency-formula");
            this.emailToFormulaContainer.render();
            this.emailToFormulaContainer.setParameters(this.actionParameters.emailToData);
        } else {
            this.deleteEmailToView();
        }

        this.actionParameters.emailToField = event.currentTarget.checked;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method changeButtonData
     * @param {} dataType
     * @param {} dataValue
     * @return
     */
    changeButtonData: function (dataType, dataValue, silent) {
        if (!silent) {
            silent = false;
        }

        if (dataType === "dependencyData") {
            dataType = "emailToData";
        }

        this.actionParameters[dataType] = dataValue;

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method createEmailToView
     * @param {} actionType
     * @return
     */
    createEmailToView: function (actionType) {
        // delete the existing view
        this.deleteEmailToView();

        // create the new udpated one
        var model = new Backbone.Model({});
        this.emailToFormulaContainer = App.view.createView({
            name           : actionType,
            model          : model,
            parentView     : this,
            layout         : this.layout,
            selectedModule : "Home",
            buttonId       : this.options.buttonId,
            manager        : this.options.manager,
        });

        this.$el.find(".emailToFormulaContainer").append(this.emailToFormulaContainer.$el);
    },

    /**
     * Description
     * @method templateDrawerCallback
     * @param {} eMailTemplate
     * @return
     */
    templateDrawerCallback: function (eMailTemplate) {
        this.handleParamsChange(eMailTemplate);
    },

    /**
     * Description
     * @method createEmailTemplateField
     * @return
     */
    createEmailTemplateField: function (tableName, moduleName, fieldId) {
        var emailTemplateModel = app.data.createBean(moduleName);
        var emailTemplateDef = {
            type    : "relate",
            vname   : "Email Templates",
            table   : tableName,
            source  : "non-db",
            module  : moduleName,
            //eslint-disable-next-line camelcase
            id_name : "id",
            name    : "name"
        };

        this[fieldId] = app.view.createField({
            meta: {
                view: "edit"
            },
            view     : this,
            model    : emailTemplateModel,
            module   : moduleName,
            def      : emailTemplateDef,
            viewName : "edit"
        });

        this[fieldId].render();
        this.$el.find("#" + fieldId).append(this[fieldId].$el);
        this[fieldId].model.on("change", this.templateDrawerCallback.bind(this));
    },

    /**
     * Description
     * @method setCorruptedFeedback
     * @return
     */
    setCorruptedFeedback: function () {
        if (this.emailToFormulaContainer) {
            this.emailToFormulaContainer.$el.find("#emailToFormulaTooltip").css("border", "1px solid red");
        }
    },

    /**
     * Description
     * @method setCleanFeedback
     * @return
     */
    setCleanFeedback: function () {
        if (this.emailToFormulaContainer) {
            this.emailToFormulaContainer.$el.find("#emailToFormulaTooltip").css("border", "");
        }
    },
});