/**
 * Class Description
 *
 * @class wrecord-button-create-record
 */
({
    events: {
        "change [name=recordType]"        : "moduleChanged",
        "change [name=linkRecord]"        : "handleCheckboxChange",
        "change [name=autoCreate]"        : "handleCheckboxChange",
        "change [name=linkType]"          : "handleParamsChange",
        "change [name=copyParentValues]"  : "handleCheckboxChange",
        "click #presetButton"             : "openCreateView",
        "click #populateFromParentButton" : "addFieldPopulatedFromParent"
    },

    moduleTypes       : {},
    linkTypes         : {},
    fieldTypes        : {},
    fieldsViews       : {},
    presetFields      : {},
    parentContainerId : "",

    actionParameters: {
        recordType           : "",
        linkType             : "",
        linkRecord           : false,
        copyParentValues     : false,
        recordAttributes     : {},
        attributesFromParent : {},
        defaultAttributes    : false,
        autoCreate           : false
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            recordType           : "",
            linkType             : "",
            linkRecord           : false,
            copyParentValues     : false,
            recordAttributes     : {},
            attributesFromParent : {},
            defaultAttributes    : false,
            executeView          : this.name,
            autoCreate           : false
        };

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .hide();

        // convert them to select2
        this.$el.find("[name=recordType]").select2(this.getCustomSelect2Options("ModuleTypes", true));
        this.$el.find("[name=linkType]").select2(this.getCustomSelect2Options("LinkTypes", false));

        this.updateView();

        return renderResult;
    },

    execute: function (buttonData, forceCompleteExecution) {
        if (app.acl.hasAccess("edit", buttonData.actionParameters.recordType)) {
            var recordType = buttonData.actionParameters.recordType;
            var createViewModel = app.data.createBean(recordType);
            var recordAttributes = _.clone(buttonData.actionParameters.recordAttributes);
            var self = this;

            // check if the record is linked so we know if we create a linked record or not
            if (buttonData.actionParameters.linkRecord === true) {
                if (this.model == null) {
                    this.model = this.view.model;
                }
                var relation = _.filter(this.model.fields, function getLinks(val) {
                    return val.type == "link" && val.module === recordType;
                });

                var link = buttonData.actionParameters.linkType;

                if (link === "" || !link) {
                    link = relation[relation.length - 1] ?
                        relation[relation.length - 1].name :
                        recordType.toLowerCase();
                }

                if (this.model.module == "Contracts" && link == "documents") {
                    link = "contracts_documents";
                }

                var isQuotesCreation = buttonData.actionParameters.recordType === "Products";

                var moduleToVerify = isQuotesCreation ? "ProductBundles" : this.module;
                var modelToVerify = isQuotesCreation && this.view.model.get("bundles") ? this.view.model.get("bundles").models[0] : this.model;

                if (this.view.name === "quote-data-group-list") {
                    modelToVerify = isQuotesCreation ? this.view.model : this.model;
                }

                if (app.metadata.getModule(moduleToVerify).fields[link]) {
                    var isInCreateView = false;
                    
                    // eslint-disable-next-line max-depth
                    if (app.controller.context && app.controller.context.parent) {
                        isInCreateView = app.controller.context.parent.get("create");
                        app.controller.context.parent.set("create", false);
                    }

                    createViewModel = this.createLinkModel(modelToVerify, link);

                    // eslint-disable-next-line max-depth
                    if (app.controller.context && app.controller.context.parent) {
                        app.controller.context.parent.set("create", isInCreateView);
                    }
                } else {
                    buttonData.actionParameters.linkRecord = false;
                }
            }

            if (
                buttonData.actionParameters.recordAttributes.assigned_user_id === "" ||
                buttonData.actionParameters.recordAttributes.assigned_user_id === undefined
            ) {
                // preset current user as the assigned user
                createViewModel.set("assigned_user_id", app.user.id);
                createViewModel.set("assigned_user_name", app.user.get("full_name"));
            }

            if (buttonData.actionParameters.copyParentValues === true) {
                if (forceCompleteExecution) {
                    var parentModelAttributes = JSON.parse(JSON.stringify(self.model.attributes));
                    
                    delete parentModelAttributes._acl;

                    createViewModel.set(parentModelAttributes);
                } else {
                    // eslint-disable-next-line max-depth
                    if (!self.model) {
                        self.model = self.options.model;
                    }
                    self.model.fetch({
                        success: function () {
                            var executeViewName = self.getExecuteViewName(buttonData);
                            self.callExecuteFunction(executeViewName, [buttonData, true]);
                        }
                    });

                    return false;
                }
            }

            var attributesFromParent = buttonData.actionParameters.attributesFromParent ?
                buttonData.actionParameters.attributesFromParent : {};
            var hasAttributesFromParent = Object.keys(attributesFromParent).length > 0;

            if (!forceCompleteExecution && hasAttributesFromParent) {
                self.model.fetch({
                    success: function () {
                        var executeViewName = self.getExecuteViewName(buttonData);
                        self.callExecuteFunction(executeViewName, [buttonData, true]);
                    }
                });
                return false;
            }

            // taking care of the custom fields
            _.each(recordAttributes, function cleanFieldsData(attributeData, attributeKey) {
                // handling the wAttachmentsField
                if (
                    createViewModel.fields[attributeKey] &&
                    createViewModel.fields[attributeKey].type === "wAttachmentsField"
                ) {
                    recordAttributes[attributeKey] = window.atob(attributeData);
                }
            });

            // add the preset values from the studio
            createViewModel.set(recordAttributes);

            var forceParentTypeCopy = false;

            if (forceCompleteExecution === true) {
                var fieldsToBeCleanedFromModel = [];

                _.each(attributesFromParent, function fixRelatedFields(fieldData, fieldUID) {
                    var cFieldData = createViewModel.fields[fieldData.currentRecordField];
                    var pFieldData = self.model.fields[fieldData.parentRecordField];
                    var cFieldName = false;
                    var pFieldName = false;

                    if (cFieldData && cFieldData.type === "id") {
                        if (cFieldData.link) {
                            cFieldName = cFieldData.link + "_name";
                        } else {
                            var cRFieldNameData = _.filter(createViewModel.fields, function getRelField(relFieldData) {
                                return relFieldData["id_name"] === fieldData.currentRecordField;
                            })[0];

                            if (cRFieldNameData) {
                                cFieldName = cRFieldNameData.name;
                            }
                        }
                    }

                    if (pFieldData && pFieldData.type === "id") {
                        if (pFieldData.link) {
                            pFieldName = pFieldData.link + "_name";
                        } else {
                            var pRFieldNameData = _.filter(self.model.fields, function getRelField(relFieldData) {
                                return relFieldData["id_name"] === fieldData.parentRecordField;
                            })[0];

                            if (pRFieldNameData) {
                                pFieldName = pRFieldNameData.name;
                            }
                        }
                    }

                    if (cFieldName && pFieldName) {
                        attributesFromParent[cFieldName + pFieldName] = {
                            currentRecordField : cFieldName,
                            parentRecordField  : pFieldName
                        };
                    } else {
                        var _cFieldID = false;
                        var _cFieldName = false;
                        var _pFieldID = false;
                        var _pFieldName = false;
                        
                        if (cFieldData && cFieldData.type === "relate") {
                            _cFieldName = cFieldData.name;
                            _cFieldID = cFieldData.id_name;
                        }

                        if (cFieldData && cFieldData.type === "link") {
                            _cFieldName = cFieldData.name + "_name";
                            _cFieldID = cFieldData.id_name;
                        }

                        if (pFieldData && pFieldData.type === "relate") {
                            _pFieldName = pFieldData.name;
                            _pFieldID = pFieldData.id_name;
                        }

                        if (pFieldData && pFieldData.type === "link") {
                            _pFieldName = pFieldData.name + "_name";
                            _pFieldID = pFieldData.id_name;
                        }

                        if (_cFieldID && _cFieldName && _pFieldID && _pFieldName) {
                            attributesFromParent[_cFieldID + _pFieldID] = {
                                currentRecordField : _cFieldID,
                                parentRecordField  : _pFieldID
                            };
                            attributesFromParent[_cFieldName + _pFieldName] = {
                                currentRecordField : _cFieldName,
                                parentRecordField  : _pFieldName
                            };

                            fieldsToBeCleanedFromModel.push(fieldUID);
                        }
                    }
                });

                _.each(fieldsToBeCleanedFromModel, function cleanParentFields(brokenFieldName){
                    delete attributesFromParent[brokenFieldName];
                });

                fieldsToBeCleanedFromModel = [];

                _.each(attributesFromParent, function setAttributesOnRecord(attributesData) {
                    if (attributesData.currentRecordField === "parent_id" || attributesData.currentRecordField === "parent_name") {
                        forceParentTypeCopy = true;
                    }
                    if (self.model.get(attributesData.parentRecordField) !== undefined) {
                        createViewModel.set(
                            attributesData.currentRecordField,
                            self.model.get(attributesData.parentRecordField)
                        );
                    }

                    var currentParentField = self.model.fields[attributesData.parentRecordField];
                    if (currentParentField && currentParentField.type === "relate") {
                        var groupField = self.model.fields[currentParentField.id_name].group;

                        if (groupField) {
                            createViewModel.set(groupField, self.model.get(groupField));
                        }
                        createViewModel.set(currentParentField.id_name, self.model.get(currentParentField.id_name));
                    } else if (currentParentField && currentParentField.name === "parent_id") {
                        createViewModel.set(attributesData.currentRecordField, self.model.get("parent_id"));
                        //eslint-disable-next-line
                        createViewModel.attributes.parent_name = self.model.get("parent_name");
                    }
                });
            }

            // delete the id as this is a new model
            delete createViewModel.id;
            delete createViewModel.attributes.id;
            delete createViewModel.attributes.date_entered;
            delete createViewModel.attributes.date_modified;

            // kind of a hack in order to have a different view for the Documents Module
            var createLayout = recordType === "Documents" ? "wRecord-button-create-document" : "create";
     
            createViewModel.set("mustLinkRecord", buttonData.actionParameters.linkRecord);

            app.wRecordButtonsModel = createViewModel;

            var refreshViews = function refreshViews(linkedRecordId, mustLinkRecord) {
                if (buttonData.actionParameters.recordType === "Products") {
                    var targetQuoteLayout = false;

                    if (self.view.name === "quote-data-group-list") {
                        targetQuoteLayout = self.view.layout;
                    } else {
                        targetQuoteLayout = self.view.layout.getComponent("extra-info").getComponent("quote-data-list-groups").getComponent("quote-data-group");
                    }

                    if (targetQuoteLayout && mustLinkRecord) {
                        mustLinkRecord.set("position", targetQuoteLayout.collection.length);
                        targetQuoteLayout.addRowModel(mustLinkRecord);
                        targetQuoteLayout.trigger("quotes:line_nums:reset", targetQuoteLayout.groupId, targetQuoteLayout.collection);
                        mustLinkRecord.save();
                    }
                }
                self.refreshSubpanels(linkedRecordId, mustLinkRecord);
            }.bind(this);

            if (buttonData.actionParameters.autoCreate === true) {
                createViewModel.save(createViewModel.attributes, {
                    success: function(savedModel) {
                        var wRBModel = App.data.createBean("wRB");
                        
                        wRBModel.set("model", savedModel);
                        refreshViews(wRBModel, savedModel);

                        var recordName = savedModel.get("name");

                        if ((recordName === undefined || recordName === "") 
                        && typeof savedModel.get("full_name") == "string") {
                            recordName = savedModel.get("full_name");
                        }

                        app.alert.show("wrb-record-create-" + savedModel.get("id"), {
                            html     : true,
                            level    : "info",
                            title    : app.lang.getAppString("LBL_WRB_BUTTON_RECORDS_CREATED"),
                            messages : "<br><a href=\"" 
                            + app.utils.getSiteUrl() 
                            + "#"
                            + savedModel.module
                            + "/" 
                            + savedModel.get("id") 
                            + "\">" + recordName + "</a>",
                            autoClose: false,
                        });
                    }
                });
            } else {
                App.drawer.open({
                    layout  : createLayout,
                    context : {
                        forceParentTypeCopy   : forceParentTypeCopy,
                        isWRecordButtonCreate : true,
                        create                : true,
                        module                : recordType,
                        predefinedModel       : createViewModel
                    }
                },
                refreshViews.bind(this)
                );
            }

            delete app.wRecordButtonsModel;
        } else {
            this.showNoAccessAlert();
        }

        return true;
    },

    /**
     * Description
     * @method presetDone
     * @param {} model
     * @return
     */
    presetDone: function (model) {
        // show the new fields modified
        this.actionParameters.defaultAttributes = this.actionParameters.defaultAttributes || _.clone(model._defaults);
        delete this.actionParameters.defaultAttributes.status;
        var attributes = _.clone(model.attributes);
        var self = this;

        // clean the attributes
        _.each(this.actionParameters.defaultAttributes, function cleanAttributes(defaultValue, key) {
            if (
                !(key in attributes) ||
                (defaultValue === null && attributes[key] === null) ||
                attributes[key] == self.actionParameters.defaultAttributes[key] ||
                (attributes[key] !== null &&
                    attributes[key].constructor === Array &&
                    attributes[key].toString() === self.actionParameters.defaultAttributes[key].toString() &&
                    !(key in model.changed))
            ) {
                delete attributes[key];
            }
        });

        _.each(attributes, function cleanAttributes(value, key) {
            if (
                !(key in model.fields) ||
                value === null ||
                value === undefined ||
                value === "" ||
                key === "revenuelineitems" ||
                key === "_revenuelineitems-rel_exp_values" ||
                (model.fields[key].type === "wAttachmentsField" && value === "[]")
            ) {
                delete attributes[key];
            }

            // handle special cases like custom packages with custom fields
            // handling the wAttachmentsField
            if (model.fields[key] && model.fields[key].type === "wAttachmentsField" && value !== "[]") {
                attributes[key] = window.btoa(attributes[key]);
            }

        });

        // get rid of unused data
        delete attributes["records"];

        this.actionParameters.recordAttributes = attributes;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        this.addNewFieldInfo(attributes);
    },

    modifyParentPopulatedFieldsData: function (fieldViewID, currentRecordField, parentRecordField) {
        this.actionParameters.attributesFromParent[fieldViewID] = {
            currentRecordField : currentRecordField,
            parentRecordField  : parentRecordField
        };

        if (this.actionParameters.recordAttributes[currentRecordField]) {
            this.removeFieldInfo(false, currentRecordField);
        }

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    removeParentPopulatedFieldsData: function (fieldViewID, currentRecordField) {
        if (fieldViewID === false) {
            _.each(this.actionParameters.attributesFromParent, function getViewID(fields, viewID) {
                if (fields.currentRecordField === currentRecordField) {
                    fieldViewID = viewID;
                }
            });
        }

        if (this.actionParameters.attributesFromParent[fieldViewID]) {
            delete this.actionParameters.attributesFromParent[fieldViewID];
        }

        if (fieldViewID) {
            this.fieldsViews[fieldViewID].$el.remove();
            delete this.fieldsViews[fieldViewID];
        }

        if (Object.keys(this.fieldsViews).length <= 0) {
            this.$el.find("#presetParentInfoContainer").hide();
        }

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },
    /**
     * Description
     * @method addNewFieldInfo
     * @param {} attributes
     * @return
     */
    addNewFieldInfo: function (attributes) {
        var self = this;
        var container = this.$el.find("#presetInfoContainer");
        var module = this.actionParameters.recordType === "" ? "Accounts" : this.actionParameters.recordType;
        var moduleDef = App.metadata.getModule(module);
        var fieldsContainer = this.$el.find("#panelCollapserBody");
        fieldsContainer.empty();

        if (moduleDef) {
            var fieldsInfo = moduleDef.fields;

            _.each(attributes, function addField(fieldValue, fieldName) {
                if (fieldValue !== undefined && fieldValue !== null && fieldValue !== "") {
                    self.removeParentPopulatedFieldsData(false, fieldName);
                    var removeFieldButton = fieldName;

                    // handle different field types
                    if (fieldName === "email") {
                        var emails = [];

                        for (var i = 0; i < fieldValue.length; i++) {
                            emails.push(fieldValue[i].email_address);
                        }

                        fieldValue = emails;
                    } else if (fieldName === "tag") {
                        var tags = [];

                        for (var tagIndex = 0; tagIndex < fieldValue.length; tagIndex++) {
                            tags.push(fieldValue[tagIndex]);
                        }

                        fieldValue = tags;
                    } else if (fieldName === "team_name") {
                        var teams = [];

                        for (var teamIndex = 0; teamIndex < fieldValue.length; teamIndex++) {
                            teams.push(fieldValue[teamIndex].name);
                        }

                        fieldValue = teams;
                    } else if (typeof fieldValue == "object") {
                        fieldValue = "Custom Value";
                    } else if (!fieldsInfo[fieldName]) {
                        fieldValue = "Custom Value";
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "datetimecombo") {
                        var dateValue = App.date(fieldValue);
                        fieldValue = dateValue.formatUser(false);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "currency") {
                        var indexOffset = 4;
                        fieldValue = fieldValue.toString();
                        fieldValue = fieldValue.substr(0, fieldValue.indexOf(".") + indexOffset);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "int") {
                        fieldValue = Math.round(fieldValue);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "date") {
                        var formatDate = App.date(fieldValue);

                        fieldValue = formatDate.formatUser(true);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "wAttachmentsField") {
                        fieldValue = "Custom Value";
                    }

                    // format the display text
                    if (fieldName.indexOf("_c") > -1 && !fieldsInfo[fieldName]) {
                        var fieldNameIndexOffset = 2;
                        fieldName = fieldName.substring(0, fieldName.indexOf("_c") + fieldNameIndexOffset);
                    }

                    // get the field label
                    var fieldLabel = fieldsInfo[fieldName] ? fieldsInfo[fieldName]["vname"] : fieldName;
                    var fieldDisplayText = App.lang.get(fieldLabel, self.actionParameters.recordType);

                    // if we do not have a translation for the field we should not show it as changed
                    if (
                        typeof fieldLabel != "undefined" && //Calls ->auto_invite_parent does not have a label
                        fieldDisplayText.indexOf("LBL###") < 0 &&
                        fieldDisplayText !== "next_offset"
                    ) {
                        if (fieldDisplayText.indexOf("_") > -1) {
                            fieldDisplayText = fieldDisplayText.substring(0, fieldDisplayText.indexOf("_"));

                            if (fieldsInfo[fieldDisplayText] && fieldsInfo[fieldDisplayText].vname) {
                                fieldDisplayText = App.lang.get(
                                    fieldsInfo[fieldDisplayText].vname,
                                    self.actionParameters.recordType
                                );
                            }
                        }
                        var presetFieldID = app.utils.generateUUID();
                        var baseFieldHtml =
                            "\
                                <tr id=\"#" +
                            presetFieldID +
                            "\">\
                                  <td  style=\"margin-left: 2.5%;width:365px;\">\
                                    <span style=\"margin-left: 2.5%;\">" +
                            fieldDisplayText +
                            "</span>\
                                  </td>\
                                  <td style=\"margin-left: 2.5%;width:365px;\"> \
                                    <span style=\"margin-left: 2.5%;\">" +
                            fieldValue +
                            "</span>\
                                  </td>\
                                  <td style=\"margin-left: 2.5%;width:365px;\">\
                                    <a class=\"btn removeFieldInfo\" name=\"" +
                            removeFieldButton +
                            "\"   id =\"removeFieldInfo\" >\
                                      <i class=\"fa fa-times\"></i>\
                                    </a>\
                                  </td>\
                                </tr>";

                        self.presetFields[fieldName] = presetFieldID;
                        fieldsContainer.append(baseFieldHtml);
                    }
                }
            });
        }

        this.$el.find(".removeFieldInfo").click(this.removeFieldInfo.bind(this));

        if (Object.keys(attributes).length <= 0) {
            container.hide();
        } else {
            container.show();
        }
    },

    /**
     * Description
     * @method removeFieldInfo
     * @param {} event
     * @return
     */
    removeFieldInfo: function (event, strongFieldName) {
        // get field name
        var fieldName = event === false ? strongFieldName : event.currentTarget.getAttribute("name");
        // remove field from data
        delete this.actionParameters.recordAttributes[fieldName];
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        if (this.presetFields[fieldName]) {
            delete this.presetFields[fieldName];
        }

        this.$el.find("#panelCollapserBody").empty();
        this.addNewFieldInfo(this.actionParameters.recordAttributes);
    },

    /**
     * Description
     * @method openCreateView
     * @return
     */
    openCreateView: function () {
        var createLayout =
            this.actionParameters.recordType === "Documents" ? "wrecord-button-preset-document-record" : "create";
        app.drawer.open({
            layout  : createLayout,
            context : {
                create                      : true,
                module                      : this.actionParameters.recordType,
                parentView                  : this,
                isWRecordButtonPresetCreate : true
            }
        });
    },

    addFieldPopulatedFromParent: function () {
        this.createFieldPopulatedFromParent();
    },

    createFieldPopulatedFromParent: function (currentRecordField, parentRecordField, viewID) {
        var container = this.$el.find("#parentFieldsBody");

        var model = new Backbone.Model({});
        var fieldViewID = viewID ? viewID : app.utils.generateUUID();

        var fieldView = app.view.createView({
            name               : "wrecord-button-populate-from-parent",
            model              : model,
            parentView         : this,
            layout             : this.layout,
            selectedModule     : "Home",
            currentRecordField : currentRecordField,
            parentRecordField  : parentRecordField,
            manager            : this.options.manager,
            fieldViewID        : fieldViewID,
            buttonId           : this.options.buttonId
        });

        fieldView.render();
        fieldView.$el.css("display", "table-row");
        fieldView.$el.css("background-color", "#F9F9F9");

        container.append(fieldView.$el);
        this.$el.find("#presetParentInfoContainer").show();
        this.fieldsViews[fieldViewID] = fieldView;

        return fieldViewID;
    },

    /**
     * Description
     * @method showPresetButton
     * @param {} visible
     * @return
     */
    showPresetButton: function (visible) {
        var functionToCall = visible ? "show" : "hide";

        this.$el.find("#presetButton")[functionToCall]();
        this.$el.find("#populateFromParentButton")[functionToCall]();
    },

    /**
     * Description
     * @method moduleChanged
     * @param {} event
     * @return
     */
    moduleChanged: function (event) {
        this.handleParamsChange(event);

        // reset values
        this.actionParameters.attributesFromParent = {};
        this.actionParameters.recordAttributes = {};
        this.actionParameters.defaultAttributes = false;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        this.addNewFieldInfo({});
        this.showPresetButton(true);
        this.populateRelationships();
        this.resetLinkWidget();
    },

    populateRelationships: function () {
        var currentModuleName = this.options.manager.model.get("moduleName");
        var currentModuleFields = app.metadata.getModule(currentModuleName).fields;
        var relationships = {};
        
        _.each(currentModuleFields, function getLinks(linkData) {
            // eslint-disable-next-line no-undef
            if (linkData.type == "link" && (App.lang.get(linkData.vname, currentModuleName) === this.actionParameters.recordType
             || linkData.module === this.actionParameters.recordType)) {
                //eslint-disable-next-line
                relationships[linkData.name] = App.lang.get(linkData.vname, currentModuleName)  + " (" + linkData.name + ")";
              
            } 
        }.bind(this));

        this.linkTypes = relationships;
    },

    resetLinkWidget: function () {
        this.actionParameters.linkType = "";
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        // set default or saved values for the elements in this view
        this.$el.find("[name=\"linkType\"]").select2("data", {
            id   : this.actionParameters.linkType,
            text : "Select Link"
        });
    },

    handleLinkWidget: function (showWidget) {
        if (showWidget) {
            this.$el.find(".linkType").show();
        } else {
            this.$el.find(".linkType").hide();
        }
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        var hasRecordSelected = this.actionParameters.recordType !== "";
        var recordType = hasRecordSelected ? this.actionParameters.recordType : "Select Module";

        // set default or saved values for the elements in this view
        this.$el.find("[name=\"recordType\"]").select2("data", {
            id   : this.actionParameters.recordType,
            text : recordType
        });

        var hasLinkSelected = this.actionParameters.linkType !== "";
        var linkType = hasLinkSelected ? this.actionParameters.linkType : "Select Link";

        // set default or saved values for the elements in this view
        this.$el.find("[name=\"linkType\"]").select2("data", {
            id   : this.actionParameters.linkType,
            text : this.linkTypes[linkType] || linkType
        });

        this.handleLinkWidget(this.actionParameters.linkRecord === true);
        
        this.$el.find("[name='linkRecord']").prop("checked", this.actionParameters.linkRecord === true);
        this.$el.find("[name='autoCreate']").prop("checked", this.actionParameters.autoCreate === true);
        this.$el.find("[name='copyParentValues']").prop("checked", this.actionParameters.copyParentValues === true);

        this.showPresetButton(hasRecordSelected);
        this.addNewFieldInfo(this.actionParameters.recordAttributes);
        this.addParentsFieldInfo(this.actionParameters.attributesFromParent || {});
    },

    addParentsFieldInfo: function (attributes) {
        var container = this.$el.find("#presetParentInfoContainer");
        this.$el.find("#parentFieldsBody").empty();

        _.each(
            attributes,
            function createViews(fields, viewID) {
                this.createFieldPopulatedFromParent(fields.currentRecordField, fields.parentRecordField, viewID);
            }.bind(this)
        );

        if (Object.keys(attributes).length <= 0) {
            container.hide();
        } else {
            container.show();
        }
    },

    /**
     * Description
     * @method getCustomSelect2Options
     * @param {} optionsType
     * @param {} getModules
     * @return select2Options
     */
    getCustomSelect2Options: function (optionsType, getModules) {
        var layoutModel = this.layout.layout.model;

        if (getModules) {
            var modules = layoutModel.get("modules");
            var hiddenModules = layoutModel.get("hiddenModules");

            var fullModulesList = {};

            // get the hidden modules list
            _.each(hiddenModules, function createCompleteModulesList(module) {
                fullModulesList[module] = app.lang.getModuleName(module);
            });

            // compute the correct modules
            _.each(modules, function correctModuleName(module) {
                fullModulesList[module] = app.lang.getModuleName(module);
            });

            this.moduleTypes = fullModulesList;
        }

        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query" + optionsType], this);
        select2Options.selectOnBlur = true;

        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _queryModuleTypes: function (query) {
        var listName = "moduleTypes";
        this._query(query, listName);
    },

    _queryLinkTypes: function (query) {
        var listName = "linkTypes";
        this._query(query, listName);
    },

    _query: function (query, listName) {
        var listEntry = this[listName];
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listEntry)) {
            _.each(listEntry, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listEntry = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) {
        var data = [];
        var values = this.currentSelectedTemplate;

        _.each(
            _.pick(this.moduleTypes, values),
            function pushEntries(value, key) {
                data.push({
                    id   : key,
                    text : value
                });
            },
            this
        );

        if (data.length === 1) {
            callback(data[0]);
        } else {
            callback(data);
        }
    },

    /**
     * Description
     * @method handleParamsChange
     * @param {} event
     * @return
     */
    handleParamsChange: function (event) {
        // update the data in the main model
        this.actionParameters[event.currentTarget.name] = event.currentTarget.value;

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method handleCheckboxChange
     * @param {} event
     * @return
     */
    handleCheckboxChange: function (event) {
        this.actionParameters[event.currentTarget.name] = event.currentTarget.checked;

        if (event.currentTarget.name === "linkRecord") {
            this.handleLinkWidget(event.currentTarget.checked);
        }

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);

        if (!this.actionParameters.recordAttributes) {
            this.actionParameters.recordAttributes = {};
        }

        if (!this.actionParameters.attributesFromParent) {
            this.actionParameters.attributesFromParent = {};
        }

        if (!this.actionParameters.linkType) {
            this.actionParameters.linkType = "";
        }

        if (!this.actionParameters.executeView) {
            this.actionParameters.executeView = this.name;
        }

        this.populateRelationships();
        this.updateView();
    }
});