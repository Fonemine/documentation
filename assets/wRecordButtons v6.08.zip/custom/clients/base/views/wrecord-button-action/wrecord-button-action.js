/**
 * Class Description
 *
 * @class wrecord-button-action
 */
({
    events: {
        "change [name=action]"             : "handleActionChange",
        "click [name=tipButton]"           : "showTip",
        "click #removeActionButton"        : "removeAction",
        "click #panelToggleAction"         : "expandActionConfiguration",
        "change [name=executeImmediately]" : "handleCheckboxChange"
    },

    actionViewsMappingTable: {},

    actionsList          : {},
    action               : "doNothing",
    actionParameters     : {},
    actionParametersView : null,
    actionId             : null,
    collapseActionId     : null,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionViewsMappingTable = this.options.manager.actions;

        // set the action ID so we can recognize it
        this.actionId = this.options.actionIdentifier;

        this.collapseActionId = App.utils.generateUUID();

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return $el
     */
    render: function () {
        var $el = this._super("render");
        this.$el.addClass("tab-pane");

        this.$el.attr("id", this.actionId);

        // check if the tab is active and make it visible if so
        if (this.options.isActiveTab === true) {
            this.$el.addClass("active");
        }

        this.options.manager.on("corrupted-button-" + this.actionId, this.setCorruptedFeedback.bind(this));
        this.options.manager.on("clean-button-" + this.actionId, this.setCleanFeedback.bind(this));

        var actionDropdown = this.$el.find("[name=action]");

        actionDropdown.select2(this.getSelect2Options());

        return $el;
    },

    /**
     * Description
     * @method setCorruptedFeedback
     * @return
     */
    setCorruptedFeedback: function (fieldIdentifier) {
        this.$el.find(fieldIdentifier || "#appendedInputButtons").css("border", "1px solid red");
    },

    handleCheckboxChange: function (event) {
        this.executeImmediately = event.currentTarget.checked;
        this.modifyActionData(this.actionParameters);
    },

    /**
     * Description
     * @method setCleanFeedback
     * @return
     */
    setCleanFeedback: function (fieldIdentifier) {
        this.$el.find(fieldIdentifier || "#appendedInputButtons").css("border", "");
    },

    /**
     * Description
     * @method setParameters
     * @param {} actionId
     * @param {} actionData
     * @return
     */
    setParameters: function (actionId, actionData) {
        // set the saved params
        this.action = actionData.action;
        this.actionParameters = actionData.actionParameters;

        this.deleteParameterView();

        if (
            this.actionViewsMappingTable[this.action] &&
            this.actionViewsMappingTable[this.action]["viewName"] !== false
        ) {
            this.createActionParameterView(this.actionViewsMappingTable[this.action]["viewName"]);
            this.actionParametersView.render();
            this.actionParametersView.setParameters(this.actionParameters);
        }

        this.$el.find("[name=executeImmediately]").prop("checked", actionData.executeImmediately === true);

        this.$el.find("[name=action]").select2("data", {
            id   : this.action,
            text : this.actionsList[this.action]
        });
    },

    /**
     * Description
     * @method deleteParameterView
     * @return
     */
    deleteParameterView: function () {
        if (this.actionParametersView !== null) {
            this.options.manager.off("saving:record:buttons");
            this.options.manager.off("corrupted-button-" + this.actionId);
            this.options.manager.off("clean-button-" + this.actionId);
            this.actionParametersView.remove();
            this.actionParametersView = null;
        }
    },

    /**
     * Description
     * @method createActionParameterView
     * @param {} actionType
     * @return
     */
    createActionParameterView: function (actionType) {
        // delete the existing view
        this.deleteParameterView();

        // create the new udpated one
        var model = new Backbone.Model({});
        this.actionParametersView = App.view.createView({
            name           : actionType,
            model          : model,
            parentView     : this,
            layout         : this.layout,
            selectedModule : "Home",
            manager        : this.options.manager,
            buttonId       : this.options.buttonId,
            actionId       : this.actionId
        });

        this.$el.find("#actionViewContainer").append(this.actionParametersView.$el);
    },

    /**
     * Description
     * @method showTip
     * @param {} event
     * @return
     */
    showTip: function (event) {
        this.options.manager.showTip(this.action);
    },

    /**
     * Description
     * @method handleActionChange
     * @param {} event
     * @return
     */
    handleActionChange: function (event) {
        // when we change the action we need to create a new view for the params
        this.action = event.currentTarget.value;

        if (
            this.actionViewsMappingTable[this.action] &&
            this.actionViewsMappingTable[this.action]["viewName"] !== false
        ) {
            this.createActionParameterView(this.actionViewsMappingTable[this.action]["viewName"]);
            this.actionParametersView.render();
            this.actionParameters = _.clone(this.actionParametersView.actionParameters);
        } else {
            this.deleteParameterView();
        }

        this.modifyActionData(this.actionParameters);
    },

    /**
     * Description
     * @method modifyActionData
     * @param {} actionParams
     * @return
     */
    modifyActionData: function (actionParams) {
        // change the data into the main model
        this.actionParameters = actionParams;

        var actionData = {
            action             : this.action,
            executeImmediately : this.executeImmediately,
            actionParameters   : this.actionParameters
        };

        this.layout.changeActionData(this.actionId, actionData);
    },

    /**
     * Description
     * @method getSelect2Options
     * @return select2Options
     */
    getSelect2Options: function () {
        this.actionsList = {};

        _.each(
            this.actionViewsMappingTable,
            function createActionsList(actionMeta, actionKey) {
                this.actionsList[actionKey] = actionMeta.label;
            }.bind(this)
        );

        // if we have the wDocs package we can add the Merge Doc action
        if (
            (app.view.views.BaseCustomRecordView && app.view.views.BaseCustomRecordView.prototype.wDocsOverride) ||
            app.view.views.BaseRecordView.prototype.wDocsOverride
        ) {
            this.actionsList["mergeDocument"] = "Merge Document";
        } else {
            delete this.actionsList.mergeDocument;
        }

        // if the module is Leads we add the convert lead aciton
        if (this.layout.layout.model.get("moduleName") !== "Leads") {
            delete this.actionsList.convertLead;
        }

        // if we have the wDocs package we can add the Merge Doc action
        if (
            (app.view.views.BaseCustomRecordView &&
                app.view.views.BaseCustomRecordView.prototype.wMapsActionsOnRecordView) ||
            app.view.views.BaseRecordView.prototype.wMapsActionsOnRecordView
        ) {
            this.actionsList["handleRoute"] = "Manage wMaps Route";
            this.actionsList["map"] = "Bing Map";
            this.actionsList["nearby"] = "Nearby";
            this.actionsList["directions"] = "Directions";
        } else {
            delete this.actionsList.map;
            delete this.actionsList.handleRoute;
            delete this.actionsList.nearby;
            delete this.actionsList.directions;
        }

        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this._query, this);
        select2Options.selectOnBlur = true;

        return select2Options;
    },

    _query: function (query) {
        var listElements = this.actionsList;
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listElements)) {
            _.each(listElements, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listElements = null;
        }

        this.sortByProperty(data.results, "id");
        query.callback(data);
    },

    sortByProperty: function (array, propertyName, sortOrder) {
        sortOrder = sortOrder ? sortOrder : "ASC";
        return array.sort(
            function sortObj(obj1, obj2) {
                if (obj1[propertyName] < obj2[propertyName]) return sortOrder === "ASC" ? -1 : 1;

                if (obj1[propertyName] > obj2[propertyName]) return sortOrder === "ASC" ? 1 : -1;

                return 0;
            }.bind(this)
        );
    },

    _initSelection: function ($ele, callback) { },

    /**
     * Description
     * @method removeAction
     * @param {} e
     * @return
     */
    removeAction: function (e) {
        e.stopImmediatePropagation();
        var message = app.lang.get("LBL_WRB_REMOVE_ACTION_ALERT");
        app.alert.show("alert_delete_action", {
            level          : "confirmation",
            title          : "Warning",
            messages       : message,
            autoClose      : true,
            autoCloseDelay : 5000,
            onConfirm      : function removeButtonOnConfirm() {
                this.layout.removeButtonAction(this.actionId);
                this.$el.remove();
            }.bind(this)
        });
    },

    /**
     * Description
     * @method expandActionConfiguration
     * @return
     */
    expandActionConfiguration: function () {
        var chevronElement = this.$el.find("#expandActionConfiguration");

        this.expandActionConfiguration = !this.expandActionConfiguration;

        if (this.expandActionConfiguration) {
            chevronElement.children().addClass("fa-chevron-up");
            chevronElement.children().removeClass("fa-chevron-down");
        } else {
            chevronElement.children().removeClass("fa-chevron-up");
            chevronElement.children().addClass("fa-chevron-down");
        }
    }
});
