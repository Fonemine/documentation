/**
 * Class Description
 *
 * @class wrecord-button-updateField-tip
 */
({
    /**
   * Description
   * @method initialize
   * @param {} options
   * @return
   */
    initialize: function(options) {
        var initResult = this._super("initialize", arguments);

        return initResult;
    },

    /**
   * Description
   * @method render
   * @return
   */
    render: function() {
        var renderResult = this._super("render", arguments);

        return renderResult;
    }
});
