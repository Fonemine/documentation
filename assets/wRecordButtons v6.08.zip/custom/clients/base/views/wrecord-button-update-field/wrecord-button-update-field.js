/**
 * Class Description
 *
 * @class wrecord-button-update-field
 */
({
    events: {
        "change [name=fieldType]"                  : "handleFieldChange",
        "change [name=defaultValue]"               : "handleParamsChange",
        "change [name=moduleType]"                 : "handleModuleChange",
        "change [name=formulaElement]"             : "handleParamsChange",
        "change [name=calculatedField]"            : "handleCheckboxChange",
        "click [name=formulaElement]"              : "formulaElementClicked",
        "click [name=fieldsDropdownButton]"        : "showFieldsDropdown",
        "click [name=functionsDropdownButton]"     : "showFunctionsDropdown",
        "click [name=relatedFieldsDropdownButton]" : "showRelatedFieldsDropdown"
    },

    actionParameters: {
        fieldType           : "",
        moduleType          : "",
        formulaElement      : "",
        validationMessage   : "",
        defaultValue        : "",
        defaultValueText    : "",
        validFormula        : false,
        corruptedFieldValue : false,
        calculatedField     : false,
    },

    defaultValues           : {},
    relateFields            : {},
    calculatedFields        : {},
    fieldTypes              : {},
    relatedModules          : {},
    modulesList             : {},
    fieldRelatedTypes       : {},
    functionTypes           : {},
    functionsDescription    : {},
    validModules            : ["Users", "Accounts", "Campaigns"],
    allowedCalculatedFields : [
        "id",
        "name",
        "multienum",
        "enum",
        "Colorstatusfield",
        "text",
        "encrypt",
        "varchar",
        "relate",
        "datetimecombo",
        "datetime",
        "date",
        "email",
        "currency",
        "phone",
        "url",
        "checkbox",
        "decimal",
        "float",
        "int",
        "bool"
    ],
    allowedPresetFields: [
        "id",
        "name",
        "enum",
        "text",
        "varchar",
        "relate",
        "datetimecombo",
        "datetime",
        "date",
        "currency",
        "phone",
        "url",
        "checkbox",
        "decimal",
        "float",
        "int",
        "bool",
        "encrypt"
    ],
    dropdownOpened        : false,
    lastExpressionEntered : "",
    functionDescription   : "",
    currentParamNumber    : -1,

    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            fieldType           : "",
            moduleType          : "",
            formulaElement      : "",
            defaultValue        : "",
            defaultValueText    : "",
            validationMessage   : "",
            validFormula        : false,
            corruptedFieldValue : false,
        };

        // get the data we need form the main model
        this.relatedModules = this.options.manager.model.get("relatedModules");
        this.modulesList = this.getRelatedModulesList();

        this.initializeFieldsList(this.options.manager.model.get("moduleName"));

        this.defaultValues = {};
        this.functionsDescription = this.options.manager.model.get("functionsDescription");
        this.functionsDescription["getCurrentUser"] = "getCurrentUser() => Returns the current user Full Name";

        this.modulesList["1currentModule"] = "CURRENT RECORD";

        this.updateWidgetView();

        // get the list of functions we can use
        _.each(
            this.getDisplayFunctionList(),
            function getFieldName(functionData) {
                this.functionTypes[functionData[0]] = functionData[0];
            }.bind(this)
        );

        return initResult;
    },

    initializeFieldsList: function (moduleName) {
        this.fieldTypes = this.getCompleteFieldsList(moduleName);
    },

    getRelatedModulesList: function () {
        var moduleName = this.options.manager.model.get("moduleName");
        var modules = app.metadata.getModule(moduleName).fields;
        var relatedModules = {};

        _.each(
            modules,
            function clean(field) {
                if (!_.isUndefined(field.type) && field.type === "relate" && field.module && !field.readonly) {
                    var moduleLabel = App.lang.get(field.label || field.vname, moduleName);

                    if (!moduleLabel) {
                        moduleLabel = field.name;
                    }

                    var moduleKey = field.module + "__" + field.name.replace(/name/g, "id");
                    moduleLabel = moduleLabel.replace(/_/g, " ");

                    relatedModules[moduleKey] = moduleLabel;
                }
            },
            this
        );

        return relatedModules;
    },

    getCompleteFieldsList: function (module) {
        var self = this;
        var massUpdateFields = {};
        var relateFields = {};
        var calculatedFields = {};
        var fieldsMeta = [];
        var metadataModule = app.metadata.getModule(module);
        var fieldsList = metadataModule.fields;

        _.each(fieldsList, function clean(field) {
            // Remove blacklisted fields
            if (!field.name || !(field.label || field.vname)) {
                return;
            }

            if (
                _.contains(self.allowedCalculatedFields, field.type) ||
                _.contains(self.allowedPresetFields, field.type) ||
                (field.source && field.source === "custom_fields" && field.type === "multienum")
            ) {
                if (field.type !== "id" || (field.type === "id" && field.name !== "parent_id")) {
                    // split the fields in two separate lists - calculated/preset
                    if (_.contains(self.allowedCalculatedFields, field.type)) {
                        calculatedFields[field.name] = field;
                    }

                    if (_.contains(self.allowedPresetFields, field.type)) {
                        relateFields[field.name] = field;
                    }

                    var displayName = field.label || field.vname;
                    var canInsertField = true;

                    for (var i = 0; i < fieldsMeta.length; i++) {
                        var fieldDisplayName = fieldsMeta[i].label || fieldsMeta[i].vname;

                        // eslint-disable-next-line max-depth
                        if (fieldDisplayName === displayName) {
                            canInsertField = false;
                            break;
                        }
                    }

                    if (canInsertField) {
                        fieldsMeta.push(field);
                        massUpdateFields[field.name] = App.lang.get(displayName, module);
                    }
                }
            }
        });

        this.meta = {
            panels: []
        };
        this.meta.panels.push({});

        this.meta.panels[0]["fields"] = fieldsMeta;
        this.relateFields = relateFields;
        this.calculatedFields = calculatedFields;

        return massUpdateFields;
    },

    initializeTooltip: function () {
        // define the functions and events that we need for a proper tooltip
        var tooltipElement = this.$el.find("#appendedInputButtons");

        // when we move the cursor we want to try to show the tooltip
        tooltipElement.on(
            "keyup click focus",
            function showTooltip() {
                this.showTooltip();
            }.bind(this)
        );

        // initialize the tooltip
        tooltipElement.tooltip({
            title: function title() {
                return this.functionDescription;
            }.bind(this),
            trigger   : "manual",
            html      : true,
            container : "body"
        });

        // when the mouse leave the element we hide the tooltip
        tooltipElement.mouseleave(function hideTooltip() {
            tooltipElement.tooltip("hide");
            tooltipElement.data("tooltipVisible", false);
        });

        // when we scroll we hide the tooltip
        $(".main-pane").scroll(function hideTooltip() {
            tooltipElement.tooltip("hide");
            tooltipElement.data("tooltipVisible", false);
        });
    },

    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.$el.find("[name=DefaultValueFieldUI]").hide();
        this.$el.find("[name=CalculatedFieldUI]").hide();

        this.initializeTooltip();

        this.$el.find("[name=defaultValue]").select2(this.getSelect2Options("DefaultValue"));
        this.$el.find("[name=fieldType]").select2(this.getSelect2Options("FieldTypes"));

        // create the select dropdown for all the data we need
        this.createCustomSelect2Dropdown(
            ".moduleType",
            "ModuleTypes",
            null,
            this.populateRelatedModulesFields.bind(this),
            null,
            this.formatResultModules
        );
        this.createCustomSelect2Dropdown(
            ".fieldsList",
            "RelatedModules",
            this.addFieldToFormula.bind(this),
            this.populateRelatedFieldsList.bind(this),
            true
        );
        this.createCustomSelect2Dropdown(
            ".relatedFieldsList",
            "RelatedFields",
            this.addRelatedFieldToFormula.bind(this),
            null,
            true
        );
        this.createCustomSelect2Dropdown(
            ".functionsList",
            "Functions",
            this.addFunctionToFormula.bind(this),
            null,
            true
        );

        this.updateView();

        // when we unFocus the formula element we need to validate the expressions
        this.$el.find("[name=formulaElement]").blur(
            function isFormulaValid(event) {
                var tooltipElement = this.$el.find("#appendedInputButtons");
                tooltipElement.tooltip("hide");
                tooltipElement.data("tooltipVisible", false);

                var functionButtonPressed = this.$el.find("[name=functionsDropdownButton]").is(":hover");
                var fieldButtonPressed = this.$el.find("[name=fieldsDropdownButton]").is(":hover");
                var fieldRelatedButtonPressed = this.$el.find("[name=relatedFieldsDropdownButton]").is(":hover");

                this.handleRelatedFieldsButton();

                if (
                    fieldButtonPressed === true ||
                    functionButtonPressed === true ||
                    fieldRelatedButtonPressed === true ||
                    this.lastExpressionEntered === this.actionParameters.formulaElement
                ) {
                    return;
                }

                this.lastExpressionEntered = this.actionParameters.formulaElement;

                this.validateCurrentExpression(event.currentTarget.value);
            }.bind(this)
        );

        this.handleRelatedFieldsButton();

        this.options.manager.on("saving:record:buttons", this.verifyDataValid.bind(this));

        return renderResult;
    },

    verifyDataValid: function () {
        if (this.currentRelatedField) {
            var relatedData = this.$el.find("[name='" + this.currentRelatedField + "']").select2("data");
            this.actionParameters["defaultValueText"] = relatedData.text;

            // update the data in the main model
            this.actionParameters["defaultValue"] = relatedData.id;
            this.actionParameters.formulaElement = this.replaceCharInFormula("\"", "'");

            this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        }
    },

    formatResultModules: function (style) {
        var formattedResult = style.text;

        if (style.id === "1currentModule") {
            formattedResult = "<b>" + style.text + "</b>";
        }

        return formattedResult;
    },

    formulaElementClicked: function () {
        this.handleRelatedFieldsButton();
        this.showTooltip();
    },

    isUsingRelatedFunction: function () {
        var relatedKeyword = "related";
        var formulaBody = this.actionParameters.formulaElement;
        var cursorPosition = this.$el.find("#appendedInputButtons").prop("selectionStart");
        var partOfForumula = formulaBody.substring(0, cursorPosition);
        var lastIndexOfFunction = partOfForumula.lastIndexOf("(");
        var lastIndexOfEndFunction = partOfForumula.lastIndexOf(")");
        var lastFunctionUsed = formulaBody.substring(lastIndexOfFunction - relatedKeyword.length, lastIndexOfFunction);
        var relatedFunctionUsed = lastFunctionUsed === relatedKeyword;
        var relatedFunctionComplete = lastIndexOfEndFunction > lastIndexOfFunction;

        return relatedFunctionUsed && !relatedFunctionComplete;
    },

    getCurrentFunctionName: function () {
        var formulaBody = this.actionParameters.formulaElement;
        var cursorPosition = this.$el.find("#appendedInputButtons").prop("selectionStart");
        var hoveredFunctionName = "";
        var closestFunctionName = "";
        this.currentParamNumber = -1;
        var distanceToFunction = Number.POSITIVE_INFINITY;

        _.each(
            this.functionTypes,
            function findCurrentFunctionName(functionName) {
                // get the position where the formula starts
                var formulaStartIndex = formulaBody.indexOf(functionName);

                if (formulaStartIndex > -1) {
                    var formulaEndIndex = formulaStartIndex + functionName.length;

                    // check if the cursor is right on the function
                    if (
                        ((cursorPosition === 0 && formulaStartIndex === 0) ||
                            cursorPosition >= formulaStartIndex + 1) &&
                        cursorPosition <= formulaEndIndex &&
                        formulaBody.charAt(formulaEndIndex) === "(" &&
                        hoveredFunctionName.length <= functionName.length
                    ) {
                        hoveredFunctionName = functionName;
                        this.currentParamNumber = -1;
                        return;
                    }

                    // check if the cursor is inside the declaration of a function
                    if (formulaEndIndex < cursorPosition) {
                        var distance = cursorPosition - formulaEndIndex;

                        if (distance < distanceToFunction && formulaBody.charAt(formulaEndIndex) === "(") {
                            // inside current function
                            var parenthesisCount = 1;
                            var paramNumber = 1;

                            // eslint-disable-next-line max-depth
                            for (var charIndex = formulaEndIndex + 1; charIndex <= cursorPosition; charIndex++) {
                                //eslint-disable-next-line max-depth
                                if (formulaBody.charAt(charIndex) === "(") {
                                    parenthesisCount = parenthesisCount + 1;
                                } else if (formulaBody.charAt(charIndex - 1) === ")") {
                                    parenthesisCount = parenthesisCount - 1;
                                } else if (formulaBody.charAt(charIndex - 1) === "," && parenthesisCount === 1) {
                                    paramNumber = paramNumber + 1;
                                }
                            }

                            // if after parsing we are still in the same function
                            if (
                                parenthesisCount === 1 ||
                                (closestFunctionName.length <= functionName.length &&
                                    parenthesisCount === 0 &&
                                    cursorPosition > formulaBody.length - 1)
                            ) {
                                this.currentParamNumber = paramNumber;
                                distanceToFunction = distance;
                                closestFunctionName = functionName;
                            }
                        }
                    }
                }
            }.bind(this)
        );

        if (hoveredFunctionName === "") {
            hoveredFunctionName = closestFunctionName;
        }

        return hoveredFunctionName;
    },

    handleRelatedFieldsButton: function () {
        // if we use related functions we need to make the element smaller
        if (this.isUsingRelatedFunction() === true) {
            this.$el.find("[name=relatedFieldsDropdownButton]").show();
            this.$el.find("[name=formulaElement]").css("width", "60%");
        } else {
            this.$el.find("[name=relatedFieldsDropdownButton]").hide();
            this.$el.find("[name=formulaElement]").css("width", "70%");
        }
    },

    showTooltip: function () {
        var tooltipElement = this.$el.find("#appendedInputButtons");
        var functionTip = this.functionsDescription[this.getCurrentFunctionName()];
        var desc = "<p align=\"left\">" + functionTip + "</p>";

        // highlight the current param hovered
        if (this.currentParamNumber > 0 && functionTip !== "") {
            var paramCount = 0;
            var startIndex = desc.indexOf("(");
            var endIndex = desc.indexOf(")");

            var highlightStartIndex = startIndex + 1;
            var highlightEndIndex = -1;

            // if we have at least one param
            if (endIndex > startIndex) {
                var lastParamStartIndex = highlightStartIndex;
                var paramFound = false;

                // iterate to highlight the selected param
                for (var charIndex = startIndex; charIndex <= endIndex; charIndex++) {
                    // eslint-disable-next-line max-depth
                    if (desc.charAt(charIndex) === "," && paramFound === false) {
                        paramCount = paramCount + 1;
                        highlightStartIndex = lastParamStartIndex;

                        //eslint-disable-next-line max-depth
                        if (paramCount === this.currentParamNumber) {
                            paramFound = true;
                            highlightEndIndex = charIndex;
                        }
                        lastParamStartIndex = charIndex + 1;
                    }
                }

                var highlightStart = "<font color=\"#B22222\">";
                var highlightEnd = "</font>";

                if (paramCount === 0 || (paramFound === false && paramCount > 0)) {
                    highlightStartIndex = lastParamStartIndex;
                    highlightEndIndex = endIndex;
                }

                if (highlightEndIndex > -1) {
                    desc = [desc.slice(0, highlightEndIndex), highlightEnd, desc.slice(highlightEndIndex)].join("");
                    desc = [desc.slice(0, highlightStartIndex), highlightStart, desc.slice(highlightStartIndex)].join(
                        ""
                    );
                }
            }
        }

        // if the description is different from the previous we show the updated tooltip
        if (this.functionDescription !== desc || tooltipElement.data("tooltipVisible") === false) {
            if (functionTip !== "") {
                this.functionDescription = desc;
                var initialWidth = tooltipElement.css("width");

                tooltipElement.css("width", "1%");
                tooltipElement.tooltip("show");
                tooltipElement.css("width", initialWidth);
                tooltipElement.data("tooltipVisible", true);
            }
        }
    },

    populateRelatedModulesFields: function (fieldData) {
        var moduleName = fieldData.id.substr(0, fieldData.id.indexOf("__"));

        if (fieldData.id === "1currentModule") {
            moduleName = this.options.manager.model.get("moduleName");
        }

        this.initializeFieldsList(moduleName);
    },

    populateRelatedFieldsList: function (fieldData) {
        this.fieldRelatedTypes = this.options.manager.model.get("relatedModuleFields")[fieldData.text];
    },

    createCustomSelect2Dropdown: function (
        elementId,
        listType,
        callback,
        updateSelect2Callback,
        hide,
        formatResultFunction
    ) {
        // create the select2 dropdowns
        var fieldsSelect2 = this.$el
            .find(elementId)
            .select2(this.getSelect2Options(listType, formatResultFunction))
            .data("select2");

        fieldsSelect2.onSelect = (function select(fn) {
            return function updateSelect2(data, options) {
                if (callback) {
                    callback(data.id);
                }

                if (updateSelect2Callback) {
                    updateSelect2Callback(data);
                }

                if (arguments && listType !== "ModuleTypes") {
                    arguments[0] = {
                        id   : "select",
                        text : app.lang.get("LBL_SEARCH_SELECT")
                    };
                }

                return fn.apply(this, arguments);
            };
        })(fieldsSelect2.onSelect);

        if (hide) {
            this.$el.find(elementId).hide();
        }
    },

    addFunctionToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");
        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);

        var val = textBefore + value + "(" + textAfter;
        this.updateFormulaField(formulaElement, val);
    },

    addRelatedFieldToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");

        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);

        var val = textBefore + value + "\"" + value + "\"" + textAfter;

        this.updateFormulaField(formulaElement, val);
    },

    addFieldToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");

        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);
        var val = textBefore + "$" + value + textAfter;
        this.updateFormulaField(formulaElement, val);
    },

    updateFormulaField: function (formulaElement, val) {
        val = this.cleanFormula(val);
        formulaElement.val(val);

        this.actionParameters.formulaElement = val;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        formulaElement.focus();

        this.updateWidgetView();
    },

    updateWidgetView: function () {
        this.handleRelatedFieldsButton();
    },

    showFunctionsDropdown: function () {
        this.showDropdownList(this.$el.find(".functionsList"));
    },

    showRelatedFieldsDropdown: function () {
        this.showDropdownList(this.$el.find(".relatedFieldsList"));
    },

    showFieldsDropdown: function () {
        this.showDropdownList(this.$el.find(".fieldsList"));
    },

    getFunctionsList: function () {
        var typeMap = SUGAR.expressions.Expression.TYPE_MAP;
        var funcMap = SUGAR.FunctionMap;
        var funcList = [];

        for (var i in funcMap) {
            if (typeof funcMap[i] == "function" && funcMap[i].prototype) {
                for (var j in typeMap) {
                    // eslint-disable-next-line max-depth
                    if (funcMap[i].prototype instanceof typeMap[j]) {
                        funcList[funcList.length] = [i, j];
                        break;
                    }
                }
            }
        }

        // add current user formula
        funcList.push(["getCurrentUser", "string"]);

        return funcList;
    },

    getDisplayFunctionList: function () {
        var functionsArray = this.getFunctionsList();
        var usedClasses = {};
        var ret = [];

        _.each(
            functionsArray,
            function getDisplayFunction(functionData) {
                var fName = functionData[0];

                // show only the functions we actually use
                if (
                    fName !== "isValidTime" &&
                    fName !== "isAlpha" &&
                    fName !== "doBothExist" &&
                    fName !== "isValidPhone" &&
                    fName !== "isRequiredCollection" &&
                    fName !== "isNumeric" &&
                    fName !== "isValidDBName" &&
                    fName !== "isAlphaNumeric" &&
                    fName !== "stddev" &&
                    fName !== "charAt" &&
                    fName !== "formatName" &&
                    fName !== "sugarField" &&
                    fName !== "forecastCommitStage" &&
                    fName !== "currencyRate"
                ) {
                    if (functionData[1] == "time") {
                        return;
                    }

                    if (SUGAR.FunctionMap[fName] && usedClasses[SUGAR.FunctionMap[fName].prototype.className]) {
                        return;
                    }

                    if (functionData[1] == "number") {
                        ret.push([functionData[0], "_number"]);
                    } else {
                        ret.push(functionData);
                    }

                    if (SUGAR.FunctionMap[fName]) {
                        usedClasses[SUGAR.FunctionMap[fName].prototype.className] = true;
                    }
                }
            }.bind(this)
        );

        return ret;
    },

    showDropdownList: function (el) {
        if (this.dropdownOpened === true) {
            this.dropdownOpened = false;
            el.hide();
        } else {
            this.dropdownOpened = true;

            el.show();
            el.select2("open");

            el.on(
                "select2-close",
                function destroyDropdown(e) {
                    this.dropdownOpened = false;
                    el.hide();
                }.bind(this)
            );
        }
    },

    handleModuleChange: function (event) {
        this.actionParameters.fieldType = "";
        this.handleParamsChange(event);

        this.updateView();
    },

    //eslint-disable-next-line consistent-return
    handleCheckboxChange: function (event) {
        var fieldName = this.actionParameters.fieldType;
        var message = "Default Message";

        if (event.currentTarget.checked === false) {
            this.options.manager.trigger("clean-button-" + this.options.buttonId, true);
            this.options.manager.trigger("clean-button-" + this.options.actionId);

            if (!this.relateFields[fieldName]) {
                message = app.lang.get("LBL_WRB_ACTION_UPDATE_ALERT");

                app.alert.show("alert_missing_buttons", {
                    level          : "error",
                    title          : message,
                    autoClose      : true,
                    autoCloseDelay : 5000
                });
                this.handleValuesDropdown();
                return false;
            }
        } else {
            if (!this.calculatedFields[fieldName]) {
                message = app.lang.get("LBL_WRB_ACTION_UPDATE_ALERT_CALC");

                app.alert.show("alert_missing_buttons", {
                    level          : "error",
                    title          : message,
                    autoClose      : true,
                    autoCloseDelay : 5000
                });
                this.handleValuesDropdown();
                return false;
            }
        }

        this.handleParamsChange(event, event.currentTarget.checked);
        this.handleValuesDropdown();
    },

    handleValuesDropdown: function () {
        var isCalculated = this.actionParameters.calculatedField;

        if (isCalculated === true) {
            this.$el.find("[name=DefaultValueFieldUI]").hide();
            this.$el.find("[name=CalculatedFieldUI]").show();
            this.handleRelatesFieldsVisibility();
        } else if (isCalculated != null) {
            this.$el.find("[name=CalculatedFieldUI]").hide();
            this.$el.find("[name=DefaultValueFieldUI]").show();
            this.handleRelatesFieldsVisibility(this.actionParameters.fieldType);
        }

        this.$el.find("[name=calculatedField]").prop("checked", isCalculated === true);

    },

    handleParamsChange: function (event, value) {
        // update the data in the main model
        var dataValue = value ? value : event.currentTarget.value;

        if (event.currentTarget.name === "formulaElement") {
            dataValue = this.cleanFormula(dataValue);
            event.currentTarget.value = dataValue;
        }

        this.actionParameters[event.currentTarget.name] = dataValue;
        this.actionParameters.formulaElement = this.replaceCharInFormula("\"", "'");

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        this.updateWidgetView();
    },

    cleanFormula: function (dirtyFormula) {
        var charIndexesToBeRemoved = [];
        var searchAllowed = true;

        for (var charIndex = 0; charIndex < dirtyFormula.length; charIndex++) {
            if (searchAllowed && dirtyFormula[charIndex] === " ") {
                charIndexesToBeRemoved.push(charIndex);
            }

            if (dirtyFormula[charIndex] === "\"") {
                searchAllowed = !searchAllowed;
            }
        }

        for (var spaceIndex = charIndexesToBeRemoved.length - 1; spaceIndex >= 0; spaceIndex--) {
            dirtyFormula =
                dirtyFormula.substr(0, charIndexesToBeRemoved[spaceIndex]) +
                dirtyFormula.substr(charIndexesToBeRemoved[spaceIndex] + 1, dirtyFormula.length);
        }

        return dirtyFormula;
    },

    handleFieldChange: function (event) {
        this.actionParameters.corruptedFieldValue = false;

        //eslint-disable-next-line no-negated-condition
        if (!this.relateFields[event.currentTarget.value]) {
            this.actionParameters.calculatedField = true;
        } else {
            this.actionParameters.calculatedField = false;
        }

        this.handleValuesDropdown();

        var fieldName = event.currentTarget.value;

        this.handleParamsChange(event, fieldName);
        this.handleRelatesFieldsVisibility(this.actionParameters.fieldType);
        this.options.manager.trigger("clean-button-" + this.options.actionId, ".fieldType");
    },

    handleRelatesFieldsVisibility: function (currentField) {
        var relateElement = this.$el.find("[name=\"defaultFieldValueDropdown\"]");
        relateElement.empty();
        this.currentRelatedField = false;

        _.each(
            this.relateFields,
            function handleFieldsVisibility(relateField, relateFieldName) {
                if (relateFieldName === currentField) {
                    var currentModule = this.actionParameters.moduleType.substr(
                        0,
                        this.actionParameters.moduleType.indexOf("__")
                    );

                    if (currentModule === "") {
                        currentModule = this.options.manager.model.get("moduleName");
                    }

                    var fieldModel = app.data.createBean(currentModule);

                    if (relateField.module === "Teams") {
                        relateField.rname = "name";
                    }

                    var myCustomField = app.view.createField({
                        meta: {
                            view: "edit"
                        },
                        view     : this,
                        model    : fieldModel,
                        module   : "Accounts",
                        def      : relateField,
                        viewName : "edit"
                    });

                    myCustomField.render();

                    this.$el.find("[name=\"defaultFieldValueDropdown\"]").append(myCustomField.$el);
                    this.$el.find("[name=\"defaultFieldValueDropdown\"]").show();

                    if (this.lastFieldTypeCreated && this.lastFieldTypeCreated !== relateField.type) {
                        this.actionParameters["defaultValue"] = "";
                        this.actionParameters["defaultValueText"] = "";
                    }

                    this.lastFieldTypeCreated = relateField.type;

                    if (relateField.type === "relate") {
                        this.currentRelatedField = currentField;
                        myCustomField.$el.find("[name='" + currentField + "']").select2("data", {
                            id   : this.actionParameters["defaultValue"],
                            text : this.actionParameters["defaultValueText"]
                        });

                        this.$el.find("[name=\"defaultFieldValueDropdown\"]").on(
                            "select2-selected",
                            function updateDefaultValue(event) {
                                if (event.val) {
                                    if (event.currentTarget.textContent) {
                                        this.actionParameters["defaultValueText"] = event.currentTarget.textContent;
                                    }

                                    // update the data in the main model
                                    var dataValue = event.val;
                                    this.actionParameters["defaultValue"] = dataValue;
                                    this.actionParameters.formulaElement = this.replaceCharInFormula("\"", "'");

                                    this.options.parentView.modifyActionData(_.clone(this.actionParameters));
                                    this.updateWidgetView();
                                }
                            }.bind(this)
                        );
                    } else {
                        var self = this;

                        // split logic for different types of fields :(
                        if (relateField.type === "enum") {
                            myCustomField.$el.find("[name='" + currentField + "']").select2("data", {
                                id   : this.actionParameters["defaultValue"],
                                text : this.actionParameters["defaultValue"]
                            });
                        } else if (relateField.type === "bool") {
                            myCustomField.$el
                                .find("[type='checkbox']")
                                .prop("checked", this.actionParameters["defaultValue"] === true);
                        } else if (relateField.type === "currency") {
                            myCustomField.$el
                                .find("[name='currency_id']")
                                .select2("val", this.actionParameters["defaultValue"]["currency_id"]);

                            myCustomField.$el
                                .find("[name='" + currentField + "']")
                                .val(this.actionParameters["defaultValue"][currentField]);
                        } else if (relateField.type === "date") {
                            this.$el.find("[name='" + currentField + "']").val(this.actionParameters["defaultValue"]);

                            $(".datepicker.dropdown-menu").on("click", function getDate(event) {
                                // update the data in the main model
                                var dataValue = myCustomField.model.get(currentField);

                                self.actionParameters["defaultValue"] = dataValue;
                                self.actionParameters.formulaElement = self.replaceCharInFormula("\"", "'");
                                self.options.parentView.modifyActionData(_.clone(self.actionParameters));
                                self.updateWidgetView();
                            });
                        } else if (relateField.type === "datetimecombo") {
                            myCustomField.model.set(currentField, this.actionParameters["defaultValue"]);

                            this.$el.find("[name='" + currentField + "_time']").on("change", function getValue(event) {
                                // update the data in the main model
                                var dataValue = myCustomField.model.get(currentField);

                                self.actionParameters["defaultValue"] = dataValue;
                                self.actionParameters.formulaElement = self.replaceCharInFormula("\"", "'");
                                self.options.parentView.modifyActionData(_.clone(self.actionParameters));
                                self.updateWidgetView();
                            });

                            $(".datepicker.dropdown-menu").on("click", function getDate(event) {
                                // update the data in the main model
                                var dataValue = myCustomField.model.get(currentField);

                                self.actionParameters["defaultValue"] = dataValue;
                                self.actionParameters.formulaElement = self.replaceCharInFormula("\"", "'");
                                self.options.parentView.modifyActionData(_.clone(self.actionParameters));
                                self.updateWidgetView();
                            });
                        } else {
                            myCustomField.$el
                                .find("[name='" + currentField + "']")
                                .val(this.actionParameters["defaultValue"]);
                        }

                        self.customField = myCustomField;

                        if (relateField.type !== "datetimecombo" && relateField.type !== "date") {
                            this.$el.find("[name=\"defaultFieldValueDropdown\"]").on("change", function getValue(event) {
                                self.actionParameters.corruptedFieldValue = false;
                                // update the data in the main model
                                var dataValue = event.target.value;

                                if (event.target.type === "checkbox") {
                                    dataValue = event.target.checked;
                                }

                                var numericalTypes = ["int", "float", "currency", "decimal"];

                                if (numericalTypes.indexOf(self.customField.type) > -1) {
                                    dataValue = app.utils.unformatNumberStringLocale(dataValue, false);
                                    if (isNaN(dataValue)) {
                                        self.actionParameters.corruptedFieldValue = true;
                                    }
                                }

                                if (self.customField.type === "currency") {
                                    if (typeof self.actionParameters["defaultValue"] !== "object") {
                                        self.actionParameters["defaultValue"] = {};
                                    }
                                    self.actionParameters["defaultValue"][event.target.name] = dataValue;
                                } else {
                                    self.actionParameters["defaultValue"] = dataValue;
                                    self.actionParameters.formulaElement = self.replaceCharInFormula("\"", "'");
                                }

                                self.options.parentView.modifyActionData(_.clone(self.actionParameters));
                                self.updateWidgetView();
                            });
                        }
                    }
                }
            }.bind(this)
        );
    },

    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);
        this.actionParameters.formulaElement = this.replaceCharInFormula("'", "\"");

        this.updateView();
        this.updateWidgetView();
    },

    updateView: function () {
        this.$el.find("[name=\"formulaElement\"]").val(this.actionParameters.formulaElement);

        var moduleType = this.modulesList[this.actionParameters.moduleType];

        if (!moduleType) {
            this.actionParameters.moduleType = "1currentModule";
            moduleType = "CURRENT RECORD";
        }

        this.populateRelatedModulesFields({
            id: this.actionParameters.moduleType
        });

        var defaultValue = this.fieldTypes[this.actionParameters.defaultValue];

        if (!defaultValue) {
            defaultValue = "Select Value";
        }

        var fieldType = this.fieldTypes[this.actionParameters.fieldType];

        if (!fieldType) {
            fieldType = "Select Field";
        }

        var fieldTypeId = this.fieldTypes[this.actionParameters.fieldType] ?
            this.actionParameters.fieldType :
            this.actionParameters.fieldType.replace(/id/g, "name");

        this.$el.find("[name=\"moduleType\"]").select2("data", {
            id   : this.actionParameters.moduleType,
            text : moduleType
        });
        this.$el.find("[name=\"fieldType\"]").select2("data", {
            id   : fieldTypeId,
            text : this.fieldTypes[fieldTypeId] || fieldType
        });
        this.$el.find("[name=\"defaultValue\"]").select2("data", {
            id   : this.actionParameters.defaultValue,
            text : defaultValue
        });

        this.handleValuesDropdown();
    },

    getSelect2Options: function (optionsType, formatResultFunction) {
        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query" + optionsType], this);
        select2Options.selectOnBlur = true;

        if (formatResultFunction) {
            select2Options.formatResult = formatResultFunction;
        }

        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text === "CURRENT RECORD") {
                    return -1;
                } else if (secondLabel.text === "CURRENT RECORD") {
                    return 1;
                }

                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _queryFunctions: function (query) {
        this._query(query, "functionTypes");
    },

    _queryModuleTypes: function (query) {
        this._query(query, "modulesList");
    },

    _queryDefaultValue: function (query) {
        var listName = "defaultValues";
        this._query(query, listName);
    },

    _queryFieldTypes: function (query) {
        var listName = "fieldTypes";
        this._query(query, listName);
    },

    _queryRelatedModules: function (query) {
        var listName = this.isUsingRelatedFunction() === true ? "relatedModules" : "fieldTypes";
        this._query(query, listName);
    },

    _queryRelatedFields: function (query) {
        this._query(query, "fieldRelatedTypes");
    },

    _query: function (query, customListName) {
        var listElements = this[customListName];
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listElements)) {
            _.each(listElements, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listElements = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) { },

    setReturnTypes: function (t, vMap) {
        var see = SUGAR.expressions.Expression;

        if (t.type == "variable") {
            if (typeof vMap[t.name] == "undefined") {
                throw "Unknown field: " + t.name;
            } else if (vMap[t.name] == "relate") {
                t.returnType = SUGAR.expressions.Expression.GENERIC_TYPE;
            } else {
                t.returnType = vMap[t.name];
            }
        }

        if (t.type == "function" && t.name !== "getCurrentUser") {
            for (var i in t.args) {
                this.setReturnTypes(t.args[i], vMap);
            }

            var fMap = SUGAR.FunctionMap;

            if (typeof fMap[t.name] == "undefined") {
                throw t.name + ": No such function defined";
            }

            for (var j in see.TYPE_MAP) {
                if (fMap[t.name].prototype instanceof see.TYPE_MAP[j]) {
                    t.returnType = j;
                    break;
                }
            }

            // For the conditional function, if both argument return types are same, set the conditional type
            if (t.name == "ifElse") {
                var args = t.args;
                var returnTypeIndex = 2;

                if (args[1].returnType == args[returnTypeIndex].returnType) {
                    t.returnType = args[1].returnType;
                }
            }

            if (!t.returnType) {
                throw t.name + ": No known return type!";
            }
        }
    },

    validateReturnTypes: function (t) {
        if (t.type == "function" && t.name !== "getCurrentUser") {
            //Depth first recursion
            for (var i in t.args) {
                this.validateReturnTypes(t.args[i]);
            }

            var fMap = SUGAR.FunctionMap;
            var see = SUGAR.expressions.Expression;

            if (typeof fMap[t.name] == "undefined") {
                throw t.name + ": No such function defined";
            }

            var types = fMap[t.name].prototype.getParameterTypes();
            var count = fMap[t.name].prototype.getParamCount();

            // check parameter count
            if (count == see.INFINITY && t.args.length == 0) {
                throw t.name + ": Requires at least one parameter";
            }

            if (count != see.INFINITY && t.args instanceof Array && t.args.length != count) {
                throw t.name + ": Requires exactly " + count + " parameter(s)";
            }

            if (typeof types == "string") {
                for (var j = 0; j < t.args.length; j++) {
                    // eslint-disable-next-line max-depth
                    if (!t.args[j].returnType) {
                        throw t.name + ": No known return type!";
                    }

                    // eslint-disable-next-line max-depth
                    if (!fMap[t.name].prototype.isProperType(new see.TYPE_MAP[t.args[j].returnType](), types)) {
                        throw t.name + ": All parameters must be of type '" + types + "'";
                    }
                }
            } else {
                for (var k = 0; k < types.length; k++) {
                    // eslint-disable-next-line max-depth
                    if (!fMap[t.name].prototype.isProperType(new see.TYPE_MAP[t.args[k].returnType](), types[k])) {
                        throw t.name + ": The parameter at index " + k + " must be of type " + types[k];
                    }
                }
            }
        }
    },

    //eslint-disable-next-line consistent-return
    validateRelateFunctions: function (t) {
        if (t.type == "function") {
            //Depth first recursion
            for (var i in t.args) {
                this.validateRelateFunctions(t.args[i]);
            }

            //these functions all take a link and a string for a related field
            var relFuncs = ["related", "rollupAve", "rollupMax", "rollupMin", "rollupSum"];

            if (this.arrayIndexOf(relFuncs, t.name) == -1) {
                return true;
            }

            var url =
                "index.php?" +
                this.paramsToUrl({
                    module  : "ExpressionEngine",
                    action  : "validateRelatedField",
                    tmodule : this.options.manager.model.get("moduleName"),
                    package : "",
                    link    : t.args[0].name,
                    related : t.args[1].value
                });

            var resp = this.httpFetchSync(url);
            var def = JSON.parse(resp.responseText);

            //Check if a field was found
            if (typeof def == "string") {
                throw t.name + ": " + def;
            }

            if (
                t.name != "related" &&
                def.type &&
                this.arrayIndexOf(["decimal", "int", "float", "currency"], def.type) == -1
            ) {
                throw t.name + ": related field  " + t.args[1].value + " must be a number ";
            }

            return true;
        }
    },

    getXMLHTTPinstance: function () {
        var xmlhttp = false;

        try {
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (E) {
                xmlhttp = false;
            }
        }

        if (!xmlhttp && typeof XMLHttpRequest != "undefined") {
            xmlhttp = new XMLHttpRequest();
        }

        return xmlhttp;
    },

    httpFetchSync: function (url, postData, headers) {
        headers = headers || {};
        var globalXmlhttp = this.getXMLHTTPinstance();
        var method = "GET";

        if (typeof postData != "undefined") {
            method = "POST";
        }

        try {
            globalXmlhttp.open(method, url, false);
        } catch (e) {
            var message = "message:" + e.message + ":url:" + url;
            app.alert.show("alert_missing_buttons", {
                level          : "error",
                title          : message,
                autoClose      : true,
                autoCloseDelay : 5000
            });
        }

        if (method == "POST" && typeof headers["Content-Type"] === "undefined") {
            headers["Content-Type"] = "application/x-www-form-urlencoded";
        }

        for (var header in headers) {
            globalXmlhttp.setRequestHeader(header, headers[header]);
        }

        globalXmlhttp.send(postData);

        var args = {
            responseText : globalXmlhttp.responseText,
            responseXML  : globalXmlhttp.responseXML,
            //eslint-disable-next-line camelcase
            request_id   : 0
        };

        return args;
    },

    arrayIndexOf: function (arr, val, start) {
        if (typeof arr.indexOf == "function") {
            return arr.indexOf(val, start);
        }

        for (var i = start || 0, j = arr.length; i < j; i++) {
            if (arr[i] === val) {
                return i;
            }
        }

        return -1;
    },

    paramsToUrl: function (params) {
        var parts = [];
        for (var i in params) {
            // eslint-disable-next-line no-prototype-builtins
            if (params.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + "=" + encodeURIComponent(params[i]));
            }
        }

        return parts.join("&") + "&";
    },

    //eslint-disable-next-line consistent-return
    validateCurrentExpression: function (expression) {
        // if we have and empty expression we must set a default value
        if (expression === "") {
            expression = "emptyExpression";
        }

        if (this.actionParameters.calculatedField === true) {
            var isCurrentModule = this.actionParameters.moduleType === "1currentModule";
            var moduleType = isCurrentModule ?
                this.options.manager.model.get("moduleName") :
                this.actionParameters.moduleType;
            var selectedModuleName = isCurrentModule ? moduleType : moduleType.substr(0, moduleType.indexOf("__"));

            var fieldsData = this.options.manager.model.get("fieldsData")[selectedModuleName];

            try {
                var varTypeMap = {};
                var getModuleRx = /(.*)__/g;
                var moduleRxFindings = getModuleRx.exec(moduleType);
                moduleType = moduleRxFindings ? moduleRxFindings[1] : moduleType;

                for (var i = 0; i < fieldsData.length; i++) {
                    varTypeMap[fieldsData[i][0]] = fieldsData[i][1];
                }

                var completeFieldsList = App.metadata.getModule(moduleType).fields;
                _.each(completeFieldsList, function getMultiselectAndIdFields(fieldData) {
                    if (fieldData.type === "multienum") {
                        varTypeMap[fieldData.name] = "string";
                    }

                    if (fieldData.type === "id") {
                        varTypeMap[fieldData.name] = "number";
                    }
                });

                var tokens = new SUGAR.expressions.ExpressionParser().tokenize(expression);

                this.setReturnTypes(tokens, varTypeMap);
                this.validateReturnTypes(tokens);
                this.validateRelateFunctions(tokens);

                this.actionParameters.validationMessage = "";
                this.actionParameters.validFormula = true;

                this.actionParameters.formulaElement = this.replaceCharInFormula("\"", "'");

                this.options.parentView.modifyActionData(_.clone(this.actionParameters));

                this.options.manager.trigger("clean-button-" + this.options.buttonId);
                this.options.manager.trigger("clean-button-" + this.options.actionId);
                return true;
            } catch (e) {
                app.alert.show("alert_missing_buttons", {
                    level          : "error",
                    title          : e,
                    autoClose      : true,
                    autoCloseDelay : 5000
                });

                this.actionParameters.validationMessage = e;
                this.actionParameters.validFormula = false;

                this.options.parentView.modifyActionData(_.clone(this.actionParameters));
                this.options.manager.trigger("corrupted-button-" + this.options.buttonId);
                this.options.manager.trigger("corrupted-button-" + this.options.actionId);
                return false;
            }
        }
    },

    replaceCharInFormula: function (charToReplace, newChar) {
        var formulaBody = this.actionParameters.formulaElement;
        var regex = new RegExp("\\" + charToReplace);

        while (formulaBody.match(regex)) {
            formulaBody = formulaBody.replace(regex, newChar);
        }

        return formulaBody;
    }
});