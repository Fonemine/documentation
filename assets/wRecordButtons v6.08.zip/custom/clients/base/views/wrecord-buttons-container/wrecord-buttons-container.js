/**
 * Class Description
 *
 * @class wrecord-buttons-container
 */
({
    events: {
        "click .add_button": "addButtonClicked"
    },

    buttons           : {},
    lastButtonCreated : null,
    manager           : null,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function(options) {
        var modelAttributes = options.layout.layout.model.attributes;
        this.options.model = new Backbone.Model(modelAttributes);

        var initResult = this._super("initialize", arguments);

        this.refreshValues();

        this.manager = this.layout.layout;

        return initResult;
    },

    /**
     * Description
     * @method refreshValues
     * @return
     */
    refreshValues: function() {
        this.buttons = {};
        this.manager = null;
        this.lastButtonCreated = null;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function() {
        // register needed events
        this.manager.model.on("change:buttons", this.updateButtons.bind(this));
        this.manager.on("wRecordButton-pressed", this.clearButtonsChecked.bind(this));
        this.manager.on("button:label:change", this.updateButtonLabel.bind(this));

        var renderResult = this._super("render", arguments);

        this.updateButtons(this.manager.model, true);

        //    initialize the sortable list so that we can sort buttons by simple dragging them
        this.$el.find("#sortableButtons").sortable({
            revert : true,
            start  : function blockRemoval(event, ui) {
                // if we drag buttons we need to block the delete functions
                this.manager.blockButtonRemoval(true);
                var initialIndex = ui.item.index();

                ui.item.data("initialIndex", initialIndex);
            }.bind(this),
            stop: function allowRemoval(event, ui) {
                // when we release the button we can remove buttons once again
                this.manager.blockButtonRemoval(false);
                this.manager.reOrderButtons(ui.item.data("initialIndex") + 1, ui.item.index() + 1);
            }.bind(this)
        });

        return renderResult;
    },

    /**
     * Description
     * @method clearButtonsChecked
     * @param {} clickedButtonId
     * @param {} recentlyAdded
     * @return
     */
    clearButtonsChecked: function(clickedButtonId, recentlyAdded) {
        var self = this;
        _.each(this.buttons, function clearButtons(buttondData, buttonId) {
            var targetButtonEl = self.$el.find("#" + buttonId);
            var targetButtonData = targetButtonEl.data();

            targetButtonEl.removeClass("active");

            if (targetButtonData.buttonCorrupted && targetButtonData.buttonCorrupted === "corrupted") {
                targetButtonEl.find("#deleteButton").css({ color: "white" });
                targetButtonEl.css({ background: "red", color: "white" });
            } else {
                targetButtonEl.find("#deleteButton").css({ color: "#717171" });
                targetButtonEl.css({ background: "#f6f6f6", color: "#555" });
            }
        });

        if (recentlyAdded) {
            this.$el.find("#" + clickedButtonId).addClass("active");
        }
    },

    /**
     * Description
     * @method updateButtonLabel
     * @param {} label
     * @param {} buttonId
     * @return
     */
    updateButtonLabel: function(label, buttonId) {
        var buttonEl = this.$el.find("#" + buttonId);
        buttonEl.text(label);
        buttonEl.append("<i class=\"fa fa-times\" id=\"deleteButton\" style=\"float: right;color:white\" tabindex=\"-1\"></i>");
    },

    /**
     * Description
     * @method updateButtons
     * @param {} model
     * @param {} doNotClearButtons
     * @return
     */
    updateButtons: function(model, doNotClearButtons) {
        // order buttons
        var buttonsList = [];

        _.each(model.attributes.buttons, function insertButtonInList(button) {
            buttonsList.push(button);
        });

        buttonsList.sort(function sortButtons(firstButton, secondButton) {
            return firstButton.orderNumber - secondButton.orderNumber;
        });

        // create the buttons and store them in a list
        _.each(
            buttonsList,
            function updateButtonsList(buttonData) {
                if (!this.buttons[buttonData.index]) {
                    this.addButton(buttonData, buttonData.index, doNotClearButtons);
                }
            }.bind(this)
        );
    },

    /**
     * Description
     * @method addButtonClicked
     * @return
     */
    addButtonClicked: function() {
        // inform the layout that we want to add a button
        this.manager.addButtonData({}, true);
    },

    /**
     * Description
     * @method addButton
     * @param {} buttonData
     * @param {} buttonId
     * @param {} doNotClearButtons
     * @return
     */
    addButton: function(buttonData, buttonId, doNotClearButtons) {
        if (!doNotClearButtons) {
            this.clearButtonsChecked(buttonId);
        }

        this.createButton(buttonData);

        this.buttons[buttonId] = _.clone(buttonData);

        this.lastButtonCreated.render();
    },

    /**
     * Description
     * @method createButton
     * @param {} buttonModel
     * @return
     */
    createButton: function(buttonModel) {
        // creating a new button and inserting it into the sortable list
        var model = new Backbone.Model(_.clone(buttonModel));
        this.lastButtonCreated = App.view.createView({
            name           : "wrecord-button",
            model          : model,
            parentView     : this,
            layout         : this,
            selectedModule : "Home",
            manager        : this.manager
        });

        this.$el.find("#sortableButtons").append(this.lastButtonCreated.$el);
    },

    /**
     * Description
     * @method deleteButton
     * @param {} buttonId
     * @return
     */
    deleteButton: function(buttonId) {
        // delete a button
        this.manager.deleteButton(buttonId);
        delete this.buttons[buttonId];
    }
});
