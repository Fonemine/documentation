/**
 * Class Description
 *
 * @class wrecord-button-run-job
 */
({
    actionParameters: {
        reportId   : "",
        reportName : ""
    },
    reportsField : false,
    reportsList  : {},

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            reportId    : "",
            reportName  : "",
            executeView : this.name
        };

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();

        this.createReportsSelection();
        this.updateView();

        return renderResult;
    },

    createReportsSelection: function () {
        this.reportsField = app.view.createField({
            def: {
                type   : "relate",
                module : "Reports",
                name   : "myTestField"
            },
            view     : this,
            viewName : "edit",
        });
        this.reportsField.render();
        this.$el.find("#reportsListContainer").empty();
        this.$el.find("#reportsListContainer").append(this.reportsField.$el);

        this.reportsField.setValue = this.handleParamsChange.bind(this);
    },

    /**
     * Description
     * @method handleParamsChange
     * @param {} event
     * @return
     */
    handleParamsChange: function (model) {
        // update the data in the main model
        this.actionParameters.reportId = model.id;
        this.actionParameters.reportName = model.name;

        this.updateView();

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);

        if (!this.actionParameters.executeView) {
            this.actionParameters.executeView = this.name;
        }

        this.updateView();
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        if (this.reportsField && this.actionParameters.reportId && this.actionParameters.reportId !== "") {
            var delay = 500;
            setTimeout(function updateReportsView() {
                this.$el.find(".select2-container.select2.inherit-width").select2("data", {
                    id   : this.actionParameters.reportId,
                    text : this.actionParameters.reportName
                });
            }.bind(this), delay);
        }
    },

    execute: function (buttonData, forceCompleteExecution) {
        var self = this;
        app.alert.show("go-to-report", {
            level     : "confirmation",
            messages  : app.lang.get("LBL_WRB_OPEN_NEW_REPORT_RECORD"),
            autoClose : false,
            onConfirm : function () {
                window.open(window.location.origin + window.location.pathname + "#Reports/" + buttonData.actionParameters.reportId, "_blank");
                self.executeNextAction();
            },
            onCancel: function () {
                self.executeNextAction();
            }
        });

    },
});