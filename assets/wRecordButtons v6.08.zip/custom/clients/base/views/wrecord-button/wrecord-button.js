/**
 * Class Description
 *
 * @class wrecord-button
 */
({
    events: {
        "click #deleteButton": "handleButtonDeleted"
    },

    buttonId          : null,
    activeByDefault   : false,
    activeButtonIndex : 1,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.buttonId = options.model.get("index");
        this.buttonName = options.model.get("label");

        this.activeByDefault =
            options.model.get("orderNumber") === this.activeButtonIndex;

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        this.$el
            .find("#" + this.buttonId)
            .on("click", this.showButtonConfig.bind(this));
        this.options.manager.on(
            "corrupted-button-" + this.buttonId,
            this.setCorruptedFeedback.bind(this)
        );
        this.options.manager.on(
            "clean-button-" + this.buttonId,
            this.setCleanFeedback.bind(this)
        );
        this.activateButton();

        return renderResult;
    },

    /**
     * Description
     * @method setCorruptedFeedback
     * @return
     */
    setCorruptedFeedback: function () {
        this.cleanColor = this.$el.css("background");

        var buttonEl = this.$el.find("#" + this.buttonId);
        buttonEl.data("buttonCorrupted", "corrupted");
    },

    /**
     * Description
     * @method setCleanFeedback
     * @return
     */
    setCleanFeedback: function () {
        var buttonEl = this.$el.find("#" + this.buttonId);

        buttonEl.data("buttonCorrupted", "clean");
    },

    /**
     * Description
     * @method showButtonConfig
     * @return
     */
    showButtonConfig: function () {
        this.options.manager.showButtonConfig(this.buttonId);

        this.$el
            .find("#" + this.buttonId)
            .css({
                background : "#555",
                color      : "white"
            });
        this.$el.find("#deleteButton").css("color", "white");
    },

    /**
     * Description
     * @method activateButton
     * @return
     */
    activateButton: function () {
        if (this.activeByDefault) {
            this.showButtonConfig();
            this.$el.find("#" + this.buttonId).addClass("active");
        }
    },

    /**
     * Description
     * @method handleButtonDeleted
     * @param {} event
     * @return
     */
    handleButtonDeleted: function (event) {
        if (this.options.manager.canDeleteButtons === true) {
            var message = "";

            if (this.isLastButton()) {
                message = app.lang.get("LBL_WRB_WREC_BUTTON_LAST_BUTTON_ALERT");
                app.alert.show("alert_delete_button", {
                    level          : "error",
                    title          : "Error",
                    messages       : message,
                    autoClose      : true,
                    autoCloseDelay : 5000
                });
            } else {
                message = app.lang.get("LBL_WRB_WREC_BUTTON_DELETE_BUTTON_ALERT");
                app.alert.show("alert_delete_button", {
                    level          : "confirmation",
                    title          : "Warning",
                    messages       : message,
                    autoClose      : true,
                    autoCloseDelay : 5000,
                    onConfirm      : function deleteButtonOnConfirm() {
                        this.layout.deleteButton(this.buttonId);
                        this.remove();
                    }.bind(this)
                });
            }
        }
    },

    /**
     * Description
     * @method isLastButton
     * @return BinaryExpression
     */
    isLastButton: function () {
        return (
            Object.keys(this.options.manager.model.get("buttons")).length <= 1
        );
    }
});