<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class CreateDocumentRevisionApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'CreateDocumentRevision' => array(
                'reqType'         => 'POST',
                'path'            => array('CreateDocumentRevision'),
                'pathVars'        => array(''),
                'method'          => 'createDocumentRevision',
                'shortHelp'       => 'Creates a document revision',
                'noLoginRequired' => true,
                'longHelp'        => '',
            ),
        );
    }

    public function createDocumentRevision(ServiceBase $api, array $args)
    {
        global $current_user;
        // get the data needed to create the new document
        $currentUserId      = $_POST['currentUserId'];
        $documentAttributes = json_decode($_POST['documentAttributes'], true);
        $documentId         = create_guid();
        $documentRevisionId = create_guid();
        $fileName           = $_FILES['documentFile']["name"];

        // set the current user id
        $current_user->id        = $currentUserId;
        $current_user->user_name = $currentUserId;

        require_once 'include/upload_file.php';

        // create a new upload file
        $documentFile = new UploadFile('documentFile');

        if ($documentFile->confirm_upload()) {
            $documentFile->final_move($documentId);
        }

        // create the document bean
        $documentBean = BeanFactory::newBean("Documents");

        // populate the document bean
        foreach ($documentAttributes as $fieldKey => $fieldValue) {
            $documentBean->{$fieldKey} = $fieldValue;
        }

        // add the needed info into the newly created document bean
        $documentBean->modified_user_id     = $currentUserId;
        $documentBean->created_by           = $currentUserId;
        $documentBean->document_revision_id = $documentRevisionId;
        $documentBean->id                   = $documentId;
        $documentBean->doc_type             = $documentAttributes["doc_type"] ? $documentAttributes["doc_type"] : "Sugar";
        $documentBean->status_id            = $documentAttributes["status_id"] ? $documentAttributes["status_id"] : "Active";

        //add teams
        $documentBean->load_relationship('teams');
        $newTeams = array();

        if ($documentBean->teams) {
            foreach ($documentAttributes["team_name"] as $teamIndex => $teamData) {
                array_push($newTeams, $teamData["id"]);
            }
        }

        $documentBean->new_with_id = true;
        $documentBean->processed   = true;
        $documentBean->teams->add($newTeams);
        $documentBean->save();

        // get the file extension
        $lastIndexOfDot = strripos($fileName, ".");
        $extension      = substr($fileName, $lastIndexOfDot + 1, strlen($fileName) - $lastIndexOfDot + 1);

        // create the document revision bean
        $documentRevisionBean = BeanFactory::newBean("DocumentRevisions");

        // add the needed info into the newly created document revision bean
        $documentRevisionBean->id          = $documentRevisionId;
        $documentRevisionBean->new_with_id = true;
        $documentRevisionBean->doc_type    = $documentBean->doc_type;

        $documentRevisionBean->change_log     = "Document Created";
        $documentRevisionBean->created_by     = $currentUserId;
        $documentRevisionBean->document_id    = $documentId;
        $documentRevisionBean->filename       = $fileName;
        $documentRevisionBean->file_ext       = $extension;
        $documentRevisionBean->file_mime_type = $_FILES['documentFile']["type"];
        $documentRevisionBean->revision       = $documentBean->revision;
        $documentRevisionBean->processed      = true;

        $documentRevisionBean->save();

        return $documentId;
    }
}
