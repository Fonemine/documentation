<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class EnhancedEmailTemplatesApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'EnhancedEmailTemplates' => array(
                'reqType'         => 'POST',
                'path'            => array('EnhancedEmailTemplates'),
                'pathVars'        => array(''),
                'method'          => 'getEnhancedEmailData',
                'shortHelp'       => 'This returns the processed email template',
                'longHelp'        => '',
                'noLoginRequired' => true,
            ),
        );
    }

    public function getEnhancedEmailData($api, $args)
    {
        $moduleName     = $args["targetModule"];
        $recordId       = $args["targetRecordId"];
        $templateId     = $args["targetTemplateId"];
        $templateModule = "pmse_Emails_Templates";

        $emailTo = false;

        if ($args["emailToField"] === true) {
            $emailTo = $this->getEmailTo($args["emailToData"]["formulaElement"], $args["targetModule"], $args["targetRecordId"]);
        }

        require_once 'modules/pmse_Inbox/engine/PMSEHandlers/PMSEEmailHandler.php';
        $pmseEmailHandler = new PMSEEmailHandler();

        $templateBean = BeanFactory::retrieveBean($templateModule, $templateId);
        $recordBean   = BeanFactory::retrieveBean($moduleName, $recordId);

        $htmlSubject = from_html($pmseEmailHandler->getBeanUtils()->mergeBeanInTemplate($recordBean, $templateBean->subject));
        $htmlBody    = from_html($pmseEmailHandler->getBeanUtils()->mergeBeanInTemplate($recordBean, $templateBean->body_html));

        $emailModelData = array(
            "subject"     => $htmlSubject,
            "description" => $templateBean->description,
            "body"        => $htmlBody,
            "emailTo"     => $emailTo,
        );

        return $emailModelData;
    }

    private function getEmailTo($formula, $recordType, $recordId)
    {
        $formula    = str_replace("'", "\"", $formula);
        $recordBean = BeanFactory::retrieveBean($recordType, $recordId);
        $result     = Parser::evaluate($formula, $recordBean)->evaluate();

        if (is_string($result) === true) {
            $emailAddressId = $this->getEmailAddressId($result);
            if (!$emailAddressId) {
                $emailAddressId = create_guid();
                $this->createEmailAddressId($result, $emailAddressId);
            }
            $result = array(array("email_address" => $result, "email_address_id" => $emailAddressId));
        } else {
            foreach ($result as $key => $emailData) {
                $parentBean = BeanFactory::retrieveBean($emailData["bean_module"], $emailData["bean_id"]);

                $result[$key]["name"] = $parentBean->name ? $parentBean->name : $parentBean->full_name;
            }
        }

        return $result;
    }

    private function createEmailAddressId($result, $emailAddressId)
    {
        $upperCaseEmailAddress = strtoupper($result);
        $qb                    = \DBManagerFactory::getConnection()->createQueryBuilder();
        $qb->insert('email_addresses')->values(
            array(
                "id"                 => "'${emailAddressId}'",
                "email_address"      => "'${result}'",
                "email_address_caps" => "'${upperCaseEmailAddress}'",
                "invalid_email"      => 0,
                "opt_out"            => 0,
                "deleted"            => 0,
            )
        );

        $qb->execute();
    }

    private function getEmailAddressId($emailAddress)
    {
        $emailAddressId = false;

        $queryBuilder = \DBManagerFactory::getConnection()->createQueryBuilder();
        $queryBuilder
            ->select(array("id"))
            ->from("email_addresses");

        $expression = $queryBuilder->expr();
        $and        = $expression->andx();

        $and->add($expression->eq(
            "deleted",
            $queryBuilder->createPositionalParameter(0)
        ));

        $and->add($expression->eq(
            "email_address",
            $queryBuilder->createPositionalParameter($emailAddress)
        ));

        $queryBuilder->where($and);

        $queryBuilderResult = $queryBuilder->execute();
        $emailData          = $queryBuilderResult->fetch();

        if ($emailData) {
            $emailAddressId = $emailData["id"];
        }

        return $emailAddressId;
    }
}
