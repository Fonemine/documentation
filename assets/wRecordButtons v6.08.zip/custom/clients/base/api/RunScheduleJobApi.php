<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class RunScheduleJobApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'RunScheduleJob' => array(
                'reqType'   => 'POST',
                'path'      => array('RunScheduleJob'),
                'pathVars'  => array(''),
                'method'    => 'runScheduleJob',
                'shortHelp' => 'This inserts a job inside the job queue',
                'longHelp'  => '',
            ),
        );
    }

    public function runScheduleJob($api, $args)
    {
        require_once 'include/SugarQueue/SugarJobQueue.php';

        global $current_user;

        $job       = new SchedulersJob();
        $job->name = $args['jobName'];

        // key piece, this is data we are passing to the job that it can use to run it.
        $job->target = $args['jobFunction'];

        //user the job runs as
        $job->assigned_user_id = $current_user->id;

        $jobData = array(
            'recordType' => $args['recordModuleType'],
            'recordId'   => $args['recordId'],
        );

        $job->data = base64_encode(json_encode($jobData));

        // Now push into the queue to run
        $jq    = new SugarJobQueue();
        $jobid = $jq->submitJob($job);

        return $jobid;
    }
}
