<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class SaveCustomButtonLabelsApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'SaveCustomButtonLabel' => array(
                'reqType'         => 'POST',
                'path'            => array('SaveCustomButtonLabel'),
                'pathVars'        => array(''),
                'method'          => 'saveCustomButtonLabel',
                'shortHelp'       => 'This inserts a new label in the localization system',
                'longHelp'        => '',
                'noLoginRequired' => true,
            ),
        );
    }

    public function saveCustomButtonLabel($api, $args)
    {
        require_once 'modules/ModuleBuilder/parsers/parser.label.php';
        $sugarLanguages = get_languages();

        $labels     = $args["labels"];
        $language   = $args["currentLanguage"];
        $moduleName = $args["moduleName"];

        foreach ($labels as $key => $labelData) {
            $newLabels = array();

            $newLabels[$labelData["labelKey"]] = $labelData["labelValue"];

            if ($labelData["alreadyLocalized"]) {
                foreach ($sugarLanguages as $languageKey => $languageDisplay) {
                    ParserLabel::addLabels($language, $newLabels, $moduleName);
                }
            } else {
                ParserLabel::addLabels($language, $newLabels, $moduleName);
            }
        }
    }
}
