<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class GetEmailTemplateDataApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'getEmailTemplateData'          => array(
                'reqType'         => 'POST',
                'path'            => array("GetEmailTemplateData", "getEmailTemplateData"),
                'pathVars'        => array(''),
                'method'          => 'getEmailTemplateData',
                'shortHelp'       => 'This method is used to get an email template from database',
                'longHelp'        => '',
                'noLoginRequired' => true,
            ),
            'getEmailTemplateProcessedData' => array(
                'reqType'         => 'POST',
                'path'            => array("GetEmailTemplateProcessedData", "getEmailTemplateProcessedData"),
                'pathVars'        => array(''),
                'method'          => 'getEmailTemplateProcessedData',
                'shortHelp'       => 'This method is used to get the processed email template',
                'longHelp'        => '',
                'noLoginRequired' => true,
            ),
        );
    }

    public function getEmailTemplateData(ServiceBase $api, array $args)
    {
        global $db;
        $conn       = $db->getConnection();
        $templateId = $args['emailId'];
        $result     = array();
        $select     =
            <<<EOQ
SELECT id,name,description,body_html,subject FROM email_templates where id = '{$templateId}';
EOQ;

        $resultset = $conn->executeQuery($select);

        while ($row = $resultset->fetch()) {
            $result[] = $row;
        }

        return $result;
    }

    public function getEmailTemplateProcessedData(ServiceBase $api, array $args)
    {
        global $sugar_config;

        $templateData                    = array();
        $emailTemplateId                 = $args["templateId"];
        $emailTemplateBean               = BeanFactory::getBean("EmailTemplates", $emailTemplateId);
        $targetBean                      = array();
        $targetBean[$args["recordType"]] = $args["recordId"];

        $emailTo = false;

        if ($args["emailToField"] === true) {
            $emailTo = $this->getEmailTo($args["emailToData"]["formulaElement"], $args["recordType"], $args["recordId"]);
        }
        $htmlBody = $emailTemplateBean->body_html;

        if ($sugar_config['email_default_client'] !== "sugar") {
            $htmlBody = strip_tags($htmlBody);
        }

        $templateData["body"]        = $emailTemplateBean->parse_template($htmlBody, $targetBean);
        $templateData["subject"]     = $emailTemplateBean->parse_template(strip_tags($emailTemplateBean->subject), $targetBean);
        $templateData["description"] = $emailTemplateBean->description;
        $templateData["emailTo"]     = $emailTo;

        return $templateData;
    }

    private function getEmailTo($formula, $recordType, $recordId)
    {
        $formula    = str_replace("'", "\"", $formula);
        $recordBean = BeanFactory::retrieveBean($recordType, $recordId);
        $result     = Parser::evaluate($formula, $recordBean)->evaluate();

        if (is_string($result) === true) {
            $emailAddressId = $this->getEmailAddressId($result);
            if (!$emailAddressId) {
                $emailAddressId = create_guid();
                $this->createEmailAddressId($result, $emailAddressId);
            }

            $result = array(array("email_address" => $result, "email_address_id" => $emailAddressId));
        } else {
            foreach ($result as $key => $emailData) {
                $parentBean = BeanFactory::retrieveBean($emailData["bean_module"], $emailData["bean_id"]);

                $result[$key]["name"] = $parentBean->name ? $parentBean->name : $parentBean->full_name;
            }
        }

        return $result;
    }

    private function createEmailAddressId($result, $emailAddressId)
    {
        $upperCaseEmailAddress = strtoupper($result);
        $qb                    = \DBManagerFactory::getConnection()->createQueryBuilder();
        $qb->insert('email_addresses')->values(
            array(
                "id"                 => "'${emailAddressId}'",
                "email_address"      => "'${result}'",
                "email_address_caps" => "'${upperCaseEmailAddress}'",
                "invalid_email"      => 0,
                "opt_out"            => 0,
                "deleted"            => 0,
            )
        );

        $qb->execute();
    }

    private function getEmailAddressId($emailAddress)
    {
        $emailAddressId = false;

        $queryBuilder = \DBManagerFactory::getConnection()->createQueryBuilder();
        $queryBuilder
            ->select(array("id"))
            ->from("email_addresses");

        $expression = $queryBuilder->expr();
        $and        = $expression->andx();

        $and->add($expression->eq(
            "deleted",
            $queryBuilder->createPositionalParameter(0)
        ));

        $and->add($expression->eq(
            "email_address",
            $queryBuilder->createPositionalParameter($emailAddress)
        ));

        $queryBuilder->where($and);

        $queryBuilderResult = $queryBuilder->execute();
        $emailData          = $queryBuilderResult->fetch();

        if ($emailData) {
            $emailAddressId = $emailData["id"];
        }

        return $emailAddressId;
    }
}
