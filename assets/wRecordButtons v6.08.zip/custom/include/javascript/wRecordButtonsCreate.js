(function extendWRecordButtonsCreateViewFunctionality(app) {
    app.events.on("app:init", function extendWButtonsCreateOnInit() {
        if (!app.view.views.BaseCreateView && !app.view.views.BaseCustomCreateView) {
            app.view.declareComponent("view", "create", undefined, undefined, false, "base");
        }

        var createView = "BaseCreateView";

        if (app.view.views.BaseCustomCreateView) {
            createView = "BaseCustomCreateView";
        }

        if (App.view.views[createView].wCreateViewOverride === true) {
            return;
        }

        App.view.views[createView] = App.view.views[createView].extend({
            wCreateViewOverride: true,

            parentView: null,

            /**
             * We use this extend method because 'create' and 'duration' field have some hardcoded code.
             * Extending 'create' fixes problems with fetching templates for fields.
             *
             * Check against 'isWRecordButtonPresetCreate' is used to
             * check if this view is for 'wrecord button preset record' functionality (used in Studio)
             *
             * @return initSuper undefined
             */
            initialize: function (options) {
                var initSuper = this._super("initialize", arguments);
           
                if (options && options.context && options.context.get("isWRecordButtonPresetCreate")) {
                    this.parentView = options.context.get("parentView");
                }

                if (this.context && this.context.get("isWRecordButtonCreate")) {
                    // manage the dependency fields
                    var modelAttributes = app.wRecordButtonsModel.attributes;
                    this.model.attributes = {};

                    if (modelAttributes.currency_id) {
                        this.model.ignoreUserPrefCurrency = true;
                    }

                    this.model.set(modelAttributes);
                    this.model.link = app.wRecordButtonsModel.link;

                    App.controller.createViewModel = this.model;
                }

                return initSuper;
            },

            /**
             * Make sure preset attributes are set on this drawer
             * @return renderSuper undefined
             */
            _render: function () {
                var renderResult = false;
                
                if (this.context && this.context.get("isWRecordButtonPresetCreate")) {
                    this.prepareModel();
                    renderResult = this._super("_render", arguments);
                    this.prepareView();

                    var timeoutDelay = 100;
                    setTimeout(this.closeSelect2Elements.bind(this), timeoutDelay);
                } else {
                    renderResult = this._super("_render", arguments);
                }
            
                if (this.context
                    && this.context.get("isWRecordButtonCreate")
                    && _.isEmpty(this.model.link) === true
                    && this.context.get("forceParentTypeCopy") === false) {
                    this.model.set("parent_id", undefined);
                    this.model.set("parent_type", undefined);
                }

                return renderResult;
            },

            closeSelect2Elements: function () {
                // close the select2 dropdowns
                var select2Elements = this.$el.find(".select2-container");

                select2Elements.select2("close");
                select2Elements.removeClass("select2-dropdown-open");
                select2Elements.removeClass("select2-container-active");
            },

            prepareModel: function () {
                var self = this;
                var presetAttributes = _.clone(this.parentView.actionParameters.recordAttributes);

                // taking care of the custom fields
                _.each(presetAttributes, function cleanFieldsData(attributeData, attributeKey) {
                    // handling the wAttachmentsField
                    if (
                        self.model.fields[attributeKey] &&
                        self.model.fields[attributeKey].type === "wAttachmentsField"
                    ) {
                        presetAttributes[attributeKey] = window.atob(attributeData);
                    }
                });
                this.model.set(presetAttributes);
            },

            prepareView: function () {
                this.toggleEdit(true);
            },

            saveAndClose: function () {
                if (this.context && this.context.get("isWRecordButtonPresetCreate")) {
                    this.toggleEdit(false);
                    this.parentView.presetDone(this.model);
                    app.drawer.close(this.context, this.model);
                } else {
                    return this._super("saveAndClose", arguments);
                }
                return true;
            },

            cancel: function () {
                if (this.context && this.context.get("isWRecordButtonPresetCreate")) {
                    //Clear unsaved changes on cancel.
                    this.toggleEdit(false);
                    app.events.trigger("create:model:changed", false);
                    this.$el.off();
                    app.drawer.close(this.context);
                    this._dismissAllAlerts();
                } else {
                    return this._super("cancel", arguments);
                }

                return true;
            }
        });
    });
})(SUGAR.App);