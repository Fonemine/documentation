(function extendWRecordButtonsCreateViewFunctionality(app) {
    app.events.on("app:sync:complete", function extendWButtonsCreateOnInit() {
        if (!app.view.layouts.BaseLeadsConvertMainLayout && !app.view.layouts.BaseCustomLeadsConvertMainLayout) {
            app.view.declareComponent("layout", "convert-main", "Leads", undefined, false, "base");
        }

        var leadsConvertView = "BaseLeadsConvertMainLayout";

        if (app.view.layouts.BaseCustomLeadsConvertMainLayout) {
            leadsConvertView = "BaseCustomLeadsConvertMainLayout";
        }

        if (App.view.layouts[leadsConvertView].wConvertViewOverride === true) {
            return;
        }

        App.view.layouts[leadsConvertView] = App.view.layouts[leadsConvertView].extend({
            wConvertViewOverride: true,

            convertComplete: function (level, message, doClose) {
                var leadsModel = this.context.get("leadsModel");
                var recordRouteFunctionality = app.router.record;

                app.router.record = function routeToRecord() {};

                var parentSuper = this._super("convertComplete", arguments);
                var wRecordButton = this.context.get("wRecordButton");
                
                if (wRecordButton) {
                    wRecordButton.executeNextAction();
                }

                app.router.record = recordRouteFunctionality;
                app.router.record("Leads", leadsModel.id);

                return parentSuper;
            }
        });
    });
})(SUGAR.App);
