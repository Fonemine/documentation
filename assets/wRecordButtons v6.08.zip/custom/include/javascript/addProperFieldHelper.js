/**
 * Class Description
 *
 * @class addProperFieldHelper
 */
(function addProperFieldHelper(app) {
    app.events.on("app:init", function initFunction() {
        var _declareClasses = app.metadata._declareClasses;

        app.metadata._declareClasses = function declareClasses(data) {
            _declareClasses.call(this, data);

            if (!data._hash) {
                //We're executing our code after the second components js file has loaded.
                //This ensures that all the controllers are loaded, and nothing will be loaded later that will overwrite our overwrite

                /**
         * Description
         * @method getButtonMeta
         * @param {} view
         * @param {} fieldName
         * @return ret
         */
                var getButtonMeta = function(view, fieldName) {
                    var ret = _.find(
                        _.flatten(view.meta.buttons),
                        function matchFieldName(def) {
                            return def.name == fieldName;
                        }
                    );

                    return ret;
                };
                /*
                * Creates a PROPER field widget.
                *
                * Example:
                * <pre><code>
                * {{properField field view model=mymodel template=edit parent=fieldset}}
                * </code></pre>
                *
                * @method properField
                * @param {Field.Field} fieldName Field name
                * @param {View.View} view Parent view
                * @param {Object} [options] Optional params to pass to the field.
                * @param {Backbone.Model} [options.model] The model associated with the field.
                * @param {check type } [options.template] The name of the template to be used.
                * @param {Field} [options.parent] The parent field of this field.
                * @return {Object} HTML placeholder for the widget as handlebars safe string.
                */

                /**
         * Description
         * @method addHandlebarHelper
         * @param {} fieldName
         * @param {} view
         * @param {} options
         * @return CallExpression
         */
                var addHandlebarHelper = function(fieldName, view, options) {
                    var field = app.view.createField({
                        def:
                            view.getFieldMeta(fieldName) ||
                                getButtonMeta(view, fieldName),
                        view     : view,
                        model    : options.hash.model,
                        viewName : options.hash.template
                    });

                    if (
                        options.hash.parent &&
                        _.isArray(options.hash.parent.fields)
                    ) {
                        options.hash.parent.fields.push(field);
                    }

                    return field.getPlaceholder();
                };

                Handlebars.registerHelper("properField", addHandlebarHelper);
            }
        };
    });
})(SUGAR.App);
