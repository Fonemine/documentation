/**
 * Class Description
 *
 * @class wRecordButtonComposeEmail
 */
(function wRecordButtonComposeEmail(app) {
    app.events.on("app:init", function init() {
        var _declareClasses = app.metadata._declareClasses;

        app.metadata._declareClasses = function declareClasses(data) {
            _declareClasses.call(this, data);

            if (!data._hash) {
                if (typeof App.view.views.BaseEmailsComposeView == "undefined") {
                    App.view.declareComponent("view", "compose", "Emails", undefined, false, "base");
                }

                var composeView = App.view._getBaseComponent("view", "compose", "Emails", "base", false);

                if (!composeView.cache[composeView.moduleBasedClassName].prototype.prePopulateTemplate) {
                    composeView.cache[composeView.moduleBasedClassName] = composeView.cache[
                        composeView.moduleBasedClassName
                    ].extend({
                        prePopulateTemplate: true,

                        /**
                         * Description
                         * @method render
                         * @return
                         */
                        render: function () {
                            var self = this;

                            var renderResult = this._super("render", arguments);

                            if (!this.templateCached) {
                                this.templateCached = true;
                                /**
                                 * Description
                                 * @method applyEmailTemplate
                                 * @param {} template
                                 * @return
                                 */
                                var applyEmailTemplate = function (template) {
                                    self.insertTemplate(template);
                                };

                                setTimeout(function setTemplate() {
                                    var emailTemplateId = self.model.get("emailTemplateId");

                                    if (emailTemplateId) {
                                        var emailTemplate = app.data.createBean("EmailTemplates", {
                                            id: emailTemplateId
                                        });

                                        emailTemplate.fetch({
                                            success: applyEmailTemplate
                                        });
                                    }
                                }, 0);
                            }

                            return renderResult;
                        }
                    });
                }
            }
        };
    });
})(SUGAR.App);
