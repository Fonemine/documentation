/**
 * Class Description
 *
 * @class wHeaderRecordButtons
 */
(function extendFunctionality(app) {
    app.events.on("app:start", function extendFunctionality() {
        /**
         * Description
         * @method extendModuleLogic
         * @param {} moduleRoot
         * @param {} moduleBase
         * @param {} buttonsTableKey
         * @param {} isPreviewButton
         * @return
         */
        var extendModuleLogic = function (moduleRoot, moduleBase, buttonsTableKey, isPreviewButton) {
            var extendedViewName = "Base" + moduleRoot + moduleBase + "View";
            var customExtendedViewName = "BaseCustom" + moduleRoot + moduleBase + "View";

            if (!app.view.views[extendedViewName] && !app.view.views[customExtendedViewName]) {
                App.view.declareComponent("view", moduleBase, moduleRoot, undefined, false, "base");
            }

            if (app.view.views[customExtendedViewName]) {
                extendedViewName = customExtendedViewName;
            }

            if (App.view.views[extendedViewName].wButtonsAdded === true) {
                return;
            }

            App.view.views[extendedViewName] = App.view.views[extendedViewName].extend({
                wButtonsAdded: true,

                replaceCharInString: function (stringValue, charToReplace, newChar) {
                    var regex = new RegExp("\\" + charToReplace);

                    while (stringValue.match(regex)) {
                        stringValue = stringValue.replace(regex, newChar);
                    }

                    return stringValue;
                },

                toggleEdit: function (isEdit) {
                    this._super("toggleEdit", arguments);

                    _.each(this.fields, function handleHeaderButtonVisibility(field) {
                        if (field.type === "buttonset" && field.buttonsData.buttonsSettings.hideOnEdit === true) {
                            if (isEdit) {
                                field.$el.hide();
                            } else {
                                field.$el.show();
                            }
                        }
                    });
                },

                /**
                 * Description
                 * @method render
                 * @return
                 */
                render: function () {
                    if (this.options.meta) {
                        this.wRecordButtonsData = {};

                        var self = this;
                        var allFields = App.metadata.getModule(self.module).fields;
                        self.buttonsTableKey = buttonsTableKey;

                        // get all wRecordButtons
                        _.each(allFields, function searchForRecordHeaderButtons(field) {
   
                            var fieldData = _.clone(field);

                            if (fieldData.type === "buttonset") {
                                // find out if the button is already created
                                var fieldEl = _.chain(self.options.meta[buttonsTableKey])
                                    //eslint-disable-next-line max-nested-callbacks
                                    .filter(function findWRecButton(field) {
                                        return field.realName === fieldData.name;
                                    })
                                    .value();

                                fieldData.options = self.replaceCharInString(fieldData.options, "\\n", "###&&&###");

                                var alreadyCreated = fieldEl.length > 0;
                                fieldData.options = self.replaceCharInString(
                                    fieldData.options.replace(/\\/g, ""),
                                    "=\"",
                                    "='"
                                );
                                fieldData.options = self.replaceCharInString(
                                    fieldData.options.replace(/\\/g, ""),
                                    "\">",
                                    "'>"
                                );

                                fieldData.options = self.replaceCharInString(fieldData.options, ";\"", ";'");
                                fieldData.options = self.replaceCharInString(fieldData.options, "\" >", "' >");
                                fieldData.options = self.replaceCharInString(fieldData.options, "\" />", "' />");
                                fieldData.options = self.replaceCharInString(fieldData.options, "###&&&###", "\\n");

                                try {
                                    var buttonData = JSON.parse(fieldData.options);
                              
                                    if (buttonData.buttonsSettings.showInHeader === true && alreadyCreated === false) {
                                        var originalButtonType = buttonData.buttonsSettings.buttonType;
                                        buttonData = JSON.stringify(buttonData);
                                        fieldData.options = buttonData;
                                        fieldData.isHeaderButton = true;
                                        var buttonName = App.utils.generateUUID();
                                        var newRecordButtonLabel = fieldData.labelValue
                                            ? fieldData.labelValue
                                            : fieldData.vname;
                                        var headerFieldData = {
                                            type            : "buttonset",
                                            name            : buttonName,
                                            options         : fieldData.options,
                                            isHeaderButton  : true,
                                            label           : newRecordButtonLabel,
                                            realName        : fieldData.name,
                                            originalType    : originalButtonType,
                                            isPreviewButton : isPreviewButton,
                                            buttonsTableKey : buttonsTableKey
                                        };

                                        // eslint-disable-next-line max-depth
                                        if (!self.options.meta[buttonsTableKey]) {
                                            self.options.meta[buttonsTableKey] = [];
                                        }

                                        // add the button at the start of the header list
                                        self.options.meta[buttonsTableKey].unshift(headerFieldData);
                                    }
                                } catch (e) {
                                    //
                                }
                                // if we must show it in header and it was not created

                            }
                        });
                    }

                    var renderResult = this._super("render", arguments);

                    var pullRightElements = this.$el.find(".pull-right");
                    var desiredElement = pullRightElements.first("div");
                    desiredElement.css("display", "inline-flex");
                    desiredElement.css("align-items", "center");
                    // eslint-disable-next-line block-scoped-var
                    _.each(self.wRecordButtonsData, function searchForRecordHeaderButtons(wRecButtonData) {
                        if (wRecButtonData.widget.dropdownSize === "btn-large" && this.layout.name !== "preview") {
                            desiredElement.css("margin-top", "-8px");
                        }
                    }.bind(this));

                    // register viewport change events so we can resize buttons
                    var resizeEvents = ["edit_button", "sidebar_toggle"];

                    for (var eventIndex = 0; eventIndex < resizeEvents.length; eventIndex++) {
                        this.registerResizeEvents(resizeEvents[eventIndex]);
                    }

                    return renderResult;
                },

                registerResizeEvents: function (componentName) {
                    var componentField = this.getField(componentName);

                    if (componentField) {
                        componentField.$el.on("click", this.resizeWRecordButtons.bind(this));
                    }
                },
                /**
                 * Description
                 * @method createWRecordHeaderButtons
                 * @return
                 */
                createWRecordHeaderButtons: function () {
                    // after we have all the data gathered we can start creating the buttons
                    var wRecordButtonsFieldsInHeader = _.filter(
                        this.options.meta[this.buttonsTableKey],
                        function getwRecordButtonField(fieldData) {
                            if (fieldData.type === "buttonset") {
                                var buttonData = _.filter(
                                    this.wRecordButtonsData,
                                    function getwRecordButtonWidget(buttonData) {
                                        return buttonData.widget.def.name === fieldData.name;
                                    }.bind(this)
                                )[0];
                    
                                return buttonData.widget && buttonData.widget.buttonsToBeCreated.length > 0;
                            }
                    
                            return false;
                        }.bind(this)
                    ).length;

                    var wActivitiesButtons = 0;

                    wActivitiesButtons = _.filter(this.options.meta[this.buttonsTableKey], function getWRecordButtons(fieldData) {
                        return fieldData.type === "rowaction" && (fieldData.name === "whistorical_narrative_button" || fieldData.name === "whistorical_summary_button");
                    }).length;

                    var maxButtonsAllowedInHeader = 5;

                    wRecordButtonsFieldsInHeader += wActivitiesButtons;

                    var totalNumberOfButtons = 0;

                    // sort the widget by the number of buttons
                    var sortedWRecordButtons = _.sortBy(this.wRecordButtonsData, "buttonsNumber");

                    _.each(sortedWRecordButtons, function getNumberOfButtons(widgetData) {
                        totalNumberOfButtons = totalNumberOfButtons + widgetData.buttonsNumber;
                    });

                    // if we have enough space for rendering all the wRecordButtons fields
                    if (wRecordButtonsFieldsInHeader <= maxButtonsAllowedInHeader) {
                        var remainingSlots = maxButtonsAllowedInHeader;
                        var remainingButtons = totalNumberOfButtons;
                        var buttonsDisplayed = 0;

                        // go through each widget and try to create it
                        for (
                            var sortedWidgetIndex = sortedWRecordButtons.length - 1;
                            sortedWidgetIndex >= 0;
                            sortedWidgetIndex--
                        ) {
                            var widgetData = sortedWRecordButtons[sortedWidgetIndex];
                            var widget = widgetData.widget;
                            var buttonsAdded = widgetData.buttonsNumber;

                            // we want to see if we have enough space to show the widget expanded and not as a dropdown
                            if (remainingButtons > remainingSlots) {
                                var buttonsSettings = widget.buttonsData.buttonsSettings;
                                buttonsSettings.buttonType = "dropDown";
                                widget.containerType = "btn-group";
                                widget.isDropdown = true;
                                buttonsAdded = 1;
                            }

                            remainingButtons = remainingButtons - widgetData.buttonsNumber;
                            remainingSlots = remainingSlots - 1;

                            buttonsDisplayed = buttonsDisplayed + buttonsAdded;
                        }

                        for (
                            var sortedButtonIndex = sortedWRecordButtons.length - 1;
                            sortedButtonIndex >= 0;
                            sortedButtonIndex--
                        ) {
                            // actually creating the buttons
                            sortedWRecordButtons[sortedButtonIndex].widget.createButtonsWidget(buttonsDisplayed);

                            // we need to space the dropdowns in this special case
                            if (sortedWRecordButtons[sortedButtonIndex].widget.isDropdown) {
                                sortedWRecordButtons[sortedButtonIndex].widget.$el.css("margin-left", "10px");
                            }
                        }
                    } else {
                        // if we have more widget than the space available we need to make a big dropdown with all the buttons
                        var masterWidget = sortedWRecordButtons[0].widget;
                        var buttonsToBeCreated = [];
                        var ownButtonsData = _.clone(masterWidget.buttonsData.buttons);
                        var ownButtons = _.clone(masterWidget.buttonsToBeCreated);

                        // we gather all the data inside 1 widget
                        for (var i = 0; i < sortedWRecordButtons.length; i++) {
                            var headerButtonId = App.utils.generateUUID();
                            var headerButtonData = {};

                            headerButtonData[headerButtonId] = {
                                actions          : {},
                                dependencyData   : {},
                                buttonStyle      : "btn-primary",
                                icon             : "fa-cog",
                                label            : sortedWRecordButtons[i].widget.label,
                                orderNumber      : 0,
                                isDropdownHeader : true,
                                showIcon         : false,
                                showLabel        : true,
                                dependencyField  : false,
                                groupId          : headerButtonId
                            };

                            // add a header for each individual widget
                            buttonsToBeCreated.push(headerButtonId);
                            _.extend(masterWidget.buttonsData.buttons, headerButtonData);

                            _.each(sortedWRecordButtons[i].widget.buttonsData.buttons, function addSubgroupId(
                                buttonData
                            ) {
                                buttonData.groupId = headerButtonId;
                            });

                            // put all the widgets into the master one
                            buttonsToBeCreated = buttonsToBeCreated.concat(
                                sortedWRecordButtons[i].widget.buttonsToBeCreated
                            );
                            _.extend(
                                masterWidget.buttonsData.buttons,
                                sortedWRecordButtons[i].widget.buttonsData.buttons
                            );
                        }

                        buttonsToBeCreated = _.uniq(buttonsToBeCreated);

                        // we call it wRecordButtons and create it
                        var ownLabel = masterWidget.label;
                        masterWidget.label = "wRecordButtons";

                        masterWidget.createButtonsWidget(1, buttonsToBeCreated, true);
                        // store all the data into an additional variable
                        masterWidget.masterWidgetData = _.clone(masterWidget.buttonsData.buttons);
                        masterWidget.buttonsData.buttons = ownButtonsData;
                        masterWidget.buttonsToBeCreated = ownButtons;
                        masterWidget.label = ownLabel;
                    }
                },

                resizeWRecordButtons: function () {
                    this.wRecordButtonsSpace = false;
                    this.createWRecordHeaderButtons();
                }
            });
        };

        extendModuleLogic("", "Record", "buttons", false);
        extendModuleLogic("Preview", "Header", "wRecordButtons", true);
    });
})(SUGAR.App);
