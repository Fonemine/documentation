<?php

if (function_exists("pre_uninstall") === false) {
    function pre_uninstall()
    {
        $instance = new Sugarcrm\Sugarcrm\custom\wsystems\wRecordButtons\Setup\Uninstall();
        $instance->preUninstall();
    }
}
