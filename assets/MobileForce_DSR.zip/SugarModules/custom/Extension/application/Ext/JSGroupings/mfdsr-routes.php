<?php

foreach ($js_groupings as $key => $groupings) {
    $target = current(array_values($groupings));

    //if the target grouping is found
    if ($target == 'include/javascript/sugar_grp7.min.js') {
        //append the custom JavaScript file
        $js_groupings[$key]['custom/JavaScript/mfdsr-routes.js'] = 'include/javascript/sugar_grp7.min.js';
    }
}
