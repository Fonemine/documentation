<?php
$module_name='mfdsr_MobileForce_DSR';
$viewdefs[$module_name]['base']['menu']['header'] = array();
