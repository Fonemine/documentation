<?php
$module_name = 'mfdsr_MobileForce_DSR';
$viewdefs[$module_name]['base']['layout']['records'] = array(
    'components' => array(
        array(
            'layout' => array(
                'type' => 'base',
                'name' => 'mfdsr',
                'css_class' => 'mfdsr',
                'components' => array(
                    array(
                        'view' => 'mfdsr-view',
                        'primary' => true,
                    ),
                ),
            ),
        ),
    ),
);
