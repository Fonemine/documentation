({
    className: 'mfdsr-view',
    
    loadData: function (options) {
        console.log("mfdsr-view");
        authData=new Object();
        authData.accessToken = localStorage.getItem('prod:SugarCRM:AuthAccessToken');
        authData.refreshToken = localStorage.getItem('prod:SugarCRM:AuthRefreshToken');
        authData.downloadToken = localStorage.getItem('prod:SugarCRM:DownloadToken');
        var pathArray = document.referrer.split('/');
        var instance = pathArray[2];
        console.log(pathArray);
        authData.instance = instance;
        authData.username = app.user.attributes.user_name;
        authData.display_name = app.user.attributes.full_name;
        authData.email = app.user.attributes.email[0].email_address;
        authData.url = 'https://apps.mobileforcesoftware.com/customers/sugarcrm/instance.php?sugarcrm-instance=' + authData.instance + '&mf-product=dsr' + '&sugarcrm-username=' + authData.username + '&sugarcrm-display_name=' + authData.display_name + '&sugarcrm-email=' + authData.email + '&sugarcrm-accessToken=' + authData.accessToken + '&sugarcrm-refreshToken=' + authData.refreshToken + '&sugarcrm-downloadToken=' + authData.downloadToken;
        if (this.context.attributes.params && this.context.attributes.params.id && this.context.attributes.params.name && this.context.attributes.params.account_id && this.context.attributes.params.account_name)
        {
            // call a new servicetask with pre-populated parameter values
            var params = '{"form":{"account":"{\"key\":\"' + this.context.attributes.params.account_id + '\",\"value\":\"' + this.context.attributes.params.account_name + '\"}","opportunity":"{\"key\":\"' + this.context.attributes.params.id + '\",\"value\":\"' + this.context.attributes.params.name + '\"}"}}';
            authData.url = 'https://apps.mobileforcesoftware.com/customers/sugarcrm/instance.php?sugarcrm-instance=' + authData.instance + '&mf-product=dsr_new' + '&sugarcrm-username=' + authData.username + '&sugarcrm-display_name=' + authData.display_name + '&sugarcrm-email=' + authData.email + '&sugarcrm-accessToken=' + authData.accessToken + '&sugarcrm-refreshToken=' + authData.refreshToken + '&sugarcrm-downloadToken=' + authData.downloadToken + '&params=' + params;
        }
        this.authData = authData;
        this.render();
    }
})
