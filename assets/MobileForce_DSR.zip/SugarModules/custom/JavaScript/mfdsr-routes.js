(function(app){
    app.events.on("router:init", function(){
        var routes = [
            {
                route: 'mfdsr_MobileForce_DSR/:id/:name/:account_id/:account_name',
                name: 'mfdsr_route1',
                callback: function(){
                    console.log("mfdsr_route1");
             	    console.log(arguments);
                    app.controller.loadView({
                        module: 'mfdsr_MobileForce_DSR',
                        layout: 'records',
                        params: {"id":arguments[0],"name":arguments[1],"account_id":arguments[2],"account_name":arguments[3]},
                        create: true
                    });
                }
            }
        ];
        app.router.addRoutes(routes);
    })
})(SUGAR.App);
