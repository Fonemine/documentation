<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$manifest = array (
  'built_in_version' => '10.2.0',
  'acceptable_sugar_versions' => 
  array (
    0 => '10.*',
    0 => '9.*',
  ),
  'acceptable_sugar_flavors' => 
  array (

  ),
  'readme' => '',
  'key' => 'mfdsr',
  'author' => 'MobileForce Software',
  'description' => 'Custom module that integrates MobileForce DSR UI into Sugar UI',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'MobileForce_DSR',
  'published_date' => '2020-11-01 08:00:00',
  'type' => 'module',
  'version' => '1.0.3',
  'remove_tables' => 'prompt',
);


$installdefs = array (
  'id' => 'MobileForce_DSR',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'mfdsr_MobileForce_DSR',
      'class' => 'mfdsr_MobileForce_DSR',
      'path' => 'modules/mfdsr_MobileForce_DSR/mfdsr_MobileForce_DSR.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
  ),
  'relationships' => 
  array (
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/mfdsr_MobileForce_DSR',
      'to' => 'modules/mfdsr_MobileForce_DSR',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/custom/Extension/modules/mfdsr_MobileForce_DSR',
      'to' => 'custom/Extension/modules/mfdsr_MobileForce_DSR',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/custom/modules/mfdsr_MobileForce_DSR',
      'to' => 'custom/modules/mfdsr_MobileForce_DSR',
    ),
    3 =>
    array (
      'from' => '<basepath>/SugarModules/custom/JavaScript/mfdsr-routes.js',
      'to' => 'custom/JavaScript/mfdsr-routes.js',
    ),
    4 =>
    array (
      'from' => '<basepath>/SugarModules/custom/Extension/application/Ext/JSGroupings/mfdsr-routes.php',
      'to' => 'custom/Extension/application/Ext/JSGroupings/mfdsr-routes.php',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
  'image_dir' => '<basepath>/icons',
);
