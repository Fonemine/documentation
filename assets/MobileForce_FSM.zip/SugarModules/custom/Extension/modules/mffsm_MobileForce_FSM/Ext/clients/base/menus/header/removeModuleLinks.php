<?php
$module_name='mffsm_MobileForce_FSM';
$viewdefs[$module_name]['base']['menu']['header'] = array();