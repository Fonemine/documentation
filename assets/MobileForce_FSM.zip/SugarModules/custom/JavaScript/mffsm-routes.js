(function(app){
    app.events.on("router:init", function(){
        var routes = [
            {
                route: 'mffsm_MobileForce_FSM/:id/:name/:account_id/:account_name',
                name: 'mffsm_route1',
                callback: function(){
                    console.log("mffsm_route1");
             	    console.log(arguments);
                    app.controller.loadView({
                        module: 'mffsm_MobileForce_FSM',
                        layout: 'records',
                        params: {"id":arguments[0],"name":arguments[1],"account_id":arguments[2],"account_name":arguments[3]},
                        create: true
                    });
                }
            }
        ];
        app.router.addRoutes(routes);
    })
})(SUGAR.App);
