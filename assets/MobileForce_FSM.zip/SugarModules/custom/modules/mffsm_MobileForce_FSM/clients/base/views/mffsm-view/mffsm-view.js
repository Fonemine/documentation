({
    className: 'mffsm-view',
    
    loadData: function (options) {
        authData=new Object();
        authData.accessToken = localStorage.getItem('prod:SugarCRM:AuthAccessToken');
        authData.refreshToken = localStorage.getItem('prod:SugarCRM:AuthRefreshToken');
        authData.downloadToken = localStorage.getItem('prod:SugarCRM:DownloadToken');
        var pathArray = document.referrer.split('/');
        var instance = pathArray[2];
        authData.instance = instance;
        authData.username = app.user.attributes.user_name;
        authData.display_name = app.user.attributes.full_name;
        authData.email = app.user.attributes.email[0].email_address;
        this.authData = authData;
        this.render();
    }
})
