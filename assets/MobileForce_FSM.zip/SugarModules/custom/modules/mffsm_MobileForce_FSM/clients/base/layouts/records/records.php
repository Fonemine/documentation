<?php
$module_name = 'mffsm_MobileForce_FSM';
$viewdefs[$module_name]['base']['layout']['records'] = array(
    'components' => array(
        array(
            'layout' => array(
                'type' => 'base',
                'name' => 'mffsm',
                'css_class' => 'mffsm',
                'components' => array(
                    array(
                        'view' => 'mffsm-view',
                        'primary' => true,
                    ),
                ),
            ),
        ),
    ),
);
