<?php
$module_name = 'mfcpq_MobileForce_CPQ';
$viewdefs[$module_name]['base']['layout']['records'] = array(
    'components' => array(
        array(
            'layout' => array(
                'type' => 'base',
                'name' => 'mfcpq',
                'css_class' => 'mfcpq',
                'components' => array(
                    array(
                        'view' => 'mfcpq-view',
                        'primary' => true,
                    ),
                ),
            ),
        ),
    ),
);
