(function(app){
    app.events.on("router:init", function(){
        var routes = [
            {
                route: 'mfcpq_MobileForce_CPQ/:id/:name/:account_id/:account_name',
                name: 'mfcpq_route1',
                callback: function(){
                    console.log("mfcpq_route1");
             	    console.log(arguments);
                    app.controller.loadView({
                        module: 'mfcpq_MobileForce_CPQ',
                        layout: 'records',
                        params: {"id":arguments[0],"name":arguments[1],"account_id":arguments[2],"account_name":arguments[3]},
                        create: true
                    });
                }
            }
        ];
        app.router.addRoutes(routes);
    })
})(SUGAR.App);
