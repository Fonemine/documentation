<?php
$module_name='mfcpq_MobileForce_CPQ';
$viewdefs[$module_name]['base']['menu']['header'] = array();