# wRecordButtons
##### Version: 3.71
##### Richard Tinca, Mirel Ivan

## Sugar Compatibility
- Version = <b>1.92</b> (Old edition for wRecordButtons) for Sugar < and > 7.9.
- Version > <b>2.00</b> ( Improved edition for wRecordButtons) for Sugar < and > 7.9.

## Synopsis
Create New FieldType wRecordButton
[*wTools Product (Blog article)*] (https://www.w-systems.com/blog/sugarcrm/custom-buttons)

## Installation
Load the module via Module Loader and then do a "Quick Repair and Rebuild" and "Rebuild JS Grouping Files".
Install also the :
-  wDocs package in order to have the "Merge Documents" action available on wRecord button.
-  wForms package in order to have the "wForms" action available on wRecord button.

## Configuration
No configuration required

## QA Summary
Current QAd versions bellow, please see test/README.md for QA history.

## System Dependencies
Which fields does this package use, which modules, which relationships

## Developer Notes
Misc notes & concerns about the package

## PM Notes
Project manager notes that may concern other project managers.
