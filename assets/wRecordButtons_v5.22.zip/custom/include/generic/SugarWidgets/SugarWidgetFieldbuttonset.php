<?php

class SugarWidgetFieldbuttonset extends SugarWidgetReportField
{}
