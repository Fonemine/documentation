(function extendDurationFieldForWRecordButtons(app) {
    app.events.on("app:start", function extendDurationOnAppStart() {
        if (
            !app.view.fields.BaseDurationField &&
            !app.view.fields.BaseCustomDurationField
        ) {
            app.view.declareComponent(
                "field",
                "duration",
                undefined,
                undefined,
                false,
                "base"
            );
        }

        var durationField = "BaseDurationField";

        if (app.view.fields.BaseCustomDurationField) {
            durationField = "BaseCustomDurationField";
        }

        if (App.view.fields[durationField].wRecordButtonDurationFix === true) {
            return;
        }

        App.view.fields[durationField] = App.view.fields[durationField].extend({
            wRecordButtonDurationFix: true,

            initialize: function(options) {
                var initResult = this._super("initialize", arguments);
                if (
                    this.view &&
                    this.view.context &&
                    this.view.context.attributes &&
                    this.view.context.attributes.isWRecordButtonCreate
                ) {
                    this.updateDurationHoursAndMinutes();
                }
                return initResult;
            }
        });
    });
})(SUGAR.App);
