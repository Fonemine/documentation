(function extendwRecordButtonsListView(app) {
    app.events.on("app:start", function extendwRecordButtonsListView() {
        var extendListView = function (viewMetaName, viewName) {
            if (!app.view.views["Base" + viewName + "View"] && !app.view.views["BaseCustom" + viewName + "View"]) {
                app.view.declareComponent("view", viewMetaName, undefined, undefined, false, "base");
            }

            var listView = "Base" + viewName + "View";

            if (app.view.views["BaseCustom" + viewName + "View"]) {
                listView = "BaseCustom" + viewName + "View";
            }

            if (app.view.views[listView].wRButtonListViewOverride === true) {
                return;
            }

            app.view.views[listView] = app.view.views[listView].extend({
                wRButtonListViewOverride : true,
                columnsChanged           : false,
                checkedRows              : {},

                initialize: function (options) {
                    var initSuper = this._super("initialize", arguments);

                    this.collection.on("data:sync:complete", this.manageWRButtons.bind(this));
                    this.on("list:toggle:column", this.notifyColumnChange.bind(this));
                    this.on("list:reorder:columns", this.notifyColumnChange.bind(this));

                    return initSuper;
                },

                render: function (options) {
                    var renderSuper = this._super("render", arguments);

                    this.checkedRows = {};

                    if (this.columnsChanged) {
                        this.columnsChanged = false;
                        this.manageWRButtons();
                    }

                    return renderSuper;
                },

                notifyColumnChange: function () {
                    this.columnsChanged = true;
                },

                manageWRButtons: function () {
                    var self = this;
                    var dependenciesToBeChecked = [];
                    var sets = 0;
                    var setLimit = 5;
                    var hasChanges = false;

                    _.each(this.rowFields, function goThroughAllRows(rowData, rowId) {
                        if (!dependenciesToBeChecked[sets]) {
                            dependenciesToBeChecked[sets] = {};
                        }
                        if (!self.checkedRows[rowId]) {
                            dependenciesToBeChecked[sets][rowId] = {};

                            _.each(rowData, function getWRBField(fieldData, fieldId) {
                                if (fieldData.type === "buttonset") {
                                    dependenciesToBeChecked[sets][rowId][fieldData.name] = {
                                        fieldsToBeUpdated : fieldData.updateFieldParams,
                                        recordId          : rowId,
                                        recordType        : self.model.module
                                    };

                                    hasChanges = true;
                                }
                            });

                            if (Object.keys(dependenciesToBeChecked[sets]).length >= setLimit) {
                                sets = sets + 1;
                            }
                        }
                    });

                    for (var index = 0; index < dependenciesToBeChecked.length; index++) {
                        var element = dependenciesToBeChecked[index];

                        // checking buttons dependency
                        var updateField = {
                            success: function (expressionValues) {
                                if (!this.disposed) {
                                    _.each(expressionValues, function manageWRButtonsDisplay(rowData, rowId) {
                                        self.checkedRows[rowId] = true;

                                        _.each(rowData, function getWRBField(fieldData, fieldName) {
                                            var fieldWidget = _.filter(self.rowFields[rowId], function getField(field) {
                                                return field.name === fieldName;
                                            })[0];

                                            if (fieldWidget) {
                                                fieldWidget.createDependentButtons(expressionValues[rowId][fieldName]);
                                            }
                                        });
                                    });
                                }
                            }.bind(this)
                        };

                        var reqParamsObject = {
                            rowsData: element,
                        };

                        if (hasChanges) {
                            app.api.call(
                                "create",
                                app.api.buildURL("EvaluateExpression/calculate_dependency_list"),
                                reqParamsObject,
                                null,
                                updateField
                            );
                        }
                    }
                },
            });
        };

        extendListView("recordList", "Recordlist");
        extendListView("SubpanelList", "SubpanelList");
    });
})(SUGAR.App);