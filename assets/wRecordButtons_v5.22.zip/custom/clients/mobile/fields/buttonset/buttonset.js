/**
 * Class Description
 *
 * @class buttonset
 */
({
    buttons               : [],
    dependencyRequests    : [],
    buttonsToBeCreated    : [],
    buttonsData           : {},
    updateFieldParams     : {},
    actionsBannedOnMobile : ["tabsManagement", "saveRecord"],
    createdButtons        : false,
    buttonId              : false,

    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.modelId = this.model.id;

        // in case the name was messed up outside of this class we have to put it back
        this.name = this.def.realName ? this.def.realName : this.name;
        this.buttonId = app.utils.generateUUID();

        // parse the data came from the studio
        this.def.options = this.replaceCharInString(this.def.options.replace(/\\/g, ""), "=\"", "='");
        this.def.options = this.replaceCharInString(this.def.options, ";\"", ";'");
        this.def.options = this.replaceCharInString(this.def.options.replace(/\\/g, ""), "\">", "'>");
        this.def.options = this.replaceCharInString(this.def.options, "\" >", "' >");
        this.def.options = this.replaceCharInString(this.def.options, "\" />", "' />");

        this.buttonsData = JSON.parse(this.def.options);

        // try creating the buttons
        this.tryCreateButtonsList();
        var self = this;

        var onAfterShow = this.view.onAfterShow.bind(this.view);
        //eslint-disable-next-line 
        this.view.onAfterShow = function () {
            onAfterShow();

            self.tryCreateButtonsList();
        };

        return initResult;
    },

    tryCreateButtonsList: function () {
        this.clearButtons();
        this.createButtonsList();

        return true;
    },

    initializeWRecordButtonsData: function () {
        this.resetCachedVariables();

        // set the properties needed for rendering the field
        _.each(
            this.buttonsData.buttons,
            function updateButtons(buttonData, buttonId) {
                if (buttonData.dependencyField === true) {
                    this.verifyDependency(buttonData.dependencyData.formulaElement, buttonId);
                } else {
                    if (!_.contains(this.buttonsToBeCreated, buttonId)) {
                        this.buttonsToBeCreated.push(buttonId);
                    }
                }
            }.bind(this)
        );
    },

    createButtonsList: function () {
        this.initializeWRecordButtonsData();

        if (Object.keys(this.updateFieldParams).length > 0 && window.navigator.onLine === true) {
            var self = this;

            // checking buttons dependency
            var updateField = {
                success: function (expressionValues) {
                    // create the buttons that passed the dependency test
                    _.each(expressionValues, function tryStoreButtonData(data, id) {
                        if (data.value === "true") {
                            if (!_.contains(self.buttonsToBeCreated, data.buttonId)) {
                                self.buttonsToBeCreated.push(data.buttonId);
                            }
                        }
                    });

                    self.createWRecordButtons();
                }
            };

            var id = this.model ? this.model.get("id") : "";
            var reqParamsObject = {
                fieldsToBeUpdated : this.updateFieldParams,
                recordType        : this.module,
                recordId          : id,
                dependency        : true
            };

            app.api.call(
                "create",
                app.api.buildURL("EvaluateExpression/calculate_dependency"),
                reqParamsObject,
                null,
                updateField
            );
        } else {
            this.createWRecordButtons();
        }
    },

    replaceCharInString: function (brokenFormula, charToReplace, newChar) {
        var formulaBody = brokenFormula;
        var regex = new RegExp("\\" + charToReplace);

        while (formulaBody.match(regex)) {
            formulaBody = formulaBody.replace(regex, newChar);
        }

        return formulaBody;
    },

    createWRecordButtons: function () {
        if (!this.def.isHeaderButton) {
            this.createButtonsWidget();
        }
    },

    createButtonsWidget: function () {
        if (this.model) {
            this.buttons = [];
            var buttonsToBeCreated = _.clone(this.buttonsToBeCreated);

            for (var index = 0; index < buttonsToBeCreated.length; index++) {
                var currentButtonId = buttonsToBeCreated[index];

                if (this.buttonsData.buttons[currentButtonId]) {
                    buttonsToBeCreated[index] = {
                        buttonId    : currentButtonId,
                        buttonOrder : this.buttonsData.buttons[currentButtonId].orderNumber
                    };
                }
            }

            // order the buttons
            buttonsToBeCreated.sort(function sortButtons(firstButton, secondButton) {
                return firstButton.buttonOrder - secondButton.buttonOrder;
            });

            // set the properties needed for rendering the field
            for (var i = 0; i < buttonsToBeCreated.length; i++) {
                this.createButton(buttonsToBeCreated[i].buttonId || buttonsToBeCreated[i]);
            }

            this._render();

            var eventTimer = 1000;
            setTimeout(
                function registerEvent() {
                    if (this.$el) {
                        this.$el.find(".uRecordButton").off("click");
                        this.$el.find(".uRecordButton").click(this.buttonClicked.bind(this));

                    }
                }.bind(this),
                eventTimer
            );
            this.handleMobileButtons();
        }
    },

    render: function () {
        var renderResult = this._super("render", arguments);

        this.registerMobileButtonsEvents();

        return renderResult;
    },

    registerMobileButtonsEvents: function () {
        app.controller.off("wMaps-collection-route-changed");
        app.controller.on("wMaps-collection-route-changed", this.handleMobileButtons.bind(this));
    },

    handleMobileButtons: function () {
        _.each(
            this.buttonsData.buttons,
            function adjustViews(buttonData) {
                var validRouteButton =
                    _.filter(buttonData.actions, function getRouteButton(actionData) {
                        return actionData.action === "handleRoute";
                    }).length === 1;

                if (validRouteButton) {
                    this.showValidRouteButton(buttonData.iconId);
                }
            },
            this
        );
    },

    clearButtons: function () {
        this.buttons = [];
        this.buttonsToBeCreated = [];
    },

    verifyDependency: function (dependencyFormula, id) {
        var uniqueIdentifier = app.utils.generateUUID();
        dependencyFormula = dependencyFormula.replace(/'/g, "\"");
        var params = {
            formula     : dependencyFormula,
            model       : JSON.stringify(this.model),
            targetField : this.name,
            buttonId    : id
        };

        this.updateFieldParams[uniqueIdentifier] = params;
    },

    createButton: function (buttonId) {
        var buttonData = this.buttonsData.buttons[buttonId];

        _.each(
            buttonData.actions,
            function removeBannedActions(actionData, actionId) {
                if (this.actionsBannedOnMobile.indexOf(actionData.action) > -1) {
                    delete buttonData.actions[actionId];
                }
            },
            this
        );

        var actionsNumber = Object.keys(buttonData.actions).length;
        if (actionsNumber > 0) {
            var buttonIcon = "fa " + buttonData.icon;
            var iconColor = buttonData.iconColor ? buttonData.iconColor : "black";
            var buttonLabel = buttonData.label;
            var iconId = app.utils.generateUUID();

            this.createdButtons = true;
            buttonData.iconId = iconId;
            var createdButtonData = {
                buttonId  : buttonData.index,
                index     : buttonData.orderNumber,
                icon      : buttonIcon,
                iconId    : iconId,
                label     : buttonLabel,
                iconColor : iconColor,
                dependent : buttonData.dependencyField
            };

            if (this.tplName === "list" || (this.view && this.view.name.indexOf("list") > -1)) {
                var insertAtPos = this.buttons.length - 1;
                var maxButtonsOnRow = 4;

                if (insertAtPos < 0) {
                    insertAtPos++;
                    this.buttons.push([]);
                }

                if (this.buttons[insertAtPos].length === maxButtonsOnRow) {
                    this.buttons.push([]);
                    insertAtPos++;
                }

                this.buttons[insertAtPos].push(createdButtonData);
            } else {
                this.buttons.push(createdButtonData);
            }
        }
    },

    buttonClicked: function (e) {
        e.preventDefault();
        e.stopPropagation();
        var buttonData = this.buttonsData.buttons[e.currentTarget.id];

        var animationDuration = 150;
        var animationDurationFinished = 100;
        var iconId = e.currentTarget.children[0].children[0].getAttribute("name");

        this.$el.find("[name=\"" + iconId + "\"]").animate({
            opacity: "0.2"
        }, {
            complete: function callbackTransition() {
                setTimeout(
                    function fadeBackIn() {
                        this.$el.find("[name=\"" + iconId + "\"]").animate({
                            opacity: 1
                        }, animationDuration);
                    }.bind(this),
                    animationDurationFinished
                );
            }.bind(this),

            duration: animationDuration
        });

        // if the button clicked is a wRecordButton and has valid data we check its actions
        if (buttonData) {
            this.model.iconId = buttonData.iconId;
            app.controller.trigger("wRBActionsTriggered", _.clone(buttonData.actions), this.model);
        }
    },

    resetCachedVariables: function () {
        // reset all cached parameters
        this.updateFieldParams = {};
    },

    showValidRouteButton: function (iconId) {
        var iconEl = this.$el.find("[name=\"" + iconId + "\"]");
        var $labelEL = iconEl
            .parent()
            .parent()
            .children()
            .children()[1];

        iconEl.removeClass(iconEl.attr("class"));

        if (app.mobile.wMapsContextButtons.wMapsMobileButtonsVisibility.canShowAddToRouteButton()) {
            iconEl.addClass("fas fa-plus-circle");
            iconEl.css("color", "#4CAF50");

            if ($labelEL) {
                $labelEL.textContent = "Route Add";
            }
        } else {
            iconEl.addClass("fas fa-minus-circle");
            iconEl.css("color", "#f44336");
            if ($labelEL) {
                $labelEL.textContent = "Route Remove";
            }
        }
    },
});