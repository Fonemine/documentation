/**
 * Class Description
 *
 * @class wrecord-button-assign-record
 */
({
    events: {
        "change [name='assignedToUser']": "handleParamsChange",
    },

    users: {
        currentUser: "Logged In User"
    },

    actionParameters: {
        assignedToUserId   : "",
        assignedToUserName : "",
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        this.populateUsersList();

        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            assignedToUserId   : "",
            assignedToUserName : "",
        };

        return initResult;
    },

    populateUsersList: function () {
        app.api.call("read", app.api.buildURL("Users"), false, {
            success: function getResultRecords(result) {
                _.each(result.records, function getUsers(userData) {
                    this.users[userData.id] = userData["full_name"];
                }.bind(this));

                // convert them to select2
                this.$el.find("[name='assignedToUser']").select2(this.getCustomSelect2Options());

                this.updateView();
            }.bind(this)
        });
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        // convert them to select2
        this.$el.find("[name='assignedToUser']").select2(this.getCustomSelect2Options());

        this.updateView();
        return renderResult;
    },

    execute: function (buttonData) {
        var currentUserId = buttonData.actionParameters.assignedToUserId;
        var currentUserName = buttonData.actionParameters.assignedToUserName;

        if (currentUserId === "currentUser") {
            currentUserId = app.user.get("id");
            currentUserName = app.user.get("full_name");
        }

        this.model.set("assigned_user_id", currentUserId);
        this.model.set("assigned_user_name", currentUserName);
        this.model.save();

        this.executeNextAction();
    },

    updateView: function () {
        var hasUserSelected = this.actionParameters.assignedToUserName !== "";
        var assignedToUser = hasUserSelected ? this.actionParameters.assignedToUserName : "Select User";

        // set default or saved values for the elements in this view
        this.$el.find("[name='assignedToUser']").select2("data", {
            id   : this.actionParameters.assignedToUserId,
            text : assignedToUser
        });
    },

    /**
     * Description
     * @method getCustomSelect2Options
     * @param {} optionsType
     * @param {} getModules
     * @return select2Options
     */
    getCustomSelect2Options: function () {
        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this._queryUsers, this);
        select2Options.selectOnBlur = true;
        select2Options.formatResult = this.formatResult.bind(this);

        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text === "Logged In User") {
                    return -1;
                } else if (secondLabel.text === "Logged In User") {
                    return 1;
                }

                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    formatResult: function (optionElement) {
        if (optionElement.text === "Logged In User") {
            var $state = $("<span><strong>" + optionElement.text + "</strong></span>");
            return $state;
        } else {
            return optionElement.text;
        }
    },

    _queryUsers: function (query) {
        var listEntry = this.users;
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listEntry)) {
            _.each(listEntry, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listEntry = null;
        }

        query.callback(data);
    },

    _initSelection: function () { },

    /**
     * Description
     * @method handleParamsChange
     * @param {} event
     * @return
     */
    handleParamsChange: function (event) {
        // update the data in the main model
        this.actionParameters.assignedToUserId = event.added.id;
        this.actionParameters.assignedToUserName = event.added.text;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);

        this.updateView();
    }
});