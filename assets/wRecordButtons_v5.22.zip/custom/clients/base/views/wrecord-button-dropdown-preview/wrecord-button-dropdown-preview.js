/**
 * Class Description
 *
 * @class wrecord-button-dropdown-preview
 */
({
    iconStyle         : "",
    buttonsData       : null,
    iconOnLeft        : false,
    dropdownPopulated : false,
    dropdownStyle     : null,
    dropdownSize      : null,
    dropdownIcon      : null,
    dropdownLabel     : null,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        // get data from the main model
        this.buttonsData = options.model.attributes;
        this.populateButtonsList();

        return initResult;
    },

    /**
     * Description
     * @method populateButtonsList
     * @return
     */
    populateButtonsList: function () {
        // initialize the params needed for the rendering
        this.buttons = [];
        this.iconOnLeft =
            this.buttonsData.buttonsSettings.iconPlacement === "left";
        this.iconStyle = this.buttonsData.buttonsSettings.buttonSize ===
            "btn-large" ?
            "font-size:large" :
            "";
        this.dropdownSize = this.buttonsData.buttonsSettings.buttonSize;
        this.dropdownStyle = "btn-primary";
        this.dropdownIcon = this.buttonsData.buttonsSettings.showDropdownIcon === true ? "fa fa-cogs" : "";
        this.dropdownLabel = this.buttonsData.fieldLabel;

        this.dropdownPopulated = false;
        _.each(
            this.buttonsData.buttons,
            function updateButtons(buttonData, buttonId) {
                var buttonIcon = buttonData.showIcon === true ?
                    "fa " + buttonData.icon :
                    "";
                var buttonLabel = buttonData.showLabel === true ?
                    buttonData.label :
                    "";

                if (!this.isTabManagementButton(buttonData)) {
                    this.buttons.push({
                        index       : buttonData.orderNumber,
                        buttonStyle : buttonData.buttonStyle,
                        icon        : buttonIcon,
                        label       : buttonLabel
                    });

                    this.dropdownPopulated = true;
                }
            }.bind(this)
        );

        // sort the list properly
        this.buttons.sort(function sortButtons(firstButton, secondButton) {
            return firstButton.index - secondButton.index;
        });

        if (this.buttons.length === 0) {
            $("#previewFieldLabel").hide();
        } else {
            $("#previewFieldLabel").show();
        }
    },

    isTabManagementButton: function (buttonData) {
        var isTabMngmtButton = false;

        _.each(buttonData.actions, function goThroughActions(actionData) {
            if (actionData.action === "tabsManagement") {
                isTabMngmtButton = true;
            }
        });

        return isTabMngmtButton && Object.keys(buttonData.actions).length <= 1;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        return renderResult;
    }
});