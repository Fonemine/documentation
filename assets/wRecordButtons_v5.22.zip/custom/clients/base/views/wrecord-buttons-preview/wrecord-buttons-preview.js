/**
 * Class Description
 *
 * @class wrecord-buttons-preview
 */
({
    buttonsData   : null,
    containerType : null,
    iconOnLeft    : true,
    buttons       : [],
    isHeader      : false,
    maxFreeSpace  : 0,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.buttonsData = options.model.attributes;

        this.isHeader = options.showInHeader;

        this.populateButtonsList();

        return initResult;
    },

    /**
     * Description
     * @method populateButtonsList
     * @return
     */
    populateButtonsList: function () {
        // initialize the params needed for the rendering
        this.buttons = [];
        this.iconOnLeft = this.buttonsData.buttonsSettings.iconPlacement === "left";
        this.containerType = this.buttonsData.buttonsSettings.buttonType === "buttons" ? "btn-list" : "btn-group";

        var screenRatio = 0.18;
        this.maxFreeSpace = window.innerWidth * screenRatio;
        var maxButtonSize = this.maxFreeSpace / Object.keys(this.buttonsData.buttons).length;

        _.each(
            this.buttonsData.buttons,
            function updateButtons(buttonData, buttonId) {
                var buttonIcon = buttonData.showIcon === true ? "fa " + buttonData.icon : "";
                var isLarge = this.buttonsData.buttonsSettings.buttonSize === "btn-large";
                var iconSize = isLarge === true ? "font-size:large" : "";
                var labelSpacing = isLarge === true ? "  " : "";
                var buttonLabel = buttonData.showLabel === true ? buttonData.label : "";

                if (isLarge === true && buttonData.showLabel === true && buttonData.showIcon === true) {
                    buttonLabel = this.iconOnLeft === true ? labelSpacing + buttonLabel : buttonLabel + labelSpacing;
                }

                if (!this.isTabManagementButton(buttonData)) {
                    this.buttons.push({
                        index              : buttonData.orderNumber,
                        icon               : buttonIcon,
                        label              : buttonLabel,
                        iconStyle          : iconSize,
                        style              : buttonData.buttonStyle,
                        generalDescription : buttonData.generalDescription,
                        iconColor          : buttonData.iconColor,
                        maxButtonSize      : maxButtonSize,
                        buttonId           : App.utils.generateUUID(),
                        size               : this.buttonsData.buttonsSettings.buttonSize
                    });
                }
            }.bind(this)
        );

        this.buttons.sort(function sortButtons(firstButton, secondButton) {
            return firstButton.index - secondButton.index;
        });

        if (this.buttons.length === 0) {
            $("#previewFieldLabel").hide();
        } else {
            $("#previewFieldLabel").show();
        }
    },

    isTabManagementButton: function (buttonData) {
        var isTabMngmtButton = false;

        _.each(buttonData.actions, function goThroughActions(actionData) {
            if (actionData.action === "tabsManagement") {
                isTabMngmtButton = true;
            }
        });

        return isTabMngmtButton && Object.keys(buttonData.actions).length <= 1;
    },

    /**
     * Description
     * @method resizeButtons
     * @return
     */
    resizeButtons: function () {
        var unusedSpaceData = this.getUnusedSpace();

        var largerButtons = unusedSpaceData.largerButtons.length;

        if (largerButtons > 0 && unusedSpaceData.unusedSpace > 0) {
            var enlargementWidth = unusedSpaceData.unusedSpace / largerButtons;

            for (var i = 0; i < unusedSpaceData.largerButtons.length; i++) {
                var buttonId = unusedSpaceData.largerButtons[i];
                var buttonEl = this.$el.find("#" + buttonId);
                var maxWidth = buttonEl.css("max-width");
                var maxSize = parseFloat(maxWidth.replace("px", "")) + enlargementWidth + "px";

                buttonEl.css("max-width", maxSize);
            }
        }
    },

    /**
     * Description
     * @method getUnusedSpace
     * @return ObjectExpression
     */
    getUnusedSpace: function () {
        var maxButtonSize = this.maxFreeSpace / Object.keys(this.buttonsData.buttons).length;
        var unusedSpace = 0;
        var largerButtons = [];

        for (var i = 0; i < this.buttons.length; i++) {
            var buttonId = this.buttons[i].buttonId;
            var buttonEl = this.$el.find("#" + buttonId);
            var treshold = 0.25;

            var spaceLeft = maxButtonSize - buttonEl.width();
            unusedSpace = unusedSpace + spaceLeft;

            if (spaceLeft <= treshold) {
                largerButtons.push(buttonId);
            }
        }

        return {
            unusedSpace   : unusedSpace,
            largerButtons : largerButtons
        };
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);

        if (this.isHeader) {
            this.resizeButtons();
        }

        return renderResult;
    }
});