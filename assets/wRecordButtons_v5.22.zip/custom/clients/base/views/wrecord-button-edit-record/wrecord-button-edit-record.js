/**
 * Class Description
 *
 * @class wrecord-button-create-record
 */
({
    events: {
        "click #presetButton": "openCreateView"
    },

    actionParameters: {
        recordAttributes  : {},
        defaultAttributes : false
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            recordAttributes  : {},
            defaultAttributes : false,
            executeView       : this.name
        };

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.showPresetButton(true);
        this.updateView();

        return renderResult;
    },

    execute: function (buttonData) {
        var listModel = false;

        if (app.acl.hasAccess("edit", this.model.module)) {
            var recordAttributes = _.clone(buttonData.actionParameters.recordAttributes);

            if (this.tplName == "detail" || this.tplName == "record") {
                if (this.view.editClicked) {
                    this.view.editClicked();
                }
            } else if (this.tplName == "list") {
                var self = this;
                var editButton = false;

                _.each(self.view.fields, function findFieldParent(parentData) {
                    _.each(parentData.fields, function findField(fieldData) {
                        _.each(fieldData.fields, function findEditField(newFieldData) {
                            if (
                                newFieldData.name === "edit_button" &&
                                self.model.get("id") === newFieldData.model.get("id")
                            ) {
                                editButton = newFieldData;
                            }
                        });
                    });
                });

                if (this.view.editClicked) {
                    listModel = editButton.model;
                    this.view.editClicked(editButton.model, editButton);
                }
            } else if (this.tplName === "preview") {
                if (this.view.layout) {
                    var previewLayout = this.view.layout.getComponent("preview-header");
                    previewLayout.toggleSaveAndCancel(true);
                    $(".btn-list")
                        .next()
                        .hide();
                    this.view.handleEdit();
                }
            } else if (this.view && this.view.tplName === "preview-header") {
                if (this.view.layout) {
                    $(".btn-list")
                        .next()
                        .hide();
                    this.view.toggleSaveAndCancel(true);

                    _.each(this.view.layout._components, function getMetaPanels(componentData) {
                        if (componentData.tplName === "preview") {
                            componentData.handleEdit();
                        }
                    });
                    this.view.context.attributes.model.set(recordAttributes);
                }
            }

            if (listModel) {
                listModel.set(recordAttributes);
            } else {
                this.view.model.set(recordAttributes);

            }

            this.executeNextAction();
        } else {
            this.showNoAccessAlert();
        }
    },

    /**
     * Description
     * @method presetDone
     * @param {} model
     * @return
     */
    presetDone: function (model) {
        // show the new fields modified
        this.actionParameters.defaultAttributes = this.actionParameters.defaultAttributes || _.clone(model._defaults);
        var attributes = _.clone(model.attributes);
        var self = this;

        // clean the attributes
        _.each(this.actionParameters.defaultAttributes, function cleanAttributes(defaultValue, key) {
            if (
                !(key in attributes) ||
                (defaultValue === null && attributes[key] === null) ||
                attributes[key] == self.actionParameters.defaultAttributes[key] ||
                (attributes[key] !== null &&
                    attributes[key].constructor === Array &&
                    attributes[key].toString() === self.actionParameters.defaultAttributes[key].toString() &&
                    !(key in model.changed))
            ) {
                delete attributes[key];
            }
        });

        _.each(attributes, function cleanAttributes(value, key) {
            if (
                !(key in model.fields) ||
                value === null ||
                value === undefined ||
                value === "" ||
                key === "revenuelineitems" ||
                key === "_revenuelineitems-rel_exp_values" ||
                (model.fields[key].type === "wAttachmentsField" && value === "[]")
            ) {
                delete attributes[key];
            }

            // handle special cases like custom packages with custom fields
            // handling the wAttachmentsField
            if (model.fields[key] && model.fields[key].type === "wAttachmentsField" && value !== "[]") {
                attributes[key] = window.btoa(attributes[key]);
            }

        });

        // get rid of unused data
        delete attributes["records"];

        this.actionParameters.recordAttributes = attributes;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        this.addNewFieldInfo(attributes);
    },

    /**
     * Description
     * @method addNewFieldInfo
     * @param {} attributes
     * @return
     */
    addNewFieldInfo: function (attributes) {
        var self = this;
        var container = this.$el.find("#presetInfoContainer");
        var module = this.options.manager.model.get("moduleName");
        var moduleDef = App.metadata.getModule(module);

        container.empty();

        if (moduleDef) {
            var fieldsInfo = moduleDef.fields;
            var subpanelId = App.utils.generateUUID();
            var fieldNameLang = app.lang.get("LBL_WRB_ACTION_FIELD_NAME");
            var fieldValueLang = app.lang.get("LBL_WRB_ACTION_FIELD_VALUE");
            var removeFieldLang = app.lang.get("LBL_WRB_ACTION_REMOVE_FIELD");
            container.append(
                "<div class=\"row-fluid record-panel\" data-panelname=\"panel_body\" id=\"presetRecordPane\" style=\"margin-left:-15px;\">\
<div class=\"row-fluid record-panel-header panel-active\" data-parent = \"accordion\" id=\"panelToggle\" href=\"#" +
                subpanelId +
                "\">\
<h5 class=\"pull-left\">\
Preset Fields\
</h5>\
</div>\
<div class=\"row-fluid panel-collapse collapse in\" style=\"display: block;\">\
<table class=\"table table-striped table-bordered table-condensed\">\
<thead>\
<tr>\
<th><span style=\"margin-left: 2.5%;width:365px;\">" + fieldNameLang + "</span></th>\
<th><span style=\"margin-left: 2.5%;width:365px;\">" + fieldValueLang + "</span></th>\
<th><span style=\"margin-left: 2.5%;width:365px;\">" + removeFieldLang + "</span></th>\
</tr>\
</thead> \
<tbody  id=\"" +
                subpanelId +
                "\">\
</tbody>\
</table>\
</div>\
</div>"
            );
            var fieldsContainer = container.find("#" + subpanelId);
            //eslint-disable-next-line no-unused-vars
            var iteratorIndex = 0;

            _.each(attributes, function addField(fieldValue, fieldName) {
                if (fieldValue !== undefined && fieldValue !== null && fieldValue !== "") {
                    iteratorIndex++;

                    var removeFieldButton = fieldName;

                    // handle different field types
                    if (fieldName === "email") {
                        var emails = [];

                        for (var i = 0; i < fieldValue.length; i++) {
                            emails.push(fieldValue[i].email_address);
                        }

                        fieldValue = emails;
                    } else if (fieldName === "tag") {
                        var tags = [];

                        for (var tagIndex = 0; tagIndex < fieldValue.length; tagIndex++) {
                            tags.push(fieldValue[tagIndex]);
                        }

                        fieldValue = tags;
                    } else if (fieldName === "team_name") {
                        var teams = [];

                        for (var teamIndex = 0; teamIndex < fieldValue.length; teamIndex++) {
                            teams.push(fieldValue[teamIndex].name);
                        }

                        fieldValue = teams;
                    } else if (typeof fieldValue == "object") {
                        fieldValue = "Custom Value";
                    } else if (!fieldsInfo[fieldName]) {
                        fieldValue = "Custom Value";
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "datetimecombo") {
                        var dateValue = App.date(fieldValue);
                        fieldValue = dateValue.formatUser(false);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "currency") {
                        var indexOffset = 4;
                        fieldValue = fieldValue.toString();
                        fieldValue = fieldValue.substr(0, fieldValue.indexOf(".") + indexOffset);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "int") {
                        fieldValue = Math.round(fieldValue);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "date") {
                        var formatDate = App.date(fieldValue);

                        fieldValue = formatDate.formatUser(true);
                    } else if (fieldsInfo[fieldName] && fieldsInfo[fieldName].type === "wAttachmentsField") {
                        fieldValue = "Custom Value";
                    }

                    // format the display text
                    if (fieldName.indexOf("_c") > -1 && !fieldsInfo[fieldName]) {
                        var fieldNameIndexOffset = 2;
                        fieldName = fieldName.substring(0, fieldName.indexOf("_c") + fieldNameIndexOffset);
                    }

                    // get the field label
                    var fieldLabel = fieldsInfo[fieldName] ? fieldsInfo[fieldName]["vname"] : fieldName;
                    var fieldDisplayText = App.lang.get(fieldLabel, self.options.manager.model.get("moduleName"));

                    // if we do not have a translation for the field we should not show it as changed
                    if (
                        typeof fieldLabel != "undefined" && //Calls ->auto_invite_parent does not have a label
                        fieldDisplayText.indexOf("LBL") < 0 &&
                        fieldDisplayText !== "next_offset"
                    ) {
                        if (fieldDisplayText.indexOf("_") > -1) {
                            fieldDisplayText = fieldDisplayText.substring(0, fieldDisplayText.indexOf("_"));

                            if (fieldsInfo[fieldDisplayText] && fieldsInfo[fieldDisplayText].vname) {
                                fieldDisplayText = App.lang.get(
                                    fieldsInfo[fieldDisplayText].vname,
                                    self.options.manager.model.get("moduleName")
                                );
                            }
                        }

                        var baseFieldHtml =
                            "\
                                <tr>\
                                  <td  style=\"margin-left: 2.5%;width:365px;\">\
                                    <span style=\"margin-left: 2.5%;\">" +
                            fieldDisplayText +
                            "</span>\
                                  </td>\
                                  <td style=\"margin-left: 2.5%;width:365px;\"> \
                                    <span style=\"margin-left: 2.5%;\">" +
                            fieldValue +
                            "</span>\
                                  </td>\
                                  <td style=\"margin-left: 2.5%;width:365px;\">\
                                    <a class=\"btn removeFieldInfo\" name=\"" +
                            removeFieldButton +
                            "\"   id =\"removeFieldInfo\" >\
                                      <i class=\"fa fa-times\"></i>\
                                    </a>\
                                  </td>\
                                </tr>";

                        fieldsContainer.append(baseFieldHtml);
                    }
                }
            });
        }

        this.$el.find(".removeFieldInfo").click(this.removeFieldInfo.bind(this));

        if (Object.keys(attributes).length <= 0) {
            container.hide();
        } else {
            container.show();
        }
    },

    /**
     * Description
     * @method removeFieldInfo
     * @param {} event
     * @return
     */
    removeFieldInfo: function (event) {
        // get field name
        var fieldName = event.currentTarget.getAttribute("name");
        // remove field from data
        delete this.actionParameters.recordAttributes[fieldName];
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));

        this.$el.find("#presetInfoContainer").empty();
        this.addNewFieldInfo(this.actionParameters.recordAttributes);
    },

    /**
     * Description
     * @method openCreateView
     * @return
     */
    openCreateView: function () {
        var createLayout = "create";
        app.drawer.open({
            layout  : createLayout,
            context : {
                create                      : true,
                module                      : this.options.manager.model.get("moduleName"),
                parentView                  : this,
                isWRecordButtonPresetCreate : true
            }
        });
    },

    /**
     * Description
     * @method showPresetButton
     * @param {} visible
     * @return
     */
    showPresetButton: function (visible) {
        var functionToCall = visible ? "show" : "hide";

        this.$el.find("#presetButton")[functionToCall]();
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        this.showPresetButton(true);
        this.addNewFieldInfo(this.actionParameters.recordAttributes);
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);

        if (!this.actionParameters.recordAttributes) {
            this.actionParameters.recordAttributes = {};
        }

        if (!this.actionParameters.executeView) {
            this.actionParameters.executeView = this.name;
        }

        this.updateView();
    }
});
