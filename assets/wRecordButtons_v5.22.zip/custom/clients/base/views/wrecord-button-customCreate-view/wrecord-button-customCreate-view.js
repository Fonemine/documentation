/**
 * Class Description
 *
 * @class wrecord-button-customCreate-view
 */
({
    extendsFrom: "CreateView",

    /**
   * Description
   * @method render
   * @return
   */
    render: function() {
        var renderResult = this._super("render", arguments);

        // manage the dependency fields
        var modelAttributes = this.model.attributes;
        this.model.attributes = {};

        this.model.set(modelAttributes);

        return renderResult;
    }
});
