/**
 * Class Description
 *
 * @class wrecord-button-run-url
 */
({
    events: {
        "change [name=finalUrl]"                   : "handleParamsChange",
        "change [name=formulaElement]"             : "handleParamsChange",
        "click .add_url"                           : "addUrlClicked",
        "change [name=calculatedField]"            : "handleCheckboxChange",
        "change [name=showAlert]"                  : "handleCheckboxChange",
        "click [name=formulaElement]"              : "formulaElementClicked",
        "click [name=fieldsDropdownButton]"        : "showFieldsDropdown",
        "click [name=functionsDropdownButton]"     : "showFunctionsDropdown",
        "click [name=relatedFieldsDropdownButton]" : "showRelatedFieldsDropdown"
    },

    actionParameters: {
        finalUrl          : "",
        fieldType         : "",
        moduleType        : "",
        formulaElement    : "",
        validationMessage : "",
        validFormula      : false,
        calculatedField   : false,
        showAlert         : false
    },

    urlFields               : {},
    relatedModules          : {},
    relateFields            : {},
    modulesList             : {},
    fieldRelatedTypes       : {},
    functionTypes           : {},
    functionsDescription    : {},
    validModules            : ["Users", "Accounts", "Campaigns"],
    allowedCalculatedFields : [
        "name",
        "multienum",
        "enum",
        "Colorstatusfield",
        "text",
        "encrypt",
        "varchar",
        "relate",
        "datetimecombo",
        "datetime",
        "date",
        "email",
        "currency",
        "phone",
        "url",
        "checkbox",
        "decimal",
        "float",
        "int",
        "bool"
    ],
    lastExpressionEntered : "",
    functionDescription   : "",
    currentParamNumber    : -1,
    dropdownOpened        : false,
    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize            : function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            finalUrl          : "",
            fieldType         : "",
            formulaElement    : "",
            validationMessage : "",
            moduleType        : "",
            validFormula      : false,
            calculatedField   : false,
            showAlert         : false
        };

        // get the data we need form the main model
        this.relatedModules = this.options.manager.model.get("relatedModules");

        this.initializeFieldsList(this.options.manager.model.get("moduleName"));

        this.functionsDescription = this.options.manager.model.get("functionsDescription");

        this.actionParameters.moduleType = this.options.manager.model.get("moduleName");

        this.updateWidgetView();

        // get the list of functions we can use
        _.each(
            this.getDisplayFunctionList(),
            function getFieldName(functionData) {
                this.functionTypes[functionData[0]] = functionData[0];
            }.bind(this)
        );

        return initResult;
    },

    showRelatedFieldsDropdown: function () {
        this.showDropdownList(this.$el.find(".relatedFieldsList"));
    },

    showFieldsDropdown: function () {
        this.showDropdownList(this.$el.find(".fieldsList"));
    },

    showFunctionsDropdown: function () {
        this.showDropdownList(this.$el.find(".functionsList"));
    },

    showDropdownList: function (el) {
        if (this.dropdownOpened === true) {
            this.dropdownOpened = false;
            el.hide();
        } else {
            this.dropdownOpened = true;

            el.show();
            el.select2("open");

            el.on(
                "select2-close",
                function destroyDropdown(e) {
                    this.dropdownOpened = false;
                    el.hide();
                }.bind(this)
            );
        }
    },

    formulaElementClicked: function () {
        this.handleRelatedFieldsButton();
        this.showTooltip();
    },

    getDisplayFunctionList: function () {
        var functionsArray = this.getFunctionsList();
        var usedClasses = {};
        var ret = [];

        _.each(
            functionsArray,
            function getDisplayFunction(functionData) {
                var fName = functionData[0];

                // show only the functions we actually use
                if (
                    fName !== "isValidTime" &&
                    fName !== "isAlpha" &&
                    fName !== "doBothExist" &&
                    fName !== "isValidPhone" &&
                    fName !== "isRequiredCollection" &&
                    fName !== "isNumeric" &&
                    fName !== "isValidDBName" &&
                    fName !== "isAlphaNumeric" &&
                    fName !== "stddev" &&
                    fName !== "charAt" &&
                    fName !== "formatName" &&
                    fName !== "sugarField" &&
                    fName !== "forecastCommitStage" &&
                    fName !== "currencyRate"
                ) {
                    if (functionData[1] == "time") {
                        return;
                    }

                    if (usedClasses[SUGAR.FunctionMap[fName].prototype.className]) {
                        return;
                    }

                    if (functionData[1] == "number") {
                        ret.push([functionData[0], "_number"]);
                    } else {
                        ret.push(functionData);
                    }

                    if (SUGAR.FunctionMap[fName]) {
                        usedClasses[SUGAR.FunctionMap[fName].prototype.className] = true;
                    }
                }
            }.bind(this)
        );

        return ret;
    },

    getFunctionsList: function () {
        var typeMap = SUGAR.expressions.Expression.TYPE_MAP;
        var funcMap = SUGAR.FunctionMap;
        var funcList = [];

        for (var i in funcMap) {
            if (typeof funcMap[i] == "function" && funcMap[i].prototype) {
                for (var j in typeMap) {
                    if (funcMap[i].prototype instanceof typeMap[j]) {
                        funcList[funcList.length] = [i, j];
                        break;
                    }
                }
            }
        }
        return funcList;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        this.$el.find("[name=DefaultValueFieldUI]").hide();
        this.$el.find("[name=CalculatedFieldUI]").hide();

        this.initializeTooltip();

        this.$el.find("[name=urlFields]").select2(this.getSelect2Options("UrlFields"));

        // create the select dropdown for all the data we need
        this.createCustomSelect2Dropdown(
            ".fieldsList",
            "RelatedModules",
            this.addFieldToFormula.bind(this),
            this.populateRelatedFieldsList.bind(this),
            true
        );
        this.createCustomSelect2Dropdown(
            ".relatedFieldsList",
            "RelatedFields",
            this.addRelatedFieldToFormula.bind(this),
            null,
            true
        );
        this.createCustomSelect2Dropdown(
            ".functionsList",
            "Functions",
            this.addFunctionToFormula.bind(this),
            null,
            true
        );

        this.updateView();

        // when we unFocus the formula element we need to validate the expressions
        this.$el.find("[name=formulaElement]").blur(
            function isFormulaValid(event) {
                var tooltipElement = this.$el.find("#appendedInputButtons");
                tooltipElement.tooltip("hide");
                tooltipElement.data("tooltipVisible", false);

                var functionButtonPressed = this.$el.find("[name=functionsDropdownButton]").is(":hover");
                var fieldButtonPressed = this.$el.find("[name=fieldsDropdownButton]").is(":hover");
                var fieldRelatedButtonPressed = this.$el.find("[name=relatedFieldsDropdownButton]").is(":hover");

                this.handleRelatedFieldsButton();

                if (
                    fieldButtonPressed === true ||
                    functionButtonPressed === true ||
                    fieldRelatedButtonPressed === true ||
                    this.lastExpressionEntered === this.actionParameters.formulaElement
                ) {
                    return;
                }

                this.lastExpressionEntered = this.actionParameters.formulaElement;

                this.validateCurrentExpression(event.currentTarget.value);
            }.bind(this)
        );

        this.handleRelatedFieldsButton();

        this.options.manager.on("saving:record:buttons", this.verifyDataValid.bind(this));

        return renderResult;
    },

    //eslint-disable-next-line consistent-return
    validateCurrentExpression: function (expression) {
        var selectedModuleName = this.options.manager.model.get("moduleName");
        var fieldsData = this.options.manager.model.get("fieldsData")[selectedModuleName];

        try {
            var varTypeMap = {};

            for (var i = 0; i < fieldsData.length; i++) {
                varTypeMap[fieldsData[i][0]] = fieldsData[i][1];
            }

            var completeFieldsList = App.metadata.getModule(selectedModuleName).fields;

            _.each(completeFieldsList, function getMultiselectFields(fieldData) {
                if (fieldData.type === "multienum") {
                    varTypeMap[fieldData.name] = "string";
                }
            });

            var tokens = new SUGAR.expressions.ExpressionParser().tokenize(expression);

            this.setReturnTypes(tokens, varTypeMap);
            this.validateReturnTypes(tokens);
            this.validateRelateFunctions(tokens);

            this.actionParameters.validationMessage = "";
            this.actionParameters.validFormula = true;

            this.actionParameters.formulaElement = this.replaceCharInFormula(
                this.actionParameters.formulaElement,
                "\"",
                "'"
            );

            this.actionParameters.finalUrl = this.replaceCharInFormula(this.actionParameters.finalUrl, "\"", "'");

            this.options.parentView.modifyActionData(_.clone(this.actionParameters));

            this.options.manager.trigger("clean-button-" + this.options.buttonId);
            this.options.manager.trigger("clean-button-" + this.options.actionId);
            return true;
        } catch (e) {
            app.alert.show("alert_missing_buttons", {
                level          : "error",
                title          : e,
                autoClose      : true,
                autoCloseDelay : 5000
            });

            this.actionParameters.validationMessage = e;
            this.actionParameters.validFormula = false;

            this.options.parentView.modifyActionData(_.clone(this.actionParameters));
            this.options.manager.trigger("corrupted-button-" + this.options.buttonId);
            this.options.manager.trigger("corrupted-button-" + this.options.actionId);
            return false;
        }
    },

    replaceCharInFormula: function (formulaDef, charToReplace, newChar) {
        var formulaBody = formulaDef || "";
        var regex = new RegExp("\\" + charToReplace);

        while (formulaBody.match(regex)) {
            formulaBody = formulaBody.replace(regex, newChar);
        }

        return formulaBody;
    },

    populateRelatedFieldsList: function (fieldData) {
        this.fieldRelatedTypes = this.options.manager.model.get("relatedModuleFields")[fieldData.text];
    },

    showTooltip: function () {
        var tooltipElement = this.$el.find("#appendedInputButtons");
        var functionTip = this.functionsDescription[this.getCurrentFunctionName()];
        var desc = "<p align=\"left\">" + functionTip + "</p>";

        // highlight the current param hovered
        if (this.currentParamNumber > 0 && functionTip !== "") {
            var paramCount = 0;
            var startIndex = desc.indexOf("(");
            var endIndex = desc.indexOf(")");

            var highlightStartIndex = startIndex + 1;
            var highlightEndIndex = -1;

            // if we have at least one param
            if (endIndex > startIndex) {
                var lastParamStartIndex = highlightStartIndex;
                var paramFound = false;

                // iterate to highlight the selected param
                for (var charIndex = startIndex; charIndex <= endIndex; charIndex++) {
                    if (desc.charAt(charIndex) === "," && paramFound === false) {
                        paramCount = paramCount + 1;
                        highlightStartIndex = lastParamStartIndex;

                        //eslint-disable-next-line max-depth
                        if (paramCount === this.currentParamNumber) {
                            paramFound = true;
                            highlightEndIndex = charIndex;
                        }
                        lastParamStartIndex = charIndex + 1;
                    }
                }

                var highlightStart = "<font color=\"#B22222\">";
                var highlightEnd = "</font>";

                if (paramCount === 0 || (paramFound === false && paramCount > 0)) {
                    highlightStartIndex = lastParamStartIndex;
                    highlightEndIndex = endIndex;
                }

                if (highlightEndIndex > -1) {
                    desc = [desc.slice(0, highlightEndIndex), highlightEnd, desc.slice(highlightEndIndex)].join("");
                    desc = [desc.slice(0, highlightStartIndex), highlightStart, desc.slice(highlightStartIndex)].join(
                        ""
                    );
                }
            }
        }

        // if the description is different from the previous we show the updated tooltip
        if (this.functionDescription !== desc || tooltipElement.data("tooltipVisible") === false) {
            if (functionTip !== "") {
                this.functionDescription = desc;
                var initialWidth = tooltipElement.css("width");

                tooltipElement.css("width", "1%");
                tooltipElement.tooltip("show");
                tooltipElement.css("width", initialWidth);
                tooltipElement.data("tooltipVisible", true);
            }
        }
    },

    getCurrentFunctionName: function () {
        var formulaBody = this.actionParameters.formulaElement;
        var cursorPosition = this.$el.find("#appendedInputButtons").prop("selectionStart");
        var hoveredFunctionName = "";
        var closestFunctionName = "";
        this.currentParamNumber = -1;
        var distanceToFunction = Number.POSITIVE_INFINITY;

        _.each(
            this.functionTypes,
            function findCurrentFunctionName(functionName) {
                // get the position where the formula starts
                var formulaStartIndex = formulaBody.indexOf(functionName);

                if (formulaStartIndex > -1) {
                    var formulaEndIndex = formulaStartIndex + functionName.length;

                    // check if the cursor is right on the function
                    if (
                        ((cursorPosition === 0 && formulaStartIndex === 0) ||
                            cursorPosition >= formulaStartIndex + 1) &&
                        cursorPosition <= formulaEndIndex &&
                        formulaBody.charAt(formulaEndIndex) === "(" &&
                        hoveredFunctionName.length <= functionName.length
                    ) {
                        hoveredFunctionName = functionName;
                        this.currentParamNumber = -1;
                        return;
                    }

                    // check if the cursor is inside the declaration of a function
                    if (formulaEndIndex < cursorPosition) {
                        var distance = cursorPosition - formulaEndIndex;

                        if (distance < distanceToFunction && formulaBody.charAt(formulaEndIndex) === "(") {
                            // inside current function
                            var parenthesisCount = 1;
                            var paramNumber = 1;

                            for (var charIndex = formulaEndIndex + 1; charIndex <= cursorPosition; charIndex++) {
                                //eslint-disable-next-line max-depth
                                if (formulaBody.charAt(charIndex) === "(") {
                                    parenthesisCount = parenthesisCount + 1;
                                } else if (formulaBody.charAt(charIndex - 1) === ")") {
                                    parenthesisCount = parenthesisCount - 1;
                                } else if (formulaBody.charAt(charIndex - 1) === "," && parenthesisCount === 1) {
                                    paramNumber = paramNumber + 1;
                                }
                            }

                            // if after parsing we are still in the same function
                            if (
                                parenthesisCount === 1 ||
                                (closestFunctionName.length <= functionName.length &&
                                    parenthesisCount === 0 &&
                                    cursorPosition > formulaBody.length - 1)
                            ) {
                                this.currentParamNumber = paramNumber;
                                distanceToFunction = distance;
                                closestFunctionName = functionName;
                            }
                        }
                    }
                }
            }.bind(this)
        );

        if (hoveredFunctionName === "") {
            hoveredFunctionName = closestFunctionName;
        }

        return hoveredFunctionName;
    },

    verifyDataValid: function () {
        if (this.currentRelatedField) {
            var relatedData = this.$el.find("[name='" + this.currentRelatedField + "']").select2("data");
            this.actionParameters["defaultValueText"] = relatedData.text;

            // update the data in the main model
            this.actionParameters["defaultValue"] = relatedData.id;
            this.actionParameters.formulaElement = this.replaceCharInFormula(
                this.actionParameters.formulaElement,
                "\"",
                "'"
            );

            this.actionParameters.finalUrl = this.replaceCharInFormula(this.actionParameters.finalUrl, "\"", "'");

            this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        }
    },

    setReturnTypes: function (t, vMap) {
        var see = SUGAR.expressions.Expression;

        if (t.type == "variable") {
            if (typeof vMap[t.name] == "undefined") {
                throw "Unknown field: " + t.name;
            } else if (vMap[t.name] == "relate") {
                t.returnType = SUGAR.expressions.Expression.GENERIC_TYPE;
            } else {
                t.returnType = vMap[t.name];
            }
        }

        if (t.type == "function") {
            for (var i in t.args) {
                this.setReturnTypes(t.args[i], vMap);
            }

            var fMap = SUGAR.FunctionMap;

            if (typeof fMap[t.name] == "undefined") {
                throw t.name + ": No such function defined";
            }

            for (var j in see.TYPE_MAP) {
                if (fMap[t.name].prototype instanceof see.TYPE_MAP[j]) {
                    t.returnType = j;
                    break;
                }
            }

            // For the conditional function, if both argument return types are same, set the conditional type
            if (t.name == "ifElse") {
                var args = t.args;
                var returnTypeIndex = 2;

                if (args[1].returnType == args[returnTypeIndex].returnType) {
                    t.returnType = args[1].returnType;
                }
            }

            if (!t.returnType) {
                throw t.name + ": No known return type!";
            }
        }
    },

    validateReturnTypes: function (t) {
        if (t.type == "function") {
            //Depth first recursion
            for (var i in t.args) {
                this.validateReturnTypes(t.args[i]);
            }

            var fMap = SUGAR.FunctionMap;
            var see = SUGAR.expressions.Expression;

            if (typeof fMap[t.name] == "undefined") {
                throw t.name + ": No such function defined";
            }

            var types = fMap[t.name].prototype.getParameterTypes();
            var count = fMap[t.name].prototype.getParamCount();

            // check parameter count
            if (count == see.INFINITY && t.args.length == 0) {
                throw t.name + ": Requires at least one parameter";
            }

            if (count != see.INFINITY && t.args instanceof Array && t.args.length != count) {
                throw t.name + ": Requires exactly " + count + " parameter(s)";
            }

            if (typeof types == "string") {
                for (var j = 0; j < t.args.length; j++) {
                    if (!t.args[j].returnType) {
                        throw t.name + ": No known return type!";
                    }

                    if (!fMap[t.name].prototype.isProperType(new see.TYPE_MAP[t.args[j].returnType](), types)) {
                        throw t.name + ": All parameters must be of type '" + types + "'";
                    }
                }
            } else {
                for (var k = 0; k < types.length; k++) {
                    if (!fMap[t.name].prototype.isProperType(new see.TYPE_MAP[t.args[k].returnType](), types[k])) {
                        throw t.name + ": The parameter at index " + k + " must be of type " + types[k];
                    }
                }
            }
        }
    },

    //eslint-disable-next-line consistent-return
    validateRelateFunctions: function (t) {
        if (t.type == "function") {
            //Depth first recursion
            for (var i in t.args) {
                this.validateRelateFunctions(t.args[i]);
            }

            //these functions all take a link and a string for a related field
            var relFuncs = ["related", "rollupAve", "rollupMax", "rollupMin", "rollupSum"];

            if (this.arrayIndexOf(relFuncs, t.name) == -1) {
                return true;
            }

            var url =
                "index.php?" +
                this.paramsToUrl({
                    module  : "ExpressionEngine",
                    action  : "validateRelatedField",
                    tmodule : this.options.manager.model.get("moduleName"),
                    package : "",
                    link    : t.args[0].name,
                    related : t.args[1].value
                });

            var resp = this.httpFetchSync(url);
            var def = JSON.parse(resp.responseText);

            //Check if a field was found
            if (typeof def == "string") {
                throw t.name + ": " + def;
            }

            if (
                t.name != "related" &&
                def.type &&
                this.arrayIndexOf(["decimal", "int", "float", "currency"], def.type) == -1
            ) {
                throw t.name + ": related field  " + t.args[1].value + " must be a number ";
            }

            return true;
        }
    },

    getXMLHTTPinstance: function () {
        var xmlhttp = false;

        try {
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (E) {
                xmlhttp = false;
            }
        }

        if (!xmlhttp && typeof XMLHttpRequest != "undefined") {
            xmlhttp = new XMLHttpRequest();
        }

        return xmlhttp;
    },

    httpFetchSync: function (url, postData, headers) {
        headers = headers || {};
        var globalXmlhttp = this.getXMLHTTPinstance();
        var method = "GET";

        if (typeof postData != "undefined") {
            method = "POST";
        }

        try {
            globalXmlhttp.open(method, url, false);
        } catch (e) {
            var message = "message:" + e.message + ":url:" + url;
            app.alert.show("alert_missing_buttons", {
                level          : "error",
                title          : message,
                autoClose      : true,
                autoCloseDelay : 5000
            });
        }

        if (method == "POST" && typeof headers["Content-Type"] === "undefined") {
            headers["Content-Type"] = "application/x-www-form-urlencoded";
        }

        for (var header in headers) {
            globalXmlhttp.setRequestHeader(header, headers[header]);
        }

        globalXmlhttp.send(postData);

        var args = {
            responseText : globalXmlhttp.responseText,
            responseXML  : globalXmlhttp.responseXML,
            //eslint-disable-next-line camelcase
            request_id   : 0
        };

        return args;
    },

    arrayIndexOf: function (arr, val, start) {
        if (typeof arr.indexOf == "function") {
            return arr.indexOf(val, start);
        }

        for (var i = start || 0, j = arr.length; i < j; i++) {
            if (arr[i] === val) {
                return i;
            }
        }

        return -1;
    },

    paramsToUrl: function (params) {
        var parts = [];
        for (var i in params) {
            if (params.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + "=" + encodeURIComponent(params[i]));
            }
        }

        return parts.join("&") + "&";
    },

    initializeTooltip: function () {
        // define the functions and events that we need for a proper tooltip
        var tooltipElement = this.$el.find("#appendedInputButtons");

        // when we move the cursor we want to try to show the tooltip
        tooltipElement.on(
            "keyup click focus",
            function showTooltip() {
                this.showTooltip();
            }.bind(this)
        );

        // initialize the tooltip
        tooltipElement.tooltip({
            title: function title() {
                return this.functionDescription;
            }.bind(this),
            trigger   : "manual",
            html      : true,
            container : "body"
        });

        // when the mouse leave the element we hide the tooltip
        tooltipElement.mouseleave(function hideTooltip() {
            tooltipElement.tooltip("hide");
            tooltipElement.data("tooltipVisible", false);
        });

        // when we scroll we hide the tooltip
        $(".main-pane").scroll(function hideTooltip() {
            tooltipElement.tooltip("hide");
            tooltipElement.data("tooltipVisible", false);
        });
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        // fix bwc issues
        _.each(this.actionParameters, function fixSavedParams(paramValue, paramKey) {
            if (!(paramKey in parameters)) {
                parameters[paramKey] = paramValue;
            }
        });

        this.actionParameters = _.clone(parameters);
        this.actionParameters.formulaElement = this.replaceCharInFormula(
            this.actionParameters.formulaElement,
            "'",
            "\""
        );

        this.actionParameters.finalUrl = this.replaceCharInFormula(this.actionParameters.finalUrl, "\"", "'");

        this.updateView();
        this.updateWidgetView();
    },

    getCompleteFieldsList: function (module) {
        var self = this;
        var massUpdateFields = {};
        var relateFields = {};
        var calculatedFields = {};
        var fieldsMeta = [];
        var metadataModule = app.metadata.getModule(module);
        var fieldsList = metadataModule.fields;

        _.each(fieldsList, function clean(field) {
            // Remove blacklisted fields
            if (!field.name || !(field.label || field.vname)) {
                return;
            }

            if (
                _.contains(self.allowedCalculatedFields, field.type) ||
                _.contains(self.allowedPresetFields, field.type) ||
                (field.source && field.source === "custom_fields" && field.type === "multienum")
            ) {
                if (field.type !== "id" || (field.type === "id" && field.name !== "parent_id")) {
                    // split the fields in two separate lists - calculated/preset
                    if (_.contains(self.allowedCalculatedFields, field.type)) {
                        calculatedFields[field.name] = field;
                    }

                    if (_.contains(self.allowedPresetFields, field.type)) {
                        relateFields[field.name] = field;
                    }

                    var displayName = field.label || field.vname;
                    var canInsertField = true;

                    for (var i = 0; i < fieldsMeta.length; i++) {
                        var fieldDisplayName = fieldsMeta[i].label || fieldsMeta[i].vname;

                        if (fieldDisplayName === displayName) {
                            canInsertField = false;
                            break;
                        }
                    }

                    if (canInsertField) {
                        fieldsMeta.push(field);
                        massUpdateFields[field.name] = App.lang.get(displayName, module);
                    }
                }
            }
        });

        this.meta = { panels: [] };
        this.meta.panels.push({});

        this.meta.panels[0]["fields"] = fieldsMeta;
        this.relateFields = relateFields;
        this.calculatedFields = calculatedFields;

        return massUpdateFields;
    },

    /**
     * Description
     * @method updateView
     * @return
     */
    updateView: function () {
        this.$el.find("[name=\"urlFields\"]").select2("data", {
            id   : "selectURLField",
            text : "Select URL Field"
        });
        this.$el.find("[name=\"finalUrl\"]").val(this.actionParameters.finalUrl);

        this.$el.find("[name=\"formulaElement\"]").val(this.actionParameters.formulaElement);

        this.populateRelatedModulesFields({
            id: this.actionParameters.moduleType
        });

        this.handleValuesDropdown();
    },

    populateRelatedModulesFields: function (fieldData) {
        var moduleName = fieldData.id;

        this.initializeFieldsList(moduleName);
    },

    initializeFieldsList: function (moduleName) {
        this.fieldTypes = this.getCompleteFieldsList(moduleName);
    },

    /**
     * Description
     * @method addUrlClicked
     * @return
     */
    addUrlClicked: function () {
        // when we add a field to the Url
        var finalUrlEl = this.$el.find("[name=\"finalUrl\"]");
        var urlFieldEl = this.$el.find("[name=\"urlFields\"]");
        var url = finalUrlEl.val() + "{" + urlFieldEl.val() + "}";

        finalUrlEl.val(url);

        this.actionParameters.finalUrl = url;
        this.actionParameters.formulaElement = this.replaceCharInFormula(
            this.actionParameters.formulaElement,
            "\"",
            "'"
        );

        this.actionParameters.finalUrl = this.replaceCharInFormula(this.actionParameters.finalUrl, "\"", "'");

        // update data in the main model
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },

    handleCheckboxChange: function (event) {
        if (event.currentTarget.checked === false) {
            this.options.manager.trigger("clean-button-" + this.options.buttonId, true);
            this.options.manager.trigger("clean-button-" + this.options.actionId);
        }

        this.handleParamsChange(event, event.currentTarget.checked);
        this.handleValuesDropdown();
    },

    handleValuesDropdown: function () {
        var isCalculated = this.actionParameters.calculatedField;

        if (isCalculated === true) {
            this.$el.find("[name=DefaultValueFieldUI]").hide();
            this.$el.find("[name=CalculatedFieldUI]").show();
            this.actionParameters.calculatedField = true;
        } else if (isCalculated !== null) {
            this.$el.find("[name=CalculatedFieldUI]").hide();
            this.$el.find("[name=DefaultValueFieldUI]").show();
            this.actionParameters.calculatedField = false;
        }

        this.$el.find("[name=calculatedField]").prop("checked", isCalculated === true);

        var showAlert = this.actionParameters.showAlert;

        if (showAlert === true) {
            this.actionParameters.showAlert = true;
        } else if (showAlert !== null) {
            this.actionParameters.showAlert = false;
        }

        this.$el.find("[name=showAlert]").prop("checked", showAlert === true);
    },

    handleParamsChange: function (event, value) {
        // update the data in the main model
        var dataValue = value ? value : event.currentTarget.value;

        if (event.currentTarget.name === "formulaElement") {
            dataValue = this.cleanFormula(dataValue);
            event.currentTarget.value = dataValue;
        }

        this.actionParameters[event.currentTarget.name] = dataValue;
        this.actionParameters.formulaElement = this.replaceCharInFormula(
            this.actionParameters.formulaElement,
            "\"",
            "'"
        );

        this.actionParameters.finalUrl = this.replaceCharInFormula(this.actionParameters.finalUrl, "\"", "'");

        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        this.updateWidgetView();
    },

    addFunctionToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");
        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);

        var val = textBefore + value + "(" + textAfter;
        this.updateFormulaField(formulaElement, val);
    },

    addFieldToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");

        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);
        var val = textBefore + "$" + value + textAfter;
        this.updateFormulaField(formulaElement, val);
    },

    addRelatedFieldToFormula: function (value) {
        var formulaElement = this.$el.find("[name=formulaElement]");

        var cursorPos = formulaElement.prop("selectionStart");
        var v = formulaElement.val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);

        var val = textBefore + value + "\"" + value + "\"" + textAfter;

        this.updateFormulaField(formulaElement, val);
    },

    updateFormulaField: function (formulaElement, val) {
        val = this.cleanFormula(val);
        formulaElement.val(val);

        this.actionParameters.formulaElement = val;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
        formulaElement.focus();

        this.updateWidgetView();
    },

    cleanFormula: function (dirtyFormula) {
        var charIndexesToBeRemoved = [];
        var searchAllowed = true;

        for (var charIndex = 0; charIndex < dirtyFormula.length; charIndex++) {
            if (searchAllowed && dirtyFormula[charIndex] === " ") {
                charIndexesToBeRemoved.push(charIndex);
            }

            if (dirtyFormula[charIndex] === "\"") {
                searchAllowed = !searchAllowed;
            }
        }

        for (var spaceIndex = charIndexesToBeRemoved.length - 1; spaceIndex >= 0; spaceIndex--) {
            dirtyFormula =
                dirtyFormula.substr(0, charIndexesToBeRemoved[spaceIndex]) +
                dirtyFormula.substr(charIndexesToBeRemoved[spaceIndex] + 1, dirtyFormula.length);
        }

        return dirtyFormula;
    },

    updateWidgetView: function () {
        this.handleRelatedFieldsButton();
    },

    handleRelatedFieldsButton: function () {
        // if we use related functions we need to make the element smaller
        if (this.isUsingRelatedFunction() === true) {
            this.$el.find("[name=relatedFieldsDropdownButton]").show();
            this.$el.find("[name=formulaElement]").css("width", "60%");
        } else {
            this.$el.find("[name=relatedFieldsDropdownButton]").hide();
            this.$el.find("[name=formulaElement]").css("width", "70%");
        }
    },

    isUsingRelatedFunction: function () {
        var relatedKeyword = "related";
        var formulaBody = this.actionParameters.formulaElement;
        var cursorPosition = this.$el.find("#appendedInputButtons").prop("selectionStart");
        var partOfForumula = formulaBody.substring(0, cursorPosition);
        var lastIndexOfFunction = partOfForumula.lastIndexOf("(");
        var lastIndexOfEndFunction = partOfForumula.lastIndexOf(")");
        var lastFunctionUsed = formulaBody.substring(lastIndexOfFunction - relatedKeyword.length, lastIndexOfFunction);
        var relatedFunctionUsed = lastFunctionUsed === relatedKeyword;
        var relatedFunctionComplete = lastIndexOfEndFunction > lastIndexOfFunction;

        return relatedFunctionUsed && !relatedFunctionComplete;
    },

    createCustomSelect2Dropdown: function (
        elementId,
        listType,
        callback,
        updateSelect2Callback,
        hide,
        formatResultFunction
    ) {
        // create the select2 dropdowns
        var fieldsSelect2 = this.$el
            .find(elementId)
            .select2(this.getSelect2Options(listType, formatResultFunction))
            .data("select2");

        fieldsSelect2.onSelect = (function select(fn) {
            return function updateSelect2(data, options) {
                if (callback) {
                    callback(data.id);
                }

                if (updateSelect2Callback) {
                    updateSelect2Callback(data);
                }

                if (arguments && listType !== "ModuleTypes") {
                    arguments[0] = {
                        id   : "select",
                        text : app.lang.get("LBL_SEARCH_SELECT")
                    };
                }

                return fn.apply(this, arguments);
            };
        })(fieldsSelect2.onSelect);

        if (hide) {
            this.$el.find(elementId).hide();
        }
    },

    /**
     * Description
     * @method getSelect2Options
     * @return select2Options
     */
    getSelect2Options: function (optionsType, formatResultFunction) {
        var moduleName = this.options.manager.model.get("moduleName");
        this.urlFields = this.getCompleteFieldsList(moduleName);

        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query" + optionsType], this);
        select2Options.selectOnBlur = true;

        if (formatResultFunction) {
            select2Options.formatResult = formatResultFunction;
        }

        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text === "CURRENT RECORD") {
                    return -1;
                } else if (secondLabel.text === "CURRENT RECORD") {
                    return 1;
                }

                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _queryFunctions: function (query) {
        this._query(query, "functionTypes");
    },

    _queryRelatedFields: function (query) {
        this._query(query, "fieldRelatedTypes");
    },

    _queryUrlFields: function (query) {
        this._query(query, "urlFields");
    },

    _queryRelatedModules: function (query) {
        var listName = this.isUsingRelatedFunction() === true ? "relatedModules" : "fieldTypes";
        this._query(query, listName);
    },

    _query: function (query, customListName) {
        var listElements = this[customListName];
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listElements)) {
            _.each(listElements, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({ id: index, text: text });
                }
            });
        } else {
            listElements = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) { }
});
