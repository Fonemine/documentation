/**
 * Class Description
 *
 * @class wrecord-button-save-record
 */
({
    events: {
        "change [name=validateRequiredFields]": "handleCheckboxChange",
    },

    actionParameters: {
        recordType             : "",
        recordAttributes       : {},
        validateRequiredFields : false,
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.actionParameters = {
            recordType             : "",
            recordAttributes       : {},
            validateRequiredFields : false,
        };

        return initResult;
    },

    render: function () {
        var renderResult = this._super("render", arguments);
        this.options.parentView.$el
            .find("[name=executeImmediately]")
            .parent()
            .show();
        return renderResult;
    },

    execute: function (buttonData) {
        if (!this.model && app.controller.context.uRecordButtonModel) {
            this.model = app.controller.context.uRecordButtonModel;
        }

        var self = this;
        if (this.model && app.acl.hasAccess("edit", this.model.module)) {
            if (this.model.changedAttributes() === false) {
                this.mustSaveModel = false;
                this.goToNextAction();
            } else {
                this.listenTo(this.model, "sync", function goToNextAction() {
                    if (_.isEmpty(app.controller.context.saveListenedTo)) {
                        self.stopListening(false, "sync");
                        self.mustSaveModel = false;
                        self.goToNextAction();
                        app.controller.context.saveListenedTo = true;
                    } else {
                        delete app.controller.context.saveListenedTo;
                    }
                });

                var defensiveCheckTimeout = 1000;

                setTimeout(function activateDefense() {
                    if (_.isEmpty(app.controller.context.saveListenedTo)) {
                        self.stopListening(false, "sync");
                        self.mustSaveModel = false;
                        self.goToNextAction();
                        app.controller.context.saveListenedTo = true;
                    } else {
                        delete app.controller.context.saveListenedTo;
                    }
                }, defensiveCheckTimeout);
            }

            if (this.tplName == "edit" || this.tplName == "detail" || this.tplName == "record") {
                if (buttonData.actionParameters.validateRequiredFields === true) {
                    setTimeout(_.bind(function delaySaveAction() {
                        this.view.saveClicked();
                    }, this), 0);
                } else {
                    this.view.handleSave();
                }
            } else if (this.tplName == "list") {
                var fieldSetField = _.find(
                    this.view.fields,
                    function getFieldSetField(field) {
                        return (
                            field.type === "fieldset" &&
                            _.find(field.fields, function getInlineSaveField(f) {
                                return f.name === "inline-save";
                            }) &&
                            field.model.cid === this.model.cid
                        );
                    }.bind(this)
                );

                if (!_.isEmpty(fieldSetField) && !_.isEmpty(fieldSetField.fields)) {
                    var inlineSaveField = _.find(fieldSetField.fields, function getInlineField(field) {
                        return field.name === "inline-save";
                    });

                    if (!_.isEmpty(inlineSaveField)) {
                        inlineSaveField.saveModel();
                    }
                }
            } else if (this.tplName == "preview" || this.tplName == "preview-header") {
                var preview = this.view.layout.getComponent("preview");
                preview.saveClicked();
            }
        } else {
            this.showNoAccessAlert();
        }
    },

    /**
     * Description
     * @method setParameters
     * @param {} parameters
     * @return
     */
    setParameters: function (parameters) {
        this.actionParameters = _.clone(parameters);

        if (!this.actionParameters.recordAttributes) {
            this.actionParameters.recordAttributes = {};
        }

        if (!this.actionParameters.executeView) {
            this.actionParameters.executeView = this.name;
        }

        this.$el
            .find("[name='validateRequiredFields']")
            .prop("checked", this.actionParameters.validateRequiredFields === true);
    },

    handleCheckboxChange: function (event) {
        // update the data in the main model
        this.actionParameters[event.currentTarget.name] = event.currentTarget.checked;
        this.options.parentView.modifyActionData(_.clone(this.actionParameters));
    },
});