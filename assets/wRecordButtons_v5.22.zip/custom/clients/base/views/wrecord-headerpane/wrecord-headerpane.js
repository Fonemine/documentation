/**
 * Class Description
 *
 * @class wrecord-headerpane
 */
({
    events: {
        "click a[name=closeDrawer]"      : "closeDrawer",
        "click a[name=saveSettings]"     : "saveSettings",
        "change [name=buttonType]"       : "changeGeneralSettings",
        "change [name=buttonSize]"       : "changeGeneralSettings",
        "change [name=iconPlacement]"    : "changeGeneralSettings",
        "change [name=showLabelName]"    : "handleCheckboxChange",
        "change [name=showInHeader]"     : "handleCheckboxChange",
        "change [name=hideOnEdit]"       : "handleCheckboxChange",
        "change [name=showDropdownIcon]" : "handleCheckboxChange"
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var modelAttributes = this.options.context.get("model").attributes;
        this.options.model = new Backbone.Model(modelAttributes);
        var initResult = this._super("initialize", arguments);

        this.manager = options.layout.layout;

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return $el
     */
    render: function () {
        this.manager.model.on("change:buttonsSettings", this.updateLayoutInformation, this);
        var $el = this._super("render");

        this.$el.find("[name=buttonType]").select2();
        this.$el.find("[name=buttonSize]").select2();
        this.$el.find("[name=iconPlacement]").select2();
        this.$el
            .find("[name=showInHeader]")
            .prop("checked", this.options.model.get("buttonsSettings").showInHeader === true);
        this.$el
            .find("[name=showLabelName]")
            .prop("checked", this.options.model.get("buttonsSettings").showLabelName === true);
        this.$el
            .find("[name=hideOnEdit]")
            .prop("checked", this.options.model.get("buttonsSettings").hideOnEdit === true);
        this.$el
            .find("[name=showDropdownIcon]")
            .prop("checked", this.options.model.get("buttonsSettings").showDropdownIcon === true);

        this.updateLayoutInformation(this.options.model);
        return $el;
    },

    /**
     * Description
     * @method closeDrawer
     * @return
     */
    closeDrawer: function (changesSaved) {
        this.context.attributes.callbackOnCancel.call(this, this.manager.layout);
        if (changesSaved === true) {
            this.manager.recordChangesMade(true);
        } else {
            this.manager.recordChangesMade(false);
            app.routing.offBefore("route", this.manager.beforeRouteChange, this);
        }

        app.drawer.close();
    },

    /**
     * Description
     * @method saveSettings
     * @return
     */
    saveSettings: function () {
        // saving the data into EXT4 and closing the drawer
        var canSave = this.manager.canSave();

        if (canSave === true) {
            this.storeLabels(this.manager.model.get("buttons"));
            this.context.attributes.saveCallback.call(this, this.manager.model.attributes);
            this.closeDrawer(true);
        }
    },

    storeLabels: function (buttonsData) {
        var languageData = {
            currentLanguage : App.lang.getLanguage(),
            moduleName      : this.manager.model.get("moduleName"),
            labels          : {}
        };

        _.each(buttonsData, function prepareLabels(buttonData) {
            buttonData.labelKey = this.getLocalizationKey(buttonData.label, buttonData.index);

            languageData.labels[buttonData.index] = {
                alreadyLocalized : buttonData.alreadyLocalized,
                labelKey         : buttonData.labelKey,
                labelValue       : buttonData.label ? buttonData.label : "NOT_LOCALIZED"
            };

            buttonData.alreadyLocalized = true;
        }.bind(this));

        app.api.call(
            "create",
            app.api.buildURL("SaveCustomButtonLabel"),
            languageData
        );
    },

    getLocalizationKey: function (label, id) {
        if (!label || label.indexOf("LBL###") < 0) {
            label = "LBL_RECORDBUTTON_" + id.replace(/-/g, "").toUpperCase();
        }

        return label;
    },

    /**
     * Description
     * @method changeGeneralSettings
     * @param {} event
     * @param {} value
     * @param {} dataKey
     * @return
     */
    changeGeneralSettings: function (event, value, dataKey) {
        var eventName = dataKey ? dataKey : event.currentTarget.name;
        var eventValue = value ? value : event.currentTarget.value;
        // inform the layout that we want to change the general settings
        this.manager.changeGeneralSettings(eventName, eventValue);
    },

    /**
     * Description
     * @method handleCheckboxChange
     * @param {} event
     * @return
     */
    handleCheckboxChange: function (event) {
        this.changeGeneralSettings(event, event.currentTarget.checked);
    },

    /**
     * Description
     * @method updateLayoutInformation
     * @param {} model
     * @return
     */
    updateLayoutInformation: function (model) {
        // update the view with the data from the main model
        var elementsToBeUpdated = model.get("buttonsSettings");
        var select2Elements = ["buttonType", "buttonSize", "iconPlacement"];
        var self = this;

        _.each(select2Elements, function updateElement(select2Element) {
            self.$el.find("[name=" + select2Element + "]").select2("val", elementsToBeUpdated[select2Element]);
        });
    }
});