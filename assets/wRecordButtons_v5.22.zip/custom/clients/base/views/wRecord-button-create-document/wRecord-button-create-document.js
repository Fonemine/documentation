/**
 * Class Description
 *
 * @class wRecord-button-create-document
 */
({
    extendsFrom: "CreateView",

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        // rearrange view
        var faultyFields = [
            "filename",
            "follow",
            "favorite",
            "document_name",
            "related_doc_name",
            "related_doc_rev_number",
            "last_rev_created_name",
            "last_rev_create_date",
            "status"
        ];
        var fieldsToRemove = [];

        // get the faulty fields
        _.each(this.meta.panels, function searchForFaultyFields(panel, panelIndex) {
            _.each(panel.fields, function removeFaultyField(field, fieldIndex) {
                if (field && field.name && _.contains(faultyFields, field.name)) {
                    fieldsToRemove.unshift({
                        fieldIndex : fieldIndex,
                        panelIndex : panelIndex
                    });
                }
            });
        });

        // remove the faulty fields
        for (var i = 0; i < fieldsToRemove.length; i++) {
            this.meta.panels[fieldsToRemove[i].panelIndex].fields.splice(fieldsToRemove[i].fieldIndex, 1);
        }

        // add the proper fields
        this.meta.panels[0].fields.push({
            label : "LBL_DOCUMENT_NAME",
            name  : "document_name",
            type  : "text"
        });
        this.meta.panels[1].fields.unshift({
            label : "LBL_DOC_TYPE",
            name  : "doc_type",
            type  : "enum"
        });
        this.meta.panels[1].fields.unshift({
            label : "LBL_DOC_STATUS",
            name  : "status_id",
            type  : "enum"
        });
        this.meta.panels[1].fields.unshift({
            label : "LBL_FILENAME",
            name  : "filename",
            type  : "file"
        });

        this.model.set(this.options.context.get("predefinedModel").attributes);
        var renderResult = this._super("render", arguments);

        return renderResult;
    },

    /**
     * Description
     * @method saveAndClose
     * @return
     */
    saveAndClose: function () {
        // get the API URL
        var apiUrl = app.api.buildURL("CreateDocumentRevision");

        // get the file to be uploaded
        var documentFile = this.$el.find("[name=filename]")[0].files[0];

        // get the file name
        var documentName = this.$el.find("[name=document_name]").val();

        // validate model
        this.validateModelWaterfall(function defaultValidationFunction() { });

        // if we have the file and the name we can start uploading the new document
        if (documentFile && documentName !== "") {
            var formData = new FormData();

            // insert all the data we need into the formData
            formData.append("documentFile", documentFile);
            formData.append("documentAttributes", JSON.stringify(this.model.attributes));
            formData.append("currentUserId", App.user.get("id"));

            this.disableButtons();

            // ajax request that handles the document creation
            $.ajax({
                url         : apiUrl,
                type        : "POST",
                data        : formData,
                processData : false,
                contentType : false,
                success     : function closeDrawerCallback(documentId) {
                    app.drawer.close(documentId, this.model.get("mustLinkRecord"));
                }.bind(this)
            });
        }
    }
});
