/**
 * Class Description
 *
 * @class wrecord-button-create-record
 */
({
    events: {
        "click .removeFieldInfo": "removeFieldInfo"
    },

    fieldsList       : {},
    parentFieldsList : {},

    currentRecordField : false,
    parentRecordField  : false,

    render: function () {
        var renderResult = this._super("render", arguments);

        this.currentRecordField = this.options.currentRecordField;
        this.parentRecordField = this.options.parentRecordField;

        this.fieldsList = this.getCompleteFieldsList(this.options.parentView.actionParameters.recordType, false);
        this.parentFieldsList = this.getCompleteFieldsList(this.options.manager.model.get("moduleName"), true);
        this.createCustomSelect2Dropdown(".fieldsList", "fieldsList", this.modifyData.bind(this), false, false);

        this.createCustomSelect2Dropdown(
            ".parentFieldsList",
            "parentFieldsList",
            this.modifyData.bind(this),
            false,
            false
        );

        if (this.currentRecordField && this.parentRecordField) {
            // set default or saved values for the elements in this view
            this.$el.find(".fieldsList").select2("data", {
                id   : this.currentRecordField,
                text : this.fieldsList[this.currentRecordField]
            });

            this.$el.find(".parentFieldsList").select2("data", {
                id   : this.parentRecordField,
                text : this.parentFieldsList[this.parentRecordField]
            });
        }

        return renderResult;
    },

    modifyData: function (fieldName, listName) {
        var metadataModule = app.metadata.getModule(this.options.parentView.actionParameters.recordType);
        var fieldsList = metadataModule.fields;

        if (fieldsList[fieldName] && listName === "fieldsList") {
            var groupFields = {};

            for (var fieldIndex = 0; fieldIndex < groupFields.length; fieldIndex++) {
                if (this.parentFieldsList[groupFields[fieldIndex]]) {
                    var newViewID = this.options.parentView.createFieldPopulatedFromParent(
                        groupFields[fieldIndex],
                        groupFields[fieldIndex]
                    );

                    this.options.parentView.modifyParentPopulatedFieldsData(
                        newViewID,
                        groupFields[fieldIndex],
                        groupFields[fieldIndex]
                    );
                }
            }
        }

        if (listName === "fieldsList") {
            this.currentRecordField = fieldName;
        } else {
            this.parentRecordField = fieldName;
        }

        if (!_.isEmpty(this.currentRecordField) && !_.isEmpty(this.parentRecordField)) {
            this.options.parentView.modifyParentPopulatedFieldsData(
                this.options.fieldViewID,
                this.currentRecordField,
                this.parentRecordField
            );
        }
    },

    getCompleteFieldsList: function (module, takeReadOnly) {
        var metadataModule = app.metadata.getModule(module);
        var fieldsList = metadataModule.fields;
        var cleanFieldsList = {};

        _.each(fieldsList, function clean(field) {
            // Remove blacklisted fields
            if ((field.readonly && !takeReadOnly) || !field.name || !(field.label || field.vname)) {
                return;
            }

            var displayName = field.label ? field.label : App.lang.get(field.vname, module);

            cleanFieldsList[field.name] = displayName + " (" + field.name + ")";
        });

        return cleanFieldsList;
    },

    getSelect2Options: function (optionsType) {
        var select2Options = {};

        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query" + optionsType], this);
        select2Options.selectOnBlur = true;

        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text === "CURRENT RECORD") {
                    return -1;
                } else if (secondLabel.text === "CURRENT RECORD") {
                    return 1;
                }

                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _queryfieldsList: function (query) {
        this._query(query, "fieldsList");
    },

    _queryparentFieldsList: function (query) {
        this._query(query, "parentFieldsList");
    },

    _query: function (query, customListName) {
        var listElements = this[customListName];
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listElements)) {
            _.each(listElements, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listElements = null;
        }

        query.callback(data);
    },

    _initSelection: function ($ele, callback) {},

    createCustomSelect2Dropdown: function (elementId, listType, callback, updateSelect2Callback, hide) {
        // create the select2 dropdowns
        var fieldsSelect2 = this.$el
            .find(elementId)
            .select2(this.getSelect2Options(listType))
            .data("select2");

        fieldsSelect2.onSelect = (function select(fn) {
            return function updateSelect2(data, options) {
                if (callback) {
                    callback(data.id, listType);
                }

                if (updateSelect2Callback) {
                    updateSelect2Callback(data);
                }

                return fn.apply(this, arguments);
            };
        })(fieldsSelect2.onSelect);

        if (hide) {
            this.$el.find(elementId).hide();
        }
    },

    removeFieldInfo: function () {
        this.options.parentView.removeParentPopulatedFieldsData(this.options.fieldViewID);
    }
});