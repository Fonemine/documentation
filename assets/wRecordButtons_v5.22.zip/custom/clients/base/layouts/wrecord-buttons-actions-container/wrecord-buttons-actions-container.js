/**
 * Class Description
 *
 * @class wrecord-buttons-actions-container
 */
({
    events: {
        "change [name=icon]"              : "handleButtonDataChange",
        "input [name=label]"              : "handleLabelChanged",
        "input [name=generalDescription]" : "handleButtonDataChange",
        "click a[name=closeDrawer]"       : "closeDrawer",
        "click a[name=saveSettings]"      : "saveSettings",
        "change [name=showLabel]"         : "handleCheckboxChange",
        "change [name=showIcon]"          : "handleCheckboxChange",
        "change [name=buttonStyle]"       : "handleButtonDataChange",
        "change [name=iconColor]"         : "handleButtonDataChange",
        "change [name=dependencyField]"   : "handleDependencyChange",
        "click #panelToggle"              : "expandGeneralSettings",
        "click #addActionButton"          : "handleAddAction"
    },

    iconsColorsList: {
        aliceblue            : "#f0f8ff",
        antiquewhite         : "#faebd7",
        aqua                 : "#00ffff",
        aquamarine           : "#7fffd4",
        azure                : "#f0ffff",
        beige                : "#f5f5dc",
        bisque               : "#ffe4c4",
        black                : "#000000",
        blanchedalmond       : "#ffebcd",
        blue                 : "#0000ff",
        blueviolet           : "#8a2be2",
        brown                : "#a52a2a",
        burlywood            : "#deb887",
        cadetblue            : "#5f9ea0",
        chartreuse           : "#7fff00",
        chocolate            : "#d2691e",
        coral                : "#ff7f50",
        cornflowerblue       : "#6495ed",
        cornsilk             : "#fff8dc",
        crimson              : "#dc143c",
        cyan                 : "#00ffff",
        darkblue             : "#00008b",
        darkcyan             : "#008b8b",
        darkgoldenrod        : "#b8860b",
        darkgray             : "#a9a9a9",
        darkgreen            : "#006400",
        darkgrey             : "#a9a9a9",
        darkkhaki            : "#bdb76b",
        darkmagenta          : "#8b008b",
        darkolivegreen       : "#556b2f",
        darkorange           : "#ff8c00",
        darkorchid           : "#9932cc",
        darkred              : "#8b0000",
        darksalmon           : "#e9967a",
        darkseagreen         : "#8fbc8f",
        darkslateblue        : "#483d8b",
        darkslategray        : "#2f4f4f",
        darkslategrey        : "#2f4f4f",
        darkturquoise        : "#00ced1",
        darkviolet           : "#9400d3",
        deeppink             : "#ff1493",
        deepskyblue          : "#00bfff",
        dimgray              : "#696969",
        dimgrey              : "#696969",
        dodgerblue           : "#1e90ff",
        firebrick            : "#b22222",
        floralwhite          : "#fffaf0",
        forestgreen          : "#228b22",
        fuchsia              : "#ff00ff",
        gainsboro            : "#dcdcdc",
        ghostwhite           : "#f8f8ff",
        gold                 : "#ffd700",
        goldenrod            : "#daa520",
        gray                 : "#808080",
        green                : "#008000",
        greenyellow          : "#adff2f",
        grey                 : "#808080",
        honeydew             : "#f0fff0",
        hotpink              : "#ff69b4",
        indianred            : "#cd5c5c",
        indigo               : "#4b0082",
        ivory                : "#fffff0",
        khaki                : "#f0e68c",
        lavender             : "#e6e6fa",
        lavenderblush        : "#fff0f5",
        lawngreen            : "#7cfc00",
        lemonchiffon         : "#fffacd",
        lightblue            : "#add8e6",
        lightcoral           : "#f08080",
        lightcyan            : "#e0ffff",
        lightgoldenrodyellow : "#fafad2",
        lightgray            : "#d3d3d3",
        lightgreen           : "#90ee90",
        lightgrey            : "#d3d3d3",
        lightpink            : "#ffb6c1",
        lightsalmon          : "#ffa07a",
        lightseagreen        : "#20b2aa",
        lightskyblue         : "#87cefa",
        lightslategray       : "#778899",
        lightslategrey       : "#778899",
        lightsteelblue       : "#b0c4de",
        lightyellow          : "#ffffe0",
        lime                 : "#00ff00",
        limegreen            : "#32cd32",
        linen                : "#faf0e6",
        magenta              : "#ff00ff",
        maroon               : "#800000",
        mediumaquamarine     : "#66cdaa",
        mediumblue           : "#0000cd",
        mediumorchid         : "#ba55d3",
        mediumpurple         : "#9370db",
        mediumseagreen       : "#3cb371",
        mediumslateblue      : "#7b68ee",
        mediumspringgreen    : "#00fa9a",
        mediumturquoise      : "#48d1cc",
        mediumvioletred      : "#c71585",
        midnightblue         : "#191970",
        mintcream            : "#f5fffa",
        mistyrose            : "#ffe4e1",
        moccasin             : "#ffe4b5",
        navajowhite          : "#ffdead",
        navy                 : "#000080",
        oldlace              : "#fdf5e6",
        olive                : "#808000",
        olivedrab            : "#6b8e23",
        orange               : "#ffa500",
        orangered            : "#ff4500",
        orchid               : "#da70d6",
        palegoldenrod        : "#eee8aa",
        palegreen            : "#98fb98",
        paleturquoise        : "#afeeee",
        palevioletred        : "#db7093",
        papayawhip           : "#ffefd5",
        peachpuff            : "#ffdab9",
        peru                 : "#cd853f",
        pink                 : "#ffc0cb",
        plum                 : "#dda0dd",
        powderblue           : "#b0e0e6",
        purple               : "#800080",
        rebeccapurple        : "#663399",
        red                  : "#ff0000",
        rosybrown            : "#bc8f8f",
        royalblue            : "#4169e1",
        saddlebrown          : "#8b4513",
        salmon               : "#fa8072",
        sandybrown           : "#f4a460",
        seagreen             : "#2e8b57",
        seashell             : "#fff5ee",
        sienna               : "#a0522d",
        silver               : "#c0c0c0",
        skyblue              : "#87ceeb",
        slateblue            : "#6a5acd",
        slategray            : "#708090",
        slategrey            : "#708090",
        snow                 : "#fffafa",
        springgreen          : "#00ff7f",
        steelblue            : "#4682b4",
        tan                  : "#d2b48c",
        teal                 : "#008080",
        thistle              : "#d8bfd8",
        tomato               : "#ff6347",
        turquoise            : "#40e0d0",
        violet               : "#ee82ee",
        wheat                : "#f5deb3",
        white                : "#ffffff",
        whitesmoke           : "#f5f5f5",
        yellow               : "#ffff00",
        yellowgreen          : "#9acd32"
    },
    cleanIconsColorsList       : {},
    dependencyFormulaContainer : null,
    buttonId                   : null,
    buttonParameters           : {},
    actionsView                : {},
    manager                    : null,
    generalSettingsExpanded    : true,
    canDeleteActionView        : true,

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var modelAttributes = this.options.context.get("model").attributes;
        this.options.model = new Backbone.Model(modelAttributes);

        this.initializeButtonParameters();

        _.each(
            this.iconsColorsList,
            function cleanList(iconCode, iconName) {
                iconName = iconName.charAt(0).toUpperCase() + iconName.slice(1);
                this.cleanIconsColorsList[iconCode] = iconName;
            },
            this
        );

        var initResult = this._super("initialize", arguments);

        this.dependencyFormulaContainer = null;
        this.manager = options.layout.layout;
        this.manager.on("wRecordButton-pressed", this.showButtonConfig.bind(this));

        return initResult;
    },

    _initSelection: function ($ele, callback) {},

    /**
     * Description
     * @method initializeButtonParameters
     * @return
     */
    initializeButtonParameters: function () {
        // set default params
        this.buttonParameters = {
            orderNumber        : 1,
            label              : "",
            actions            : {},
            showLabel          : true,
            icon               : "",
            showIcon           : false,
            iconColor          : "Red",
            index              : "",
            buttonStyle        : "default",
            dependencyField    : false,
            generalDescription : "",
            dependencyData     : {
                formulaElement    : "",
                validationMessage : "",
                validFormula      : false
            }
        };
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        var renderResult = this._super("render", arguments);
        this.$el.find("[name=iconColor]").select2(this.getCustomSelect2Options());
        this.$el.find("#generalSettingsFade").css("display", "none");
        this.initializeIconsList();
        this.updateButton();

        return renderResult;
    },

    getCustomSelect2Options: function () {
        var select2Options = {};

        select2Options.formatResult = this.formatIconsColorsList;
        select2Options.placeholder = app.lang.get("LBL_SEARCH_SELECT");
        // select2Options.initSelection = _.bind(this._initSelection, this);
        select2Options.query = _.bind(this["_query"], this);
        select2Options.selectOnBlur = true;
        select2Options.initSelection = this._initSelection;
        /**
         * Description
         * @method sortResults
         * @param {} results
         * @return CallExpression
         */
        select2Options.sortResults = function sortResults(results) {
            return results.sort(function sortAlphabetically(firstLabel, secondLabel) {
                if (firstLabel.text > secondLabel.text) {
                    return 1;
                }

                if (firstLabel.text < secondLabel.text) {
                    return -1;
                }

                return 0;
            });
        };

        return select2Options;
    },

    _query: function (query) {
        var listEntry = this.cleanIconsColorsList;
        var data = {
            results : [],
            more    : false
        };

        if (_.isObject(listEntry)) {
            _.each(listEntry, function pushValidResults(element, index) {
                var text = "" + element;

                // Additionally filter results based on query term //
                if (query.matcher(query.term, text)) {
                    data.results.push({
                        id   : index,
                        text : text
                    });
                }
            });
        } else {
            listEntry = null;
        }

        query.callback(data);
    },

    formatIconsColorsList: function (option) {
        var iconColorText = option.text;
        var iconColorOptionHtml =
            "<div style=\"display:inline-flex;\"> \
            <div style=\"width:  20px;background-color:" +
            option.id +
            "\
;height: 20px;margin-right:  5px;\"></div>" +
            iconColorText +
            "</div>";
        return iconColorOptionHtml;
    },

    /**
     * Description
     * @method closeDrawer
     * @return
     */
    closeDrawer: function () {
        this.$el.hide();
        app.drawer.close();
    },

    /**
     * Description
     * @method saveSettings
     * @return
     */
    saveSettings: function () {
        // saving the data into EXT4 and closing the drawer
        var canSave = this.manager.canSave();

        if (canSave === true) {
            this.context.attributes.saveCallback.call(this, this.manager.model.attributes);
            this.closeDrawer();
        }
    },

    /**
     * Description
     * @method setCorruptedFeedback
     * @return
     */
    setCorruptedFeedback: function () {
        if (this.dependencyFormulaContainer) {
            this.dependencyFormulaContainer.$el.find("#dependencyFormulaTooltip").css("border", "1px solid red");
        }
    },

    /**
     * Description
     * @method setCleanFeedback
     * @return
     */
    setCleanFeedback: function () {
        if (this.dependencyFormulaContainer) {
            this.dependencyFormulaContainer.$el.find("#dependencyFormulaTooltip").css("border", "");
        }
    },

    /**
     * Description
     * @method initializeIconsList
     * @return
     */
    initializeIconsList: function () {
        // initialize the fontawesome icons
        this.$el.find("[name=icon]").select2({
            formatResult : this.formatIcons,
            /**
             * Description
             * @method sortResults
             * @param {} results
             * @return CallExpression
             */
            sortResults  : function (results) {
                return results.sort(function sortAlphabetically(firstIcon, secondIcon) {
                    if (firstIcon.text < secondIcon.text) {
                        return -1;
                    }

                    if (firstIcon.text > secondIcon.text) {
                        return 1;
                    }

                    return 0;
                });
            }
        });

        this.$el.find("[name=buttonStyle]").select2({
            formatResult: this.formatButtonStyle
        });
    },

    /**
     * Description
     * @method formatButtonStyle
     * @param {} style
     * @return BinaryExpression
     */
    formatButtonStyle: function (style) {
        return "<a class=\"btn " + style.id + "\" style=\"width:20px;height:10px;\"></a> " + style.text;
    },

    /**
     * Description
     * @method formatIcons
     * @param {} icon
     * @return BinaryExpression
     */
    formatIcons: function (icon) {
        var originalOption = icon.element;

        return "<i class=\"fa " + $(originalOption).data("icon") + "\"></i> " + icon.text;
    },

    /**
     * Description
     * @method updateButtonData
     * @param {} buttonData
     * @return
     */
    updateButtonData: function (buttonData) {
        buttonData.label = this.localizeButtonLabel(buttonData.label, buttonData.labelKey, buttonData.index);

        // update with external data
        _.each(
            this.buttonParameters,
            function updateParam(paramValue, paramKey) {
                this.buttonParameters[paramKey] = _.clone(buttonData[paramKey]);
            }.bind(this)
        );
    },

    localizeButtonLabel: function (label, labelKey, id) {
        if ((!label || label.indexOf("LBL###")) < 0 && !labelKey) {
            labelKey = "LBL_RECORDBUTTON_" + id.replace(/-/g, "").toUpperCase();

            this.manager.handleButtonLabelChange(id, labelKey, label);
            // insert it into language file

            app.metadata.getStrings("mod_strings")[this.manager.model.get("moduleName")][labelKey] = label;
        }
        return app.lang.get(labelKey, this.manager.model.get("moduleName"));
    },

    /**
     * Description
     * @method updateButton
     * @return
     */
    updateButton: function () {
        // actually this updates the view of the button with the data we received earlier
        var labelsToBeUpdated = ["label", "actionParameter", "generalDescription"];
        var checkboxesToBeUpdated = ["showIcon", "showLabel", "dependencyField"];
        var dropdownsToBeUpdated = ["icon", "buttonStyle"];

        _.each(
            labelsToBeUpdated,
            function updateLabel(label) {
                this.$el.find("[name='" + label + "']").val(this.buttonParameters[label]);
            }.bind(this)
        );

        _.each(
            checkboxesToBeUpdated,
            function updateCheckbox(checkbox) {
                this.$el.find("[name='" + checkbox + "']").prop("checked", this.buttonParameters[checkbox] === true);
            }.bind(this)
        );

        _.each(
            dropdownsToBeUpdated,
            function updateDropdown(dropdown) {
                this.$el.find("[name=" + dropdown + "]").select2("val", this.buttonParameters[dropdown]);
            }.bind(this)
        );
        var initializeIconColor = this.cleanIconsColorsList[this.buttonParameters.iconColor] ?
            this.cleanIconsColorsList[this.buttonParameters.iconColor] :
            "Black";
        this.$el.find("[name=iconColor]").select2("data", {
            id   : this.buttonParameters.iconColor,
            text : initializeIconColor
        });

        if (this.buttonParameters.dependencyField === true) {
            if (this.dependencyFormulaContainer === null) {
                this.createDependencyView("wrecord-button-dependency-formula");
                this.dependencyFormulaContainer.render();
            }

            this.dependencyFormulaContainer.setParameters(this.buttonParameters.dependencyData);
        } else if (this.buttonParameters.dependencyField === false) {
            this.deleteDependencyView();
        }
    },

    /**
     * Description
     * @method createDependencyView
     * @param {} actionType
     * @return
     */
    createDependencyView: function (actionType) {
        // delete the existing view
        this.deleteDependencyView();

        // create the new udpated one
        var model = new Backbone.Model({});
        this.dependencyFormulaContainer = App.view.createView({
            name             : actionType,
            model            : model,
            parentView       : this,
            layout           : this.layout,
            selectedModule   : "Home",
            buttonId         : this.buttonId,
            manager          : this.manager,
            forcedReturnType : "boolean"
        });

        this.$el.find(".dependencyFormulaContainer").append(this.dependencyFormulaContainer.$el);
    },

    /**
     * Description
     * @method deleteDependencyView
     * @return
     */
    deleteDependencyView: function () {
        this.manager.trigger("clean-button-" + this.buttonId);
        this.manager.trigger("clean-button-" + this.buttonId + "-generalSettings");

        if (this.dependencyFormulaContainer !== null) {
            this.dependencyFormulaContainer.remove();
            this.dependencyFormulaContainer = null;
        }
    },

    /**
     * Description
     * @method deleteAllActions
     * @return
     */
    deleteAllActions: function () {
        var self = this;
        _.each(this.actionsView, function deleteAction(actionData, actionId) {
            self.deleteActionView(actionId);
        });
    },

    /**
     * Description
     * @method deleteActionView
     * @param {} actionId
     * @return
     */
    deleteActionView: function (actionId) {
        // remove an action by id
        if (this.actionsView[actionId] && this.canDeleteActionView === true) {
            this.actionsView[actionId].deleteParameterView();
            this.actionsView[actionId].remove();
            delete this.actionsView[actionId];
        }
    },

    /**
     * Description
     * @method createActionView
     * @param {} actionId
     * @return
     */
    createActionView: function (actionId) {
        // delete existing action view
        this.deleteActionView(actionId);

        var model = new Backbone.Model({});

        // create the new view
        this.actionsView[actionId] = App.view.createView({
            name             : "wrecord-button-action",
            model            : model,
            parentView       : this,
            actionIdentifier : actionId,
            buttonId         : this.buttonId,
            layout           : this,
            selectedModule   : "Home",
            manager          : this.manager
        });

        this.$el.find("#actionsContainer").append(this.actionsView[actionId].$el);
    },

    /**
     * Description
     * @method handleAddAction
     * @param {} e
     * @return
     */
    handleAddAction: function (e) {
        e.stopImmediatePropagation();
        var actionId = App.utils.generateUUID();
        var actions = {
            action           : "doNothing",
            actionParameters : {}
        };

        this.buttonParameters.actions[actionId] = actions;

        // we create a new view for the new action
        this.tryCreateNewActionView(actionId);

        // we update the data in the main model
        this.manager.handleButtonDataChange(this.buttonId, _.clone(this.buttonParameters));
    },

    /**
     * Description
     * @method tryCreateNewActionView
     * @param {} actionId
     * @return
     */
    tryCreateNewActionView: function (actionId) {
        // we recreate the actions
        this.deleteActionView(actionId);
        this.createActionView(actionId);
        this.actionsView[actionId].render();
    },

    /**
     * Description
     * @method removeButtonAction
     * @param {} actionId
     * @return
     */
    removeButtonAction: function (actionId) {
        // listen when an action is removed
        this.deleteActionView(actionId);
        delete this.buttonParameters.actions[actionId];
        this.changeButtonData(this.buttonId, _.clone(this.buttonParameters));
    },

    /**
     * Description
     * @method changeActionData
     * @param {} actionId
     * @param {} actionData
     * @return
     */
    changeActionData: function (actionId, actionData) {
        this.buttonParameters.actions[actionId] = _.clone(actionData);
        this.manager.handleButtonDataChange(this.buttonId, _.clone(this.buttonParameters));
    },

    /**
     * Description
     * @method handleButtonDataChange
     * @param {} event
     * @param {} value
     * @return
     */
    handleButtonDataChange: function (event, value) {
        var dataType = event.currentTarget.name;
        var dataValue = value ? value : event.currentTarget.value;

        this.changeButtonData(dataType, dataValue);
    },

    /**
     * Description
     * @method handleLabelChanged
     * @param {} event
     * @param {} value
     * @return
     */
    handleLabelChanged: function (event, value) {
        var dataValue = value ? value : event.currentTarget.value;

        var labelKey = "LBL_RECORDBUTTON_" + this.buttonParameters.index.replace(/-/g, "").toUpperCase();
        app.metadata.getStrings("mod_strings")[this.manager.model.get("moduleName")][labelKey] = dataValue;

        this.manager.buttonLabelHasChanged(dataValue, this.buttonParameters.index);
        this.handleButtonDataChange(event, dataValue);
    },

    /**
     * Description
     * @method handleCheckboxChange
     * @param {} event
     * @return
     */
    handleCheckboxChange: function (event) {
        this.handleButtonDataChange(event, event.currentTarget.checked);
    },

    /**
     * Description
     * @method handleDependencyChange
     * @param {} event
     * @return
     */
    handleDependencyChange: function (event) {
        if (event.currentTarget.checked === true) {
            this.createDependencyView("wrecord-button-dependency-formula");
            this.dependencyFormulaContainer.render();
            this.dependencyFormulaContainer.setParameters(this.buttonParameters.dependencyData);
        } else {
            this.deleteDependencyView();
        }

        this.handleButtonDataChange(event, event.currentTarget.checked);
    },

    /**
     * Description
     * @method changeButtonData
     * @param {} dataType
     * @param {} dataValue
     * @return
     */
    changeButtonData: function (dataType, dataValue, silent) {
        if (!silent) {
            silent = false;
        }
        this.buttonParameters[dataType] = dataValue;

        this.manager.handleButtonDataChange(this.buttonId, _.clone(this.buttonParameters), silent);

        this.updateButton();
    },

    /**
     * Description
     * @method showButtonConfig
     * @param {} buttonId
     * @return
     */
    showButtonConfig: function (buttonId) {
        if (this.manager && buttonId) {
            var buttonData = this.manager.model.get("buttons")[buttonId];

            if (buttonData) {
                // handle registered events
                if (this.buttonId) {
                    this.manager.off("corrupted-button-" + this.buttonId + "-generalSettings");
                    this.manager.off("clean-button-" + this.buttonId + "-generalSettings");
                }

                this.manager.on(
                    "corrupted-button-" + buttonId + "-generalSettings",
                    this.setCorruptedFeedback.bind(this)
                );
                this.manager.on("clean-button-" + buttonId + "-generalSettings", this.setCleanFeedback.bind(this));

                this.buttonId = buttonId;
                this.updateButtonData(buttonData);
                this.updateButton();

                // delete all the old actions before creating new ones
                this.deleteAllActions();

                // create action views
                this.actionsView = {};
                _.each(
                    this.buttonParameters.actions,
                    function reCreateActions(actionData, actionId) {
                        this.deleteActionView(actionId);
                        this.createActionView(actionId);

                        this.actionsView[actionId].render();
                        this.actionsView[actionId].setParameters(actionId, actionData);
                    }.bind(this)
                );
            }
        }
    },

    /**
     * Description
     * @method expandGeneralSettings
     * @return
     */
    expandGeneralSettings: function () {
        var chevronElement = this.$el.find("#expandGeneralSettings");
        this.generalSettingsExpanded = !this.generalSettingsExpanded;

        if (this.generalSettingsExpanded) {
            chevronElement.children().addClass("fa-chevron-up");
            chevronElement.children().removeClass("fa-chevron-down");
        } else {
            chevronElement.children().removeClass("fa-chevron-up");
            chevronElement.children().addClass("fa-chevron-down");
        }
    },

    /**
     * Description
     * @method fadeGeneralSettings
     * @param {} event
     * @return
     */
    fadeGeneralSettings: function (event) {
        var generalSettings = this.$el.find("#generalSettings");
        var headerBar = this.$el.find("#generalSettingsFade");
        var settingsHeight = generalSettings.height();
        var currentYPos = generalSettings.offset().top;

        if (currentYPos < 0 && Math.abs(currentYPos) >= settingsHeight) {
            if (!headerBar.is(":visible")) {
                headerBar.fadeIn("slow");
            }
        } else if (currentYPos > -1 * settingsHeight) {
            headerBar.fadeOut("slow");
        }
    }
});