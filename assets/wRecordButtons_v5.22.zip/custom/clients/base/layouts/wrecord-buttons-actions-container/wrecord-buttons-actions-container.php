<?php
$viewdefs['base']['layout']['wrecord-buttons-actions-container'] = array(
    'name'       => 'wrecord-buttons-actions-container',
    'type'       => 'wrecord-buttons-actions-container',
    'span'       => 12,
    'components' => array(),
);
