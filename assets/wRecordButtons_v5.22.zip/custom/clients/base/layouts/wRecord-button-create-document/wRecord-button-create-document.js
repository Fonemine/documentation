({
    initialize: function(options) {
        if (this.parseVersion(App.metadata.getServerInfo().version) <= this.parseVersion("7.8")) {
            options = this.removeCssClassFromLayouts(options);
        }

        var initSuper = this._super("initialize", [options]);
        return initSuper;
    },

    render: function() {
        var renderResult = this._super("render", arguments);
        return renderResult;
    },

    /**
     * calculate SugarVersion Score
     */
    parseVersion: function(version, versionSeparator) {
        var versionScoreMultiplierData = {
            major    : 1000000,
            minor    : 10000,
            subminor : 100,
            patch    : 1
        };
        var versionScore = 0;
        var defaultVersion = 0;

        version = version ? version : "";
        versionSeparator = versionSeparator ? versionSeparator : ".";

        version = version.slice(0, version.indexOf("-") > -1 ? version.indexOf("-") : version.length);

        _.each(versionScoreMultiplierData, function getVersionData(versioningScore) {
            var indexOfVersionSeparator =
                version.indexOf(versionSeparator) > -1 ? version.indexOf(versionSeparator) : version.length;

            var versionNumber = version.slice(0, indexOfVersionSeparator)
                ? version.slice(0, indexOfVersionSeparator)
                : version;

            if (versionNumber === "") {
                versionNumber = defaultVersion;
            }

            version = version.slice(indexOfVersionSeparator + 1, version.length);

            versionScore = versionScore + parseInt(versionNumber) * versioningScore;
        });

        if (isNaN(versionScore) === true) {
            versionScore = 0;
        }

        return versionScore;
    },

    removeCssClassFromLayouts: function(options) {
        var newOptions = options;
        if (options && options.meta && options.meta.components) {
            var sidebarComponent = _.find(options.meta.components, function goThroughComponents(c) {
                return c && c.layout && c.layout.name && c.layout.name == "sidebar";
            });
            if (sidebarComponent && sidebarComponent.layout) {
                var sidebarLayout = sidebarComponent.layout;
                for (var i = 0; i < sidebarLayout.components.length; i++) {
                    var component = sidebarLayout.components[i];
                    if (component && component.layout && component.layout.css_class) {
                        delete component.layout.css_class;
                    }
                }
            }
        }
        return newOptions;
    }
});
