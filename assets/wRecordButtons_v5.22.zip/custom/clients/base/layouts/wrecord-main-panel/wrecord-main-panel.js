/**
 * Class Description
 *
 * @class wrecord-main-panel
 */
({
    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function(options) {
        var buttonsParsed = options.layout.model.attributes;
        var setingsModel = new Backbone.Model(buttonsParsed);

        this.options.context.model = setingsModel;
        this.options.context.model.module = "Home";

        var initResult = this._super("initialize", arguments);

        this.model = setingsModel;

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function() {
        var renderResult = this._super("render", arguments);

        this.$el.css("top", "0px");
        this.$el.css("margin-left", "0px");
        this.$el.css("width", "62%");
        this.$el.css("border-right", "1px solid gainsboro");
        this.$el.addClass("main-pane span12");

        this.$el.scroll(
            function notifyActionsContainer(event) {
                var actionsContainerLayout = this.getComponent("wrecord-buttons-actions-container");

                if (actionsContainerLayout) {
                    actionsContainerLayout.fadeGeneralSettings(event);
                }
            }.bind(this)
        );

        return renderResult;
    }
});
