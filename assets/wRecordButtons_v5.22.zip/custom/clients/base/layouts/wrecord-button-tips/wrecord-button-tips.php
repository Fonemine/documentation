<?php
$viewdefs['base']['layout']['wrecord-button-tips'] = array(
    'name'       => 'wrecord-button-tips',
    'type'       => 'wrecord-button-tips',
    'span'       => 3,
    'components' => array(),
);
