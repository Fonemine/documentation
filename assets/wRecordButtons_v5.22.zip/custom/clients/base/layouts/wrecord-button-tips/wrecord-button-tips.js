/**
 * Class Description
 *
 * @class wrecord-button-tips
 */
({
    availableTips: {
        updateField    : true,
        assignRecord   : true,
        createRecord   : true,
        mergeDocument  : true,
        runUrl         : true,
        runJob         : true,
        composeMail    : true,
        tabsManagement : true,
        editRecord     : true,
        saveRecord     : true,
        convertLead    : true,
        directions     : true,
        handleRoute    : true,
        runReport      : true,
        map            : true,
        nearby         : true
    },
    tip        : null,
    tipsViews  : {},
    tipsTitles : {
        updateField    : "Update Field Action",
        assignRecord   : "Assign Record Action",
        createRecord   : "Create Record Action",
        mergeDocument  : "Merge Documents Action",
        runUrl         : "Run URL Action",
        runJob         : "Run Job Action",
        runReport      : "Run Report Action",
        convertLead    : "Convert Lead Action",
        composeMail    : "Compose Mail Action",
        doNothing      : "",
        tabsManagement : "Tabs/Panels Visibility Control",
        editRecord     : "Edit Record Action",
        saveRecord     : "Save Record Action",
        directions     : "Show Directions Action",
        handleRoute    : "Manage wMaps Route Action",
        map            : "Bing Map Action",
        nearby         : "Nearby Action"
    },

    /**
     * Description
     * @method initialize
     * @param {} options
     * @return
     */
    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.model = new Backbone.Model(this.model.attributes);
        this.tip = null;
        this.tipsViews = {};

        return initResult;
    },

    /**
     * Description
     * @method render
     * @return
     */
    render: function () {
        // register needed events
        this.options.layout.on("show:tip", this.showTipPressed, this);

        var renderResult = this._super("render", arguments);

        this.styleElement();

        return renderResult;
    },

    /**
     * Description
     * @method showTipPressed
     * @param {} tipType
     * @return
     */
    showTipPressed: function (tipType) {
        // if we have a current tip and it is different from the new one we want to show
        if (!this.tip || (this.tip && this.tip !== this.tipsViews[tipType])) {
            // hide the current tip
            this.hideCurrentTip();

            // create or show the new tip
            this.tryCreateTip(tipType);
        }
    },

    /**
     * Description
     * @method hideCurrentTip
     * @return
     */
    hideCurrentTip: function () {
        // if we have a current tip, we hide it
        if (this.tip) {
            this.tip.hide();
            this.tip = null;
        }
    },

    /**
     * Description
     * @method tryCreateTip
     * @param {} action
     * @return
     */
    tryCreateTip: function (action) {
        // change the title
        this.$el.find("h4").text(this.tipsTitles[action] + " Tips");
        // show the no tips description
        this.$el.find("h2").show();

        // if we have the tip already created, we show it
        if (this.tipsViews[action]) {
            this.$el.find("h2").hide();
            this.tip = this.tipsViews[action];
            this.tip.show();
        } else if (this.availableTips[action]) {
            // creating a new tip
            var model = new Backbone.Model({});
            var tip = App.view.createView({
                name           : "wrecord-button-" + action + "-tip",
                model          : model,
                parentView     : this,
                layout         : this,
                selectedModule : "Home"
            });

            this.$el.find("[name=\"tipsContainer\"]").append(tip.$el);
            tip.render();

            // update the current tip
            this.tip = tip;

            // cache the new tip
            this.tipsViews[action] = tip;

            // hide the No Tips description
            this.$el.find("h2").hide();
        }
    },

    /**
     * Description
     * @method styleElement
     * @return
     */
    styleElement: function () {
        this.$el.css("width", "37.9%");
        this.$el.css("margin-left", "62%");
    }
});