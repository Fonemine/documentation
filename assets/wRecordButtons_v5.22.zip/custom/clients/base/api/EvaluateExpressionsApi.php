<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

class EvaluateExpressionsApi extends ModuleApi
{
    public function registerApiRest()
    {
        return array(
            'evaluateExpressions'       => array(
                'reqType'   => 'POST',
                'path'      => array('EvaluateExpression', 'evaluate_expression'),
                'pathVars'  => array('', ''),
                'method'    => 'evaluateExpression',
                'shortHelp' => 'This method evaluates an expression',
                'longHelp'  => '',
            ),
            'evaluateExpressionsMobile' => array(
                'reqType'   => 'POST',
                'path'      => array('EvaluateExpressionsMobile', 'evaluate_expression_mobile'),
                'pathVars'  => array('', ''),
                'method'    => 'evaluateExpressionsMobile',
                'shortHelp' => 'This method evaluates an expression',
                'longHelp'  => '',
            ),
            'evaluateCalculatedURL'     => array(
                'reqType'   => 'POST',
                'path'      => array('EvaluateCalculatedURL', 'evaluate_calculated_url'),
                'pathVars'  => array('', ''),
                'method'    => 'evaluateCalculatedURL',
                'shortHelp' => 'This method evaluates an calculated URL',
                'longHelp'  => '',
            ),
            'calculateDependency'       => array(
                'reqType'   => 'POST',
                'path'      => array('EvaluateExpression', 'calculate_dependency'),
                'pathVars'  => array('', ''),
                'method'    => 'calculateDependency',
                'shortHelp' => 'This method checks the dependency of given fields',
                'longHelp'  => '',
            ),
            'calculateDependencyList'   => array(
                'reqType'   => 'POST',
                'path'      => array('EvaluateExpression', 'calculate_dependency_list'),
                'pathVars'  => array('', ''),
                'method'    => 'calculateDependencyList',
                'shortHelp' => 'This method checks the dependency of given fields',
                'longHelp'  => '',
            ),
        );
    }

    public function calculateDependencyList($api, $args)
    {
        $dependenciesValues = array();

        foreach ($args["rowsData"] as $rowId => $rowData) {
            $dependenciesValues[$rowId] = array();

            $wRBListData = array(
                "fieldsToBeUpdated" => array(),
                "recordId"          => false,
                "recordType"        => false,
            );

            foreach ($rowData as $fieldName => $fieldData) {
                $wRBListData["fieldsToBeUpdated"] = array_merge(
                    $wRBListData["fieldsToBeUpdated"],
                    $fieldData["fieldsToBeUpdated"]
                );

                $wRBListData["recordId"]   = $fieldData["recordId"];
                $wRBListData["recordType"] = $fieldData["recordType"];
            }
            $calculatedFieldsValues = $this->calculateDependency($api, $wRBListData);

            foreach ($calculatedFieldsValues as $fieldId => $calculatedFieldData) {
                if (!$dependenciesValues[$rowId][$calculatedFieldData["fieldName"]]) {
                    $dependenciesValues[$rowId][$calculatedFieldData["fieldName"]] = array();
                }
                $dependenciesValues[$rowId][$calculatedFieldData["fieldName"]][$fieldId] = $calculatedFieldData;
            }
        }

        return $dependenciesValues;
    }

    public function calculateDependency($api, $args)
    {
        global $current_user;

        $expressionValues  = array();
        $fieldsToBeUpdated = $args['fieldsToBeUpdated'];
        $bean              = BeanFactory::retrieveBean($args['recordType'], $args['recordId']);

        if ($bean) {
            $this->populateBean($bean, $api, $args);

            $fieldIndex       = 0;
            $calculatedFields = array();

            // enforce fields to calculate their value with the formula provided
            foreach ($fieldsToBeUpdated as $fieldName => $paramsData) {
                $targetField                     = $paramsData["targetField"];
                $bean->fetched_row[$targetField] = array();

                if ($bean->field_defs[$targetField]["calculated"] === true) {
                    $tmpField = $targetField . $fieldIndex;

                    $bean->field_defs[$tmpField]            = $bean->field_defs[$targetField];
                    $bean->field_defs[$tmpField]["id"]      = $bean->field_defs[$tmpField]["id"] . $fieldIndex;
                    $bean->field_defs[$tmpField]["options"] = "";
                    $bean->fetched_row[$tmpField]           = array();

                    $targetField = $tmpField;
                    $fieldIndex  = $fieldIndex + 1;
                } else {
                    $bean->field_defs[$targetField]['enforced']   = true;
                    $bean->field_defs[$targetField]['calculated'] = true;
                }

                if (strpos($paramsData["formula"], '$currentUserID') > -1) {

                    $paramsData["formula"] = str_replace('$currentUserID', "\"" . $current_user->id . "\"", $paramsData["formula"]);
                    $assignedUser          = BeanFactory::retrieveBean("Users", $bean->assigned_user_id);
                    $manager               = BeanFactory::retrieveBean("Users", $assignedUser->reports_to_id);
                    $managerOfManagerID    = $manager->reports_to_id;

                    $paramsData["formula"] = str_replace('$managerOfManagerID', "\"" . $managerOfManagerID . "\"", $paramsData["formula"]);
                }

                $bean->field_defs[$targetField]["formula"] = $paramsData["formula"];

                $calculatedFields[$fieldName] = array(
                    "tempFieldName" => $targetField,
                    "buttonId"      => $paramsData["buttonId"],
                    "targetField"   => $paramsData["targetField"],
                );
            }

            $bean->updateCalculatedFields();
            $formattedBean = $this->formatBean($api, $args, $bean);

            // enforce fields to calculate their value with the formula provided
            foreach ($calculatedFields as $fieldName => $paramsData) {
                $value = $formattedBean[$paramsData["tempFieldName"]];

                if (is_object($value)) {
                    $value = strval($value);
                }

                $expressionValues[$fieldName]              = array();
                $expressionValues[$fieldName]["value"]     = $value;
                $expressionValues[$fieldName]["buttonId"]  = $paramsData["buttonId"];
                $expressionValues[$fieldName]["fieldName"] = $paramsData["targetField"];
            }
        }

        return $expressionValues;
    }

    public function evaluateExpressionsMobile($api, $args)
    {
        global $current_user;
        $fieldsToBeUpdated = $args['fieldsToBeUpdated'];

        $bean           = BeanFactory::retrieveBean($args['recordType'], $args['recordId']);
        $modifiedFields = array();

        if ($bean) {
            // enforce fields to calculate their value with the formula provided
            foreach ($fieldsToBeUpdated as $fieldName => $paramsData) {
                $bean->fetched_row[$paramsData['targetField']] = array();

                if (!$bean->field_defs[$paramsData['targetField']]) {
                    $bean->field_defs[$paramsData['targetField']] = array(
                        'name' => $paramsData['targetField'],
                        'type' => 'text',
                    );
                }

                if ($paramsData['formula'] === "getCurrentUser()") {
                    $paramsData['formula'] = str_replace("getCurrentUser()", "toString(\"" . $current_user->full_name . "\")", $paramsData['formula']);
                } else {
                    $paramsData['formula'] = str_replace("getCurrentUser()", "\"" . $current_user->full_name . "\"", $paramsData['formula']);
                }

                $bean->field_defs[$paramsData['targetField']]['enforced']   = true;
                $bean->field_defs[$paramsData['targetField']]['calculated'] = true;
                $bean->field_defs[$paramsData['targetField']]['formula']    = $paramsData['formula'];
            }

            $bean->updateCalculatedFields();
        }

        foreach ($fieldsToBeUpdated as $fieldName => $fieldData) {
            $modifiedFields[$fieldName] = $bean->{$fieldName};
        }

        return $modifiedFields;
    }

    public function evaluateExpression($api, $args)
    {
        global $current_user;
        $fieldsToBeUpdated = $args['fieldsToBeUpdated'];
        $bean              = BeanFactory::retrieveBean($args['recordType'], $args['recordId']);

        $freshCalculatedValues = array();

        if ($bean) {
            // enforce fields to calculate their value with the formula provided
            foreach ($fieldsToBeUpdated as $fieldName => $paramsData) {
                $bean->fetched_row[$paramsData['targetField']] = array();

                if (!$bean->field_defs[$paramsData['targetField']]) {
                    $bean->field_defs[$paramsData['targetField']] = array(
                        'name' => $paramsData['targetField'],
                        'type' => 'text',
                    );
                }

                if ($paramsData['formula'] === "getCurrentUser()") {
                    $paramsData['formula'] = str_replace("getCurrentUser()", "toString(\"" . $current_user->full_name . "\")", $paramsData['formula']);
                } else {
                    $paramsData['formula'] = str_replace("getCurrentUser()", "\"" . $current_user->full_name . "\"", $paramsData['formula']);
                }

                $bean->field_defs[$paramsData['targetField']]['enforced']   = true;
                $bean->field_defs[$paramsData['targetField']]['calculated'] = true;
                $bean->field_defs[$paramsData['targetField']]['formula']    = $paramsData['formula'];
            }

            $bean->updateCalculatedFields();
        }

        foreach ($fieldsToBeUpdated as $fieldName => $paramsData) {
            if ($bean->field_defs[$fieldName] && $bean->field_defs[$fieldName]["type"] === "datetime") {}
            $freshCalculatedValues[$fieldName] = $bean->{$fieldName};
        }

        return $freshCalculatedValues;
    }

    public function evaluateCalculatedURL($api, $args)
    {
        $calculatedExpressionValues    = array();
        $keepTempFieldForCalculatedURL = $args['keepTempFieldForCalculatedURL'];
        $bean                          = BeanFactory::retrieveBean($args['recordType'], $args['recordId']);

        if ($bean) {
            $this->populateBean($bean, $api, $args);

            foreach ($keepTempFieldForCalculatedURL as $tempFieldName => $paramsData) {
                $bean->fetched_row[$paramsData['targetField']]              = array();
                $bean->field_defs[$paramsData['targetField']]['enforced']   = true;
                $bean->field_defs[$paramsData['targetField']]['calculated'] = true;
                $bean->field_defs[$paramsData['targetField']]['formula']    = $paramsData['formula'];
            }

            // pre format bean so that we can calculate the new values
            $preFormattedBean = $this->formatBean($api, $args, $bean);

            foreach ($preFormattedBean as $tempFieldName => $fieldValue) {
                if ($bean->{$tempFieldName}) {
                    $oldValuesFromBean[$tempFieldName] = $bean->{$tempFieldName};
                    $bean->{$tempFieldName}            = $fieldValue;
                }
            }

            // calculate the new values
            $bean->updateCalculatedFields();

            $formattedBean              = $this->formatBean($api, $args, $bean);
            $calculatedExpressionValues = array();

            $recalculateValues = false;
            // check if the results are correct
            foreach ($keepTempFieldForCalculatedURL as $tempFieldName => $paramsData) {
                if ((!is_null($formattedBean[$tempFieldName])
                    && ($formattedBean[$tempFieldName] === false && (strpos($paramsData['formula'], 'year(') !== false)))
                    || (strpos($paramsData['formula'], 'timestamp') !== false
                        || strpos($paramsData['formula'], 'isBefore') !== false)
                ) {
                    $recalculateValues = true;
                }
            }

            if ($recalculateValues === true) {
                foreach ($oldValuesFromBean as $tempFieldName => $fieldValue) {
                    $bean->{$tempFieldName} = $fieldValue;
                }

                // calculate the values once again
                $bean->updateCalculatedFields();

                $formattedBean = $this->formatBean($api, $args, $bean);
            }

            // format the result in order to send them back to the controller
            foreach ($keepTempFieldForCalculatedURL as $tempFieldName => $paramsData) {
                $value = $formattedBean[$paramsData['targetField']];
                // if the value is an object, cast it to value
                if (is_object($value)) {
                    $value = strval($value);
                }

                $fieldType = $bean->field_defs[$paramsData['targetField']]['type'];

                // hack for when you try to set a bool value to a text field
                if (($fieldType == "varchar" || $fieldType == "text") && is_bool($value)) {
                    $value = ($value) ? 'true' : 'false';
                }

                $calculatedExpressionValues[$tempFieldName]             = array();
                $calculatedExpressionValues[$tempFieldName]['value']    = $value;
                $calculatedExpressionValues[$tempFieldName]['buttonId'] = $paramsData['buttonId'];

                $calculatedExpressionValues[$tempFieldName]['fieldName'] = $paramsData['targetField'];
            }
        }

        return $calculatedExpressionValues;
    }
}
