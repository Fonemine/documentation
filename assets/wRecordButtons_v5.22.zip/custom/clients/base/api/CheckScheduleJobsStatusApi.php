<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class CheckScheduleJobsStatusApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'CheckScheduleJobsStatus' => array(
                'reqType'   => 'POST',
                'path'      => array('CheckScheduleJobsStatus'),
                'pathVars'  => array(''),
                'method'    => 'checkScheduleJobsStatus',
                'shortHelp' => 'This inserts a job inside the job queue',
                'longHelp'  => '',
            ),
        );
    }

    public function checkScheduleJobsStatus($api, $args)
    {
        global $db;
        $conn = $db->getConnection();

        $activeJobs         = $args['jobs'];
        $activeJobsStatuses = array();

        // get jobs statuses
        foreach ($activeJobs as $jobId => $jobData) {
            $getJobQuery =
                <<<EOQ
SELECT status, resolution, name
FROM job_queue
WHERE deleted = 0 AND id='{$jobId}'
EOQ;

            $getJobQueryResult = $conn->executeQuery($getJobQuery);

            while ($row = $getJobQueryResult->fetch()) {
                //populate the list we send back to the controller
                $activeJobsStatuses[$jobId] = array(
                    'status'     => $row["status"],
                    'resolution' => $row["resolution"],
                    'jobName'    => $row["name"],
                );

                if ($row["status"] === "done") {
                    $this->createNotification($activeJobsStatuses, $jobId, $row["resolution"]);
                }
            }
        }

        return $activeJobsStatuses;
    }

    private function createNotification($activeJobsStatuses, $jobId, $jobResolution)
    {
        global $current_user;

        $jobNotification              = BeanFactory::newBean("Notifications");
        $jobNotification->name        = $activeJobsStatuses[$jobId]['jobName'] . " Job has been done on " . date("Y-m-d");
        $jobNotification->description = "
        The " . $activeJobsStatuses[$jobId]['jobName'] . " scheduled job has finished running</br>
        Resolution: " . strtoupper($jobResolution);
        $jobNotification->severity         = "wRecordButtons Job Status";
        $jobNotification->is_read          = 0;
        $jobNotification->assigned_user_id = $current_user->id;

        $jobNotification->save();
    }
}
