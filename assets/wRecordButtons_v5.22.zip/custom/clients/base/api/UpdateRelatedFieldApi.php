<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class UpdateRelatedFieldApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'updateRelatedField' => array(
                'reqType'   => 'POST',
                'path'      => array('UpdateRelatedField'),
                'pathVars'  => array(''),
                'method'    => 'updateRelatedField',
                'shortHelp' => 'This method updates a related field.',
                'longHelp'  => '',
            ),
            'updateCurrentModel' => array(
                'reqType'   => 'POST',
                'path'      => array('UpdateCurrentModel'),
                'pathVars'  => array(''),
                'method'    => 'updateCurrentModel',
                'shortHelp' => 'This method updates the current model.',
                'longHelp'  => '',
            ),
        );
    }

    public function updateCurrentModel($api, $args)
    {
        $module   = $args['module'];
        $fields   = $args['fields'];
        $recordId = $args['recordId'];

        $bean = BeanFactory::getBean($module, $recordId);

        foreach ($fields as $fieldName => $fieldValue) {
            $bean->{$fieldName} = $fieldValue;
        }

        $bean->save();

        return true;
    }

    public function updateRelatedField($api, $args)
    {
        global $timedate;
        $module        = $args['module'];
        $field         = $args['field'];
        $value         = $args['value'];
        $formula       = $args['formula'];
        $recordId      = $args['recordId'];
        $recordUpdated = false;

        if ($recordId && $recordId !== "") {
            $bean = BeanFactory::getBean($module, $recordId);

            if ($bean) {
                $fieldDef = $bean->field_defs[$field];

                // if we got a relate field we have to change the id instead of the name
                if ($fieldDef && $fieldDef["type"] === "relate") {
                    $field = $fieldDef["id_name"];
                }

                if ($formula) {
                    $this->populateBean($bean, $api, $args);
                    $bean->fetched_row[$field]              = array();
                    $bean->field_defs[$field]['enforced']   = true;
                    $bean->field_defs[$field]['calculated'] = true;
                    $bean->field_defs[$field]['formula']    = $formula;

                    $recordUpdated = true;
                } else {
                    if (is_array($value)) {
                        foreach ($value as $fieldName => $fieldValue) {
                            $bean->{$fieldName} = $fieldValue;
                            $recordUpdated      = true;
                        }
                    } else {
                        $bean->{$field} = $value;
                        $recordUpdated  = true;
                    }
                }

                if ($recordUpdated) {
                    $bean->save();
                }
            }
        }

        return $recordUpdated;
    }
}
