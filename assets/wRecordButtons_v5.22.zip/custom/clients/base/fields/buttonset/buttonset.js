/**
 * Class Description
 *
 * @class buttonset
 */
({
    plugins: ["LinkedModel"],

    buttons            : [],
    dependencyRequests : [],
    buttonsToBeCreated : [],
    activeJobs         : {},
    expressions        : {},
    buttonsData        : {
        buttons         : {},
        buttonsSettings : {}
    },
    updateFieldParams : {},
    actionsQueue      : {
        actions    : {},
        actionData : {}
    },
    isDropdown                  : false,
    isDashlet                   : false,
    iconOnLeft                  : false,
    checkJobsStatusInProgress   : false,
    dropdownPopulated           : false,
    isDashletOrPreview          : false,
    buttonsPartiallyLoaded      : false,
    buttonsTableKey             : false,
    createdButtons              : false,
    mustSaveModel               : false,
    buttonId                    : false,
    dropdownStyle               : null,
    dropdownSize                : null,
    dropdownIcon                : null,
    dropdownLabel               : null,
    dropdownId                  : null,
    containerType               : null,
    forcedWidth                 : 0,
    freeSpaceTreshold           : 250,
    marginBetweenHeaderElements : 25,
    mobileOnlyActions           : ["map", "nearby", "handleRoute", "directions"],
    bwcMapping                  : {
        createRecord : "wrecord-button-create-record",
        saveRecord   : "wrecord-button-save-record",
        assignRecord : "wrecord-button-assign-record",
    },

    alwaysLinkedRecords: {
        Calls: "Calls"
    },
    events: {
        "click .btn"          : "buttonClicked",
        "click .showDropdown" : "positionDropdownMenu"
    },

    initialize: function (options) {
        var initResult = this._super("initialize", arguments);

        this.modelId = this.model.id;
        // in case the name was messed up outside of this class we have to put it back
        this.name = this.def.realName ? this.def.realName : this.name;
        this.buttonsTableKey = this.def.buttonsTableKey;
        this.buttonId = App.utils.generateUUID();

        if (this.def.options) {
            // parse the data came from the studio
            this.def.options = this.replaceCharInFormula(this.def.options, "\\n", "###&&&###");
            this.def.options = this.replaceCharInFormula(this.def.options.replace(/\\/g, ""), "=\"", "='");
            this.def.options = this.replaceCharInFormula(this.def.options.replace(/\\/g, ""), "\">", "'>");
            this.def.options = this.replaceCharInFormula(this.def.options, ";\"", ";'");
            this.def.options = this.replaceCharInFormula(this.def.options, "\" >", "' >");
            this.def.options = this.replaceCharInFormula(this.def.options, "\" />", "' />");
            this.def.options = this.replaceCharInFormula(this.def.options, "###&&&###", "\\n");

            try {
                this.buttonsData = JSON.parse(this.def.options);
            } catch (e) {
                app.alert.show("wrb-config-error", {
                    level     : "error",
                    messages  : "Invalid wRecordButton configuration!",
                    autoClose : true
                });
            }

        }

        // try creating the buttons
        this.tryCreateButtonsList();
        this.model.on("sync", this.tryCreateButtonsList.bind(this));

        return initResult;
    },

    tryCreateButtonsList: function (model) {
        if (model && Object.keys(model.changed).length === 0) {
            return false;
        }

        // initialize the basic properties
        this.dropdownStyle = null;
        this.dropdownIcon = null;
        this.dropdownLabel = null;
        this.dropdownId = null;
        this.isPreview = false;
        this.createdButtons = false;
        this.buttonsPartiallyLoaded = false;

        this.clearButtons();
        this.createButtonsList(model);

        return true;
    },

    initializeWRecordButtonsData: function () {
        this.resetCachedVariables();

        // set the properties needed for rendering the field
        _.each(
            this.buttonsData.buttons,
            function updateButtons(buttonData, buttonId) {
                if (buttonData.dependencyField === true) {
                    this.verifyDependency(buttonData.dependencyData.formulaElement, buttonId);
                } else {
                    if (
                        !_.contains(this.buttonsToBeCreated, buttonId) &&
                        !this.isTabManagementButton(buttonData) &&
                        !this.isMobileButton(buttonData)
                    ) {
                        this.buttonsToBeCreated.push(buttonId);
                    }
                }
            }.bind(this)
        );
    },

    isMobileButton: function (buttonData) {
        var isMobileButton = false;

        _.each(
            buttonData.actions,
            function goThroughActions(actionData) {
                if (this.mobileOnlyActions.indexOf(actionData.action) > -1) {
                    isMobileButton = true;
                }
            },
            this
        );

        return isMobileButton && Object.keys(buttonData.actions).length <= 1;
    },

    isTabManagementButton: function (buttonData) {
        var isTabMngmtButton = false;

        _.each(buttonData.actions, function goThroughActions(actionData) {
            if (actionData.action === "tabsManagement") {
                isTabMngmtButton = true;
            }
        });

        return isTabMngmtButton && Object.keys(buttonData.actions).length <= 1;
    },

    getParentPanelName: function () {
        var parentPanelName = false;
        var self = this;

        _.each(this.view.meta.panels, function goThroughPanels(panelData) {
            _.each(panelData.fields, function goThroughField(fieldData) {
                if (fieldData.name === self.name) {
                    parentPanelName = panelData.name;
                }
            });
        });

        return parentPanelName;
    },

    getTabsVisibilityFormula: function () {
        var tabsVisibilityFormula = false;

        _.each(this.buttonsData.buttons, function goThroughButtons(buttonData) {
            _.each(buttonData.actions, function goThroughActions(actionData) {
                if (actionData.action === "tabsManagement") {
                    tabsVisibilityFormula = actionData.actionParameters.formulaElement;
                }
            });
        });

        return tabsVisibilityFormula;
    },

    controlTabsVisibility: function () {
        // check wether this is only a tabs/panels visibility control
        var tabsVisibilityFormula = this.getTabsVisibilityFormula();
        var parentPanelName = this.getParentPanelName();

        if (tabsVisibilityFormula && tabsVisibilityFormula !== "" && parentPanelName) {
            var expressionContext = new SUGAR.expressions.SidecarExpressionContext({
                model      : this.model,
                collection : this.view.collection,
                context    : this.view.context
            });

            tabsVisibilityFormula = this.replaceCharInFormula(tabsVisibilityFormula, "'", "\"");
            try {
                var expression = SUGAR.expressions.SidecarExpressionContext.parser.evaluate(
                    tabsVisibilityFormula,
                    expressionContext
                );
                var expressionValue = expression.evaluate();
                var panelElement = $("div[data-panelname=\"" + parentPanelName + "\"]");
                var isActiveTab = this.view.$el.find(".tab." + parentPanelName + ".active").length > 0;

                if (panelElement.length === 0) {
                    panelElement = $(".tab." + parentPanelName);
                }

                if (expressionValue === "true") {
                    panelElement.show();
                    panelElement.removeClass("tabBlocked");
                } else if (expressionValue === "false") {
                    panelElement.hide();
                    panelElement.addClass("tabBlocked");
                }

                if (isActiveTab && expressionValue === "false") {
                    var allTabs = this.view.$el.find(".tab");
                    var hasActiveTab = false;

                    for (var i = 0; i < allTabs.length; i++) {
                        var panelId =
                        "#" + allTabs[i].children[0].href.substr(allTabs[i].children[0].href.indexOf("#") + 1);

                        if (allTabs[i].classList.contains("tabBlocked")) {
                            $(panelId).removeClass("active");
                            $(panelId).addClass("fade");
                        } else if (!hasActiveTab && !allTabs[i].classList.contains("tabBlocked")) {
                            hasActiveTab = true;
                            this.view.$el
                                .find("." + allTabs[i].classList[0] + "." + allTabs[i].classList[1])
                                .addClass("active");
                            $(panelId).removeClass("fade");
                            $(panelId).addClass("active");
                        }
                    }
                    panelElement.removeClass("active");
                }

                $(".tab.dropdown.more").hide();
            } catch (e) {
                app.alert.show("wrb-tab-visibility-formula", {
                    level     : "warning",
                    messages  : "wRecordButtons Tab Visibility formula is incorrect.",
                    autoClose : true
                });
            }
        }
    },

    createButtonsList: function (model) {
        var tplName = this.view.tplName.toLowerCase();

        this.controlTabsVisibility();

        // we force dropdowns on the dashlet
        if (tplName === "dashablelist" || tplName.indexOf("dashlet") > -1) {
            // set the container type as btn-group
            this.containerType = "btn-group";
            this.isDropdown = true;
            this.isDashlet = true;
        }

        this.initializeWRecordButtonsData();
        if (["list", "flex-list"].indexOf(tplName) > -1 && !model && Object.keys(this.updateFieldParams).length > 0) {
            return true;
        }

        if (this.tplName !== "nodata" && Object.keys(this.updateFieldParams).length > 0) {
            this.executeDependencyCheck();
        } else {
            this.createWRecordButtons();
        }

        return true;
    },

    createWireframeLoading: function () {
        this.$el.append("\
<style class='wRBLoaderStyle'>\
    .wRBLoader {\
    animation: blinker 1.3s linear infinite;\
    }\
\
    @keyframes blinker {  \
    50% { opacity: 0.4; }\
    }\
</style>\
        ");

        if (this.buttonsData.buttonsSettings.buttonType === "dropDown") {
            this.$el.append(
                "\
                <div class='btn-group'>\
                    <a class='btn wRBLoader' data-toggle='dropdown' style='width: 64px;z-index: inherit;height: 16px;\background-color: #ddd;color: #ddd;border-color: #c2c2c2;background-image: none;'></a>\
                    <a class='btn wRBLoader' data-toggle='dropdown' style='width: 16px;z-index: inherit;height: 16px;\background-color: #ddd;color: #ddd;border-color: #c2c2c2;background-image: none;'>\
                        <i class='fa fa-caret-down wRBLoader' style='color:#c2c2c2;'></i>\
                    </a>\
                </div>\
                "
            );
        } else {
            var maxWireframebuttons = 3;
            var completeNumberOfButtons = Object.keys(this.buttonsData.buttons).length;
            var validButtonsNumber = completeNumberOfButtons > maxWireframebuttons ? maxWireframebuttons : completeNumberOfButtons;

            for (let index = 0; index < validButtonsNumber; index++) {
                this.$el.append(
                    "\
                        <a class='btn wRBLoader' data-toggle='dropdown' style='width: 64px;z-index: inherit;height: 16px;background-color: #ddd;color: #ddd;border-color: #ddd;background-image: none;'></a>\
                    "
                );
            }
        }
    },

    removeWireframeLoading: function () {
        this.$el.find(".wRBLoader").remove();
        this.$el.find(".wRBLoaderStyle").remove();
    },

    executeDependencyCheck: function () {
        var self = this;

        // checking buttons dependency
        var updateField = {
            success: function (expressionValues) {
                // create the buttons that passed the dependency test
                self.createDependentButtons(expressionValues);
            }
        };

        var id = this.model ? this.model.get("id") : "";
        var reqParamsObject = {
            fieldsToBeUpdated : this.updateFieldParams,
            recordType        : this.module,
            recordId          : id,
            dependency        : true
        };

        app.api.call(
            "create",
            app.api.buildURL("EvaluateExpression/calculate_dependency"),
            reqParamsObject,
            null,
            updateField
        );
    },

    createDependentButtons: function (expressionValues) {
        var self = this;

        _.each(expressionValues, function tryStoreButtonData(data, id) {
            if (data.value === "true") {
                if (!_.contains(self.buttonsToBeCreated, data.buttonId) && !self.isMobileButton(data)) {
                    self.buttonsToBeCreated.push(data.buttonId);
                }
            }
        });

        self.createWRecordButtons();
    },

    replaceCharInFormula: function (brokenFormula, charToReplace, newChar) {
        var formulaBody = brokenFormula;
        var regex = new RegExp("\\" + charToReplace);

        while (formulaBody.match(regex)) {
            formulaBody = formulaBody.replace(regex, newChar);
        }

        return formulaBody;
    },

    createWRecordButtons: function () {
        if (this.$el) {
            this.removeWireframeLoading();

            var buttonsSettings = this.buttonsData.buttonsSettings;
            this.isDropdown = buttonsSettings.buttonType === "dropDown";
            this.iconOnLeft = buttonsSettings.iconPlacement === "left";
            this.containerType = buttonsSettings.buttonType === "buttons" ? "btn-list" : "btn-group";
            this.iconStyle = buttonsSettings.buttonSize === "btn-large" ? "font-size:large" : "";
            this.dropdownIcon = buttonsSettings.showDropdownIcon === true ? "fa fa-cogs" : "";
            this.dropdownSize = buttonsSettings.buttonSize;

            //check if the buttons are shown in the header, if so we have to make it a dropdown if we got more than 5 buttons
            if (this.def.isHeaderButton) {
                var maxButtonsAllowedInHeader = 5;

                var buttonsNumber = this.buttonsToBeCreated.length;
                var wRecordButtonsFieldsInHeader = _.filter(
                    this.view.options.meta[this.buttonsTableKey],
                    function getwRecordButtonField(fieldData) {
                        return fieldData.type === "buttonset";
                    }
                ).length;

                if (
                    buttonsNumber > maxButtonsAllowedInHeader ||
                    wRecordButtonsFieldsInHeader > maxButtonsAllowedInHeader
                ) {
                    buttonsSettings.buttonType = "dropDown";
                } else {
                    buttonsSettings.buttonType = this.def.originalType;
                }

                this.containerType = buttonsSettings.buttonType === "buttons" ? "btn-list" : "btn-group";
                this.isDropdown = buttonsSettings.buttonType === "dropDown";

                if (buttonsSettings.buttonType === "dropDown") {
                    buttonsNumber = 1;
                }

                this.view.wRecordButtonsData[this.buttonId] = {
                    buttons       : this.buttonsToBeCreated,
                    buttonsNumber : buttonsNumber,
                    buttonName    : this.label,
                    widget        : this
                };

                if (Object.keys(this.view.wRecordButtonsData).length === wRecordButtonsFieldsInHeader) {
                    if (this.view.createWRecordHeaderButtons) {
                        this.view.createWRecordHeaderButtons();
                    }
                }
            } else {
                this.createButtonsWidget();
            }
        }
        this.view.trigger("urecord-buttons-created");
    },

    createButtonsWidget: function (buttonsNumber, buttonsToBeCreated, combinedButtons) {
        var tplName = this.view.tplName.toLowerCase();
        // we force dropdowns on the dashlet
        if (tplName === "dashablelist" || tplName.indexOf("dashlet") > -1) {
            // set the container type as btn-group
            this.containerType = "btn-group";
            this.isDropdown = true;
            this.isDashlet = true;
        }

        this.buttons = [];
        this.maxDropdownSize = false;
        var maxButtonSize = false;
        buttonsToBeCreated = buttonsToBeCreated ? _.clone(buttonsToBeCreated) : _.clone(this.buttonsToBeCreated);

        if (this.def.isHeaderButton) {
            if (!this.view.wRecordButtonsSpace) {
                if (this.view.tplName === "record") {
                    var takeParentElement = $(".headerpane").children()[0];
                    if (takeParentElement) {
                        var takeTotalWidthHeaderPane = $(".record")[0].offsetWidth;

                        takeParentElement.setAttribute("id", "childrenArray");

                        var takeChildrenArray = $("#childrenArray").children();

                        var totalWidthFromChildrenArray = 0;
                        //eslint-disable-next-line
                        for (var childIndex = 0; childIndex < takeChildrenArray.length - 1; childIndex++) {
                            //eslint-disable-next-line
                            if (
                                !_.contains(
                                    $(".headerpane h1> .record-cell:last-of-type"),
                                    takeChildrenArray[childIndex]
                                )
                            ) {
                                totalWidthFromChildrenArray +=
                                    takeChildrenArray[childIndex].offsetWidth + this.marginBetweenHeaderElements;
                            } else if (takeChildrenArray[childIndex].attributes["data-type"].nodeValue === "follow") {
                                totalWidthFromChildrenArray +=
                                    this.marginBetweenHeaderElements + this.marginBetweenHeaderElements;
                            } else {
                                totalWidthFromChildrenArray += this.freeSpaceTreshold;
                            }
                        }

                        var lastChildElementFromFirstChildrens = takeChildrenArray.last();

                        var lastChildArray = lastChildElementFromFirstChildrens[0].children;

                        var rightSideElementsWidth = 0;
                        var elementsCalculatedCardinal = 2;
                        //eslint-disable-next-line
                        for (
                            var lastChildIndex = lastChildArray.length - elementsCalculatedCardinal; lastChildIndex < lastChildArray.length; lastChildIndex++
                        ) {
                            rightSideElementsWidth =
                                rightSideElementsWidth + lastChildArray[lastChildIndex].offsetWidth;
                        }

                        var takeChildrensSum = totalWidthFromChildrenArray + rightSideElementsWidth;

                        this.view.wRecordButtonsSpace = takeTotalWidthHeaderPane - takeChildrensSum;
                    }
                }
            }

            var wRecordButtonsFieldsInHeader = _.filter(
                this.view.options.meta[this.buttonsTableKey],
                function getwRecordButtonField(fieldData) {
                    return fieldData.type === "buttonset";
                }
            ).length;

            var maxFreeSpace = this.view.wRecordButtonsSpace;

            if (this.def.isPreviewButton) {
                var screenRatio = 0.15;
                maxFreeSpace = window.innerWidth * screenRatio / wRecordButtonsFieldsInHeader;
            }

            buttonsNumber = buttonsNumber ? buttonsNumber : buttonsToBeCreated.length;
            if (!combinedButtons) {
                var maxButtonNumber = 4;
                var maxNumberForDropdownSizeOffset = 0.7;
                var minNumberForDropdownSizeOffset = 0.1;

                var dropdownSizeOffset =
                    buttonsNumber <= maxButtonNumber ? maxNumberForDropdownSizeOffset : minNumberForDropdownSizeOffset;

                this.maxDropdownSize = maxFreeSpace * dropdownSizeOffset;
            }

            maxButtonSize = maxFreeSpace / buttonsNumber;
        }

        if (!combinedButtons) {
            for (var index = 0; index < buttonsToBeCreated.length; index++) {
                var currentButtonId = buttonsToBeCreated[index];

                if (this.buttonsData.buttons[currentButtonId]) {
                    buttonsToBeCreated[index] = {
                        buttonId    : currentButtonId,
                        buttonOrder : this.buttonsData.buttons[currentButtonId].orderNumber
                    };
                }
            }

            // order the buttons
            buttonsToBeCreated.sort(function sortButtons(firstButton, secondButton) {
                return firstButton.buttonOrder - secondButton.buttonOrder;
            });
        }

        // set the properties needed for rendering the field
        for (var i = 0; i < buttonsToBeCreated.length; i++) {
            if (this.isDropdown) {
                this.createDropdownOption(buttonsToBeCreated[i].buttonId || buttonsToBeCreated[i], maxButtonSize);
            } else {
                this.createButton(buttonsToBeCreated[i].buttonId || buttonsToBeCreated[i], maxButtonSize);
            }
        }

        this.showButtonsWidget();
        this.removeEmptyView();
        this.buttonsPartiallyLoaded = true;
        this._render();
        this.handleSubgroupVisibility();
    },

    clearButtons: function () {
        this.buttons = [];
        this.buttonsToBeCreated = [];
    },

    removeEmptyView: function () {
        if (this.createdButtons && this.$el) {
            if (this.view.tplName === "record" && !this.def.isHeaderButton) {
                this.$el
                    .parent()
                    .parent()
                    .parent()
                    .show();
            }
        } else if (!this.createdButtons && this.$el) {
            if (this.view.tplName == "list" || this.isDashlet) {
                this.$el.empty();
            } else if (this.view.tplName === "flex-list") {
                this.$el.empty();
                this.$el.html("<div>Buttons Not Active</div>");
            } else if (!this.def.isHeaderButton) {
                this.$el.empty();
                this.$el
                    .parent()
                    .parent()
                    .parent()
                    .hide();
            } else if (this.def.isHeaderButton) {
                this.$el.empty();
            }
        }
    },

    showButtonsWidget: function () {
        if (this.createdButtons && this.$el) {
            if (this.view.tplName == "list" || this.isDashlet) {
                this.$el.parent().show();
            } else if (!this.def.isHeaderButton) {
                this.$el
                    .parent()
                    .parent()
                    .show();

                if (this.buttonsData.buttonsSettings.showLabelName !== true) {
                    // hide the title
                    this.$el
                        .parent()
                        .parent()
                        .find(".record-label")
                        .hide();
                }
            }
        }
    },

    verifyDependency: function (dependencyFormula, id) {
        var uniqueIdentifier = App.utils.generateUUID();
        dependencyFormula = dependencyFormula.replace(/'/g, "\"");
        var params = {
            formula     : dependencyFormula,
            model       : JSON.stringify(this.model),
            targetField : this.name,
            buttonId    : id
        };

        this.updateFieldParams[uniqueIdentifier] = params;
    },

    createDropdownOption: function (buttonId, maxButtonSize) {
        var buttonData = this.buttonsData.buttons[buttonId];
        var buttonIcon = buttonData.showIcon === true ? "fa " + buttonData.icon : "";
        var buttonLabel = buttonData.showLabel === true ? buttonData.label : "";
        maxButtonSize = maxButtonSize ? maxButtonSize : window.innerWidth;

        this.buttons.push({
            buttonId           : buttonData.index,
            buttonStyle        : buttonData.buttonStyle,
            icon               : buttonIcon,
            iconColor          : buttonData.iconColor,
            marginTop          : this.def.isHeaderButton === true ? "0" : "5",
            label              : buttonLabel,
            generalDescription : buttonData.generalDescription,
            isDropdownHeader   : buttonData.isDropdownHeader,
            maxButtonSize      : maxButtonSize,
            dependent          : buttonData.dependencyField,
            groupId            : buttonData.groupId
        });

        this.createdButtons = true;
        this.dropdownPopulated = true;
    },

    createButton: function (buttonId, maxButtonSize) {
        var buttonData = this.buttonsData.buttons[buttonId];
        var buttonIcon = buttonData.showIcon === true ? "fa " + buttonData.icon : "";
        var isLarge = this.buttonsData.buttonsSettings.buttonSize === "btn-large";
        var iconSize = isLarge === true ? "font-size:large" : "";
        var labelSpacing = isLarge === true ? "  " : "";
        var buttonLabel = buttonData.showLabel === true ? buttonData.label : "";
        maxButtonSize = maxButtonSize ? maxButtonSize : window.innerWidth;

        if (isLarge === true && buttonData.showLabel === true && buttonData.showIcon === true) {
            buttonLabel = this.iconOnLeft === true ? labelSpacing + buttonLabel : buttonLabel + labelSpacing;
        }

        this.createdButtons = true;
        this.buttons.push({
            buttonId           : buttonData.index,
            index              : buttonData.orderNumber,
            icon               : buttonIcon,
            label              : buttonLabel,
            iconStyle          : iconSize,
            iconColor          : buttonData.iconColor,
            style              : buttonData.buttonStyle,
            generalDescription : buttonData.generalDescription,
            marginTop          : this.def.isHeaderButton === true ? "0" : "5",
            size               : this.buttonsData.buttonsSettings.buttonSize,
            dependent          : buttonData.dependencyField,
            maxButtonSize      : maxButtonSize
        });
    },

    buttonClicked: function (e) {
        var buttonData = this.buttonsData.buttons[e.currentTarget.id];

        if (this.masterWidgetData && !buttonData) {
            buttonData = this.masterWidgetData[e.currentTarget.id];
        }

        // if the button clicked is a wRecordButton and has valid data we check its actions
        if (buttonData) {
            this.resetCachedVariables();
            this.actionsQueue = {
                actions           : _.clone(buttonData.actions),
                currentButtonData : _.clone(buttonData)
            };
            this.executeNextAction();

            if (this.isDropdown) {
                this.closeDropdowns();
            }
        } else {
            if (this.isDropdown) {
                this.detachDropdown();
            }

            if (e.currentTarget.dataset.subgroupid) {
                this.handleSubgroup(e.currentTarget.dataset.subgroupid, e);
                e.stopImmediatePropagation();
            }
        }
    },

    callExecuteFunction: function (executeViewName, args) {
        if (app.view.views[executeViewName] && app.view.views[executeViewName].prototype.execute) {
            app.view.views[executeViewName].prototype.execute.apply(this, args);
            this.tryExecuteImmediateAction();
        }
    },

    tryExecuteImmediateAction: function () {
        var nextActionId = Object.keys(this.actionsQueue.actions)[0];
        if (nextActionId && this.actionsQueue.actions[nextActionId]) {
            if (
                this.actionsQueue.actions[nextActionId].action !== "createRecord" &&
                this.actionsQueue.actions[nextActionId].executeImmediately === true
            ) {
                this.goToNextAction();
            }
        }
    },

    goToNextAction: function () {
        var timeoutTreshold = 500;
        setTimeout(
            function executeAfterTimeout() {
                this.executeNextAction();
            }.bind(this),
            timeoutTreshold
        );
    },

    executeNextAction: function () {
        app.controller.context.uRecordButtonModel = this.model;
        var timeoutTreshold = 500;

        setTimeout(
            function handleNextAction() {
                var buttonData = this.actionsQueue.currentButtonData;
                var buttonId = buttonData.index;
                var nextActionId = Object.keys(this.actionsQueue.actions)[0];

                if (nextActionId) {
                    var actionData = this.actionsQueue.actions[nextActionId];

                    delete this.actionsQueue.actions[nextActionId];
                    switch (actionData.action) {
                        case "mergeDocument":
                            if (app.acl.hasAccess("edit", "Documents")) {
                                this.mergeDocument(actionData);
                            } else {
                                this.showNoAccessAlert();
                            }
                            break;
                        case "runUrl":
                            this.runUrl(actionData);
                            break;
                        case "updateField":
                            this.updateField(actionData, buttonId, nextActionId);
                            break;
                        case "runJob":
                            this.runJob(actionData);
                            break;
                        case "convertLead":
                            if (app.acl.hasAccess("edit", "Leads") && app.acl.hasAccess("edit", "Contacts")) {
                                this.convertLead(actionData);
                            }
                            break;
                        case "composeMail":
                            this.composeMail(actionData);
                            break;
                        default:
                            if (!actionData.actionParameters.executeView) {
                                actionData.actionParameters.executeView = this.bwcMapping[actionData.action];
                            }
                            if (actionData.actionParameters.executeView) {
                                var executeViewName = this.getExecuteViewName(actionData);
                                this.callExecuteFunction(executeViewName, [actionData]);
                            } else {
                                this.executeNextAction();
                            }
                            break;
                    }
                } else if (this.mustSaveModel) {
                    this.mustSaveModel = false;
                    this.trySaveModel();
                }
            }.bind(this),
            timeoutTreshold
        );
    },

    refreshSubpanels: function (linkedRecordId, mustLinkRecord) {
        var delayNextAction = false;

        if (!this.model) {
            this.model = this.options.model;
        }
        var self = this;
        var relation = "";

        if (typeof linkedRecordId !== "string" && mustLinkRecord) {
            mustLinkRecord = mustLinkRecord.get("mustLinkRecord");
        }

        // if the record is a document we must link it manualy
        if (mustLinkRecord) {
            if (typeof linkedRecordId === "string") {
                var linkName = "";
                var reqUrl = app.api.buildURL() + "/" + this.model.module + "/" + this.model.get("id") + "/link";
                //eslint-disable-next-line camelcase

                relation = _.filter(this.model.fields, function getLinks(val) {
                    return val.type == "link" && val.module === "Documents";
                });

                if (this.model.module == "Contracts") {
                    linkName = "contracts_documents";
                } else {
                    linkName = relation[relation.length - 1] ? relation[relation.length - 1].name : "documents";
                }

                //eslint-disable-next-line camelcase
                var linkData = {
                    //eslint-disable-next-line camelcase
                    link_name : linkName,
                    ids       : [linkedRecordId]
                };

                var documentCreated = {
                    success: function () {
                        var subpanelCollection = self.model.getRelatedCollection(linkName);
                        subpanelCollection.fetch({
                            relate: true
                        });
                    }
                };

                App.api.call("create", reqUrl, linkData, null, documentCreated);
                linkedRecordId = {
                    attributes: {
                        module: "Documents"
                    }
                };
            } else {
                relation = _.filter(this.model.fields, function getLinks(val) {
                    return val.type == "link" 
                    && ((translate(val.vname, linkedRecordId.get("model").module)) === linkedRecordId.get("model").module
                    || val.module === linkedRecordId.get("model").module
                    || translate(val.vname) === linkedRecordId.get("model").module);
                });

                _.each(relation, function refresh(relationData) {
                  
                    var linkName = relationData ?
                    //  relation[relation.length - 1].name :
                        relationData.name :
                        linkedRecordId.get("model").module.toLocaleLowerCase();

                    var subpanelCollection = this.model.getRelatedCollection(linkName);
                    subpanelCollection.fetch({
                        relate: true
                    });
                }.bind(this));

            }
        }

        var changedAttributes = _.clone(this.model.changedAttributes());
        var modelID = this.model.get("id");

        if (this.view.type == "recordlist") {
            delayNextAction = true;
            this.view.context.attributes.collection.fetch({
                success: function returnFetchedCollection(fetchedCollection) {
                    if (!this.model) {
                        this.model = this.options.model;
                    }
                    modelID = this.model.get("id");
                    var newFetchedModel = _.find(fetchedCollection.models, function getCurrentModel(modelData) {
                        return modelData.get("id") == modelID;
                    });

                    if (changedAttributes) {
                        newFetchedModel.set(changedAttributes);
                        newFetchedModel.save(newFetchedModel.attributes, {
                            silent  : true,
                            success : function reqSuccess() {
                                this.executeNextAction();
                            }.bind(this),
                            error: function reqFail() {
                                this.executeNextAction();
                            }.bind(this)
                        });
                    }
                }.bind(this),
                error: function reqFail() {
                    this.executeNextAction();
                }.bind(this)
            });
        } else if (this.view.type == "preview" || this.view.type == "preview-header") {
            this.view.context.attributes.collection.fetch({
                success: function (fetchedCollection) {
                    var newFetchedModel = _.find(fetchedCollection.models, function getCurrentModel(modelData) {
                        return modelData.get("id") == modelID;
                    });

                    if (changedAttributes) {
                        newFetchedModel.set(changedAttributes);
                        newFetchedModel.save({
                            silent: true
                        });
                    }
                }
            });
        }

        if (!delayNextAction) {
            this.executeNextAction();
        }
    },

    getExecuteViewName: function (actionData) {
        var executeViewName = actionData.actionParameters.executeView;
        executeViewName = this.charReplaceAt(executeViewName, 0, executeViewName[0].toUpperCase());

        while (executeViewName.indexOf("-") > -1) {
            var delimiterIndex = executeViewName.indexOf("-");

            executeViewName = this.charReplaceAt(
                executeViewName,
                delimiterIndex + 1,
                executeViewName[delimiterIndex + 1].toUpperCase()
            );
            executeViewName = this.charReplaceAt(executeViewName, delimiterIndex, "", true);
        }

        executeViewName = "BaseCustom" + executeViewName + "View";

        return executeViewName;
    },

    charReplaceAt: function (string, index, replacement, replaceWithBlanc) {
        var lengthModifier = 0;

        if (replaceWithBlanc) {
            lengthModifier = 1;
        }

        return string.substr(0, index) + replacement + string.substr(index + replacement.length + lengthModifier);
    },

    handleSubgroup: function (groupId, event) {
        if (event.currentTarget.dataset.groupClosed) {
            delete event.currentTarget.dataset.groupClosed;
            $("[data-groupId=\"" + groupId + "\"]").show();
        } else {
            event.currentTarget.dataset.groupClosed = true;
            $("[data-groupId=\"" + groupId + "\"]").hide();
        }
    },

    handleSubgroupVisibility: function () {
        var self = this;
        _.each(this.buttons, function handleVisibility(buttonData) {
            if (buttonData.isDropdownHeader) {
                var subgroupButtons = _.filter(self.buttons, function getSubgroupButtons(groupButtonData) {
                    return groupButtonData.groupId === buttonData.groupId;
                });

                if (subgroupButtons.length <= 1) {
                    $("[data-subgroupid=\"" + buttonData.groupId + "\"]").hide();
                }
            }
        });
    },

    resetCachedVariables: function () {
        // reset all cached parameters
        this.updateFieldParams = {};
    },

    openComposeEmailDrawer: function (actionData) {
        if (this.parseVersion(App.metadata.getServerInfo().version) > this.parseVersion("7.9")) {
            if (this.model === null) {
                this.model = this.view.model;
            }

            var requestParams = {
                templateId   : actionData.actionParameters.emailTemplate,
                recordType   : this.model.module,
                recordId     : this.model.id,
                fieldName    : this.name,
                emailToData  : actionData.actionParameters.emailToData,
                emailToField : actionData.actionParameters.emailToField,
            };

            if (actionData.actionParameters.usePMSETemplates) {
                requestParams = {
                    targetModule     : this.model.module,
                    targetRecordId   : this.model.id,
                    targetTemplateId : actionData.actionParameters.emailTemplate,
                    fieldName        : this.name,
                    emailToData      : actionData.actionParameters.emailToData,
                    emailToField     : actionData.actionParameters.emailToField,
                };
            }
           
            var successCallback = {
                success: function loadEmailDrawer(result) {
                
                    if (this.model === null) {
                        this.model = this.view.model;
                    }

                    if (App.user.get("preferences").email_client_preference.type === "sugar") {
                        var emailModel = App.data.createBean("Emails");
                        emailModel.attributes.related = this.model;

                        // check if the record is linked so we know if we create a linked record or not
                        if (actionData.actionParameters.linkRecord === true) {
                            emailModel.set("parent", this.model);
                            emailModel.set("parent_id", this.model.get("id"));
                            emailModel.set("parent_type", this.model.module);
                            emailModel.set("parent_name", this.model.get("name"));        
                            emailModel.set("mustLinkRecord", true);    
                        }
            
                        if (actionData.actionParameters.emailTemplate !== ""){
                            emailModel.attributes.emailTemplateId = actionData.actionParameters.emailTemplate;
                        }
                        emailModel.attributes.name = result.subject;
                        emailModel.attributes.description = result.description;
                        //eslint-disable-next-line camelcase
                        emailModel.attributes.description_html = result.body;

                        if (result.emailTo !== false){                
                            var emailAddresses = result.emailTo;
                            var emailToCollection = app.data.createMixedBeanCollection();
                            var linkedCollection = app.data.createBeanCollection();

                            _.each(emailAddresses, function getEmailData(emailData){
                                var emailParticipantData = {
                                    _link            : "to",
                                    //eslint-disable-next-line
                                email_address:    emailData.email_address,
                                    //eslint-disable-next-line
                                email_address_id: emailData.email_address_id,
                                    //eslint-disable-next-line
                                invalid_email    : false,
                                    deleted          : false,
                                };

                                var emailParticipant = App.data.createBean("EmailParticipants", emailParticipantData);

                                emailToCollection.add(emailParticipant);

                                if (!linkedCollection._create) {
                                    linkedCollection._create = [];
                                }
                                linkedCollection._create.push(emailParticipant);
                            });

                            linkedCollection.link = {
                                name : "to",
                                bean : emailModel
                            };

                            emailToCollection._linkedCollections = {
                                "to": linkedCollection
                            };

                            emailModel.set("to_collection", emailToCollection);
                        }

                        var context = new App.Context({
                            create : true,
                            module : "Emails",
                            model  : emailModel
                        });

                        App.drawer.open({ 
                            layout  : "compose-email",
                            context : context
                        },
                        this.refreshSubpanels.bind(this)
                        );
                    } else {
                        var emailBody = result.body.replace(/\n/g, "\r\n")
                            .replace(/<p>/g, "\r\n")
                            .replace(/(<([^>]+)>)/ig, "");

                        var emailToAddresses = _.chain(this.model.attributes.email)
                            .pluck("email_address")
                            .value()
                            .join(";");

                        this.executeNextAction();

                        window.location.href = "mailto:" + emailToAddresses +
                            "?subject=" + encodeURIComponent(result.subject) +
                            "&body=" + encodeURIComponent(emailBody);
                    }
                }.bind(this)
            };

            var apiPath = actionData.actionParameters.usePMSETemplates ? "EnhancedEmailTemplates" : "GetEmailTemplateProcessedData/getEmailTemplateProcessedData";

            var apiUrl = app.api.buildURL(apiPath, "create", requestParams, {});

            app.api.call("create", apiUrl, requestParams, null, successCallback);
        } else {
            var options = {
                related         : this.model,
                emailTemplateId : actionData.actionParameters.emailTemplate
            };

            var emailAddresses = this.model.get("email");

            // inserting the main email address
            if (emailAddresses && emailAddresses[0]) {
                //eslint-disable-next-line camelcase
                options.to_addresses = [];
                options.to_addresses.push({
                    bean  : this.model,
                    email : emailAddresses[0].email_address
                });
            }

            // opening the compose email drawer
            app.drawer.open({
                layout  : "compose",
                context : {
                    create      : "true",
                    module      : "Emails",
                    prepopulate : options
                }
            },
            this.refreshSubpanels.bind(this)
            );
        }
    },

    /**
     * calculate SugarVersion Score
     */
    parseVersion: function (version, versionSeparator) {
        var versionScoreMultiplierData = {
            major    : 1000000,
            minor    : 10000,
            subminor : 100,
            patch    : 1
        };
        var versionScore = 0;
        var defaultVersion = 0;

        version = version ? version : "";
        versionSeparator = versionSeparator ? versionSeparator : ".";

        version = version.slice(0, version.indexOf("-") > -1 ? version.indexOf("-") : version.length);

        _.each(versionScoreMultiplierData, function getVersionData(versioningScore) {
            var indexOfVersionSeparator =
                version.indexOf(versionSeparator) > -1 ? version.indexOf(versionSeparator) : version.length;

            var versionNumber = version.slice(0, indexOfVersionSeparator) ?
                version.slice(0, indexOfVersionSeparator) :
                version;

            if (versionNumber === "") {
                versionNumber = defaultVersion;
            }

            version = version.slice(indexOfVersionSeparator + 1, version.length);

            versionScore = versionScore + parseInt(versionNumber) * versioningScore;
        });

        if (isNaN(versionScore) === true) {
            versionScore = 0;
        }

        return versionScore;
    },

    composeMail: function (actionData) {
        var self = this;
        if (this.view.tplName === "record") {
            this.openComposeEmailDrawer(actionData);
        } else {
            var beforeFetchAttributes = _.clone(this.model.attributes);
            this.model.fetch({
                success: function openCustomDrawer(model) {
                    model.set(beforeFetchAttributes);
                    self.openComposeEmailDrawer(actionData);
                }
            });
        }
    },

    updateFieldAction: function (actionData) {
        var self = this;

        var notifyRelatedModuleUpdated = {
            success: function (updated) {
                self.executeNextAction();
                if (updated) {
                    // show related module updated alert
                    app.alert.show("related-record-to-be-updated", {
                        level     : "success",
                        messages  : "Save successful on Related Record.",
                        autoClose : true
                    });
                } else {
                    // show related module updated alert
                    app.alert.show("nothing-to-be-updated", {
                        level     : "warning",
                        messages  : "Nothing to be updated on the Related Record. ",
                        autoClose : true
                    });
                }
            }
        };

        var currentModelNeedsSaving = false;
        var requestParameters = {};

        // check wether we need an api call to get the new value or we can calculate it here
        _.each(
            this.updateFieldParams,
            function goThroughParams(fieldParams, uniqueIdentifier) {
                if (fieldParams.fieldToBeUpdated != null) {
                    var fieldName = fieldParams.fieldToBeUpdated;
                    if (
                        this.model &&
                        this.model.fields &&
                        this.model.fields[fieldName] &&
                        this.model.fields[fieldName].id_name
                    ) {
                        fieldName = this.model.fields[fieldName].id_name;
                    }

                    fieldParams.calculated = fieldParams.calculated === true ? true : false;
                    // in case we have request params then we need to store the params in order to make an api call
                    if (
                        fieldParams.requestParams &&
                        fieldParams.calculated === true &&
                        fieldParams.moduleType === "1currentModule"
                    ) {
                        requestParameters[uniqueIdentifier] = fieldParams.requestParams;
                    } else {
                        fieldParams.formulaElement = fieldParams.formulaElement.replace(/"/g, "");
                        var relatedModuleType = this.module;
                        var paramToGet = "id";

                        var relatedRecordId = this.model.get(paramToGet);

                        var fieldValue =
                            fieldParams.calculated === true ? fieldParams.formulaElement : fieldParams.defaultValue;

                        if (fieldParams.moduleType !== "1currentModule") {
                            relatedModuleType = fieldParams.moduleType.substr(0, fieldParams.moduleType.indexOf("__"));
                            var stringIndexOffset = 2;
                            paramToGet = fieldParams.moduleType.substr(
                                fieldParams.moduleType.indexOf("__") + stringIndexOffset,
                                fieldParams.moduleType.length
                            );

                            if (this.model.fields[paramToGet] && this.model.fields[paramToGet].type === "relate") {
                                paramToGet = this.model.fields[paramToGet].id_name;
                            }

                            var stringIdIndexOffset = 3;
                            var getParamId = paramToGet.substring(0, paramToGet.length - stringIdIndexOffset);

                            if (this.model.get(paramToGet) == undefined && this.view.model && this.view.model.id) {
                                relatedRecordId = this.view.model.get(getParamId).id;
                            } else if (this.model.get(paramToGet) == undefined && this.view.model) {
                                relatedRecordId = this.model.get(getParamId).id;
                            } else {
                                relatedRecordId = this.model.get(paramToGet);
                            }
                        } else if (fieldParams.calculated === false) {
                            if (typeof fieldValue === "object") {
                                // eslint-disable-next-line max-depth
                                if (this.model.fields[fieldName].type === "currency") {
                                    fieldValue[fieldName] = App.utils.unformatNumberString(
                                        fieldValue[fieldName],
                                        App.user.getPreference("number_grouping_separator"),
                                        App.user.getPreference("decimal_separator"),
                                        true
                                    );
                                }
                                this.model.set(fieldValue);
                            } else {
                                // eslint-disable-next-line max-depth
                                if (this.model.fields[fieldName] && this.model.fields[fieldName].type === "relate") {
                                    fieldName = this.model.fields[fieldName].id_name;
                                }

                                // fixed team_id bug
                                // eslint-disable-next-line max-depth
                                if (fieldName === "team_id") {
                                    fieldName = "team_name";
                                    fieldValue = [{
                                        id       : fieldValue,
                                        name     : fieldParams.fieldValueText,
                                        primary  : true,
                                        selected : false
                                    }];
                                }
                                if (fieldName === "deleted" && fieldValue == true) {
                                    this.destroyModel = true;
                                } else {
                                    this.model.set(fieldName, fieldValue);
                                }
                            }
                            currentModelNeedsSaving = true;
                        }

                        var apiParams = {
                            module   : relatedModuleType,
                            recordId : relatedRecordId,
                            field    : fieldName,
                            value    : fieldValue
                        };

                        if (fieldParams.calculated === true) {
                            // if we have custom fields in the formula we need to make the api call
                            if (fieldParams.formulaElement.indexOf("$") >= -1) {
                                if (fieldParams.moduleType === "1currentModule") {
                                    requestParameters[uniqueIdentifier] = {
                                        formula     : fieldParams.formulaElement,
                                        targetField : fieldName,
                                        recordId    : relatedRecordId,
                                        moduleType  : relatedModuleType
                                    };
                                } else {
                                    fieldValue = this.model.get(fieldName);
                                    apiParams.value = fieldValue;
                                    apiParams.formula = fieldParams.formulaElement;

                                    app.api.call(
                                        "create",
                                        app.api.buildURL("UpdateRelatedField"),
                                        apiParams,
                                        null,
                                        notifyRelatedModuleUpdated
                                    );
                                }
                            } else if (fieldParams.moduleType !== "1currentModule") {
                                app.api.call(
                                    "create",
                                    app.api.buildURL("UpdateRelatedField"),
                                    apiParams,
                                    null,
                                    notifyRelatedModuleUpdated
                                );
                            }
                        } else if (fieldParams.moduleType !== "1currentModule") {
                            if (fieldParams.calculated !== true) {
                                // getting fieldMetadata
                                var fieldsMetadata = app.metadata.getModule(apiParams.module).fields;
                                // handle fields that required expressionValue formatting
                                var targetFieldData = fieldsMetadata[apiParams.field];

                                if (targetFieldData && targetFieldData.type === "datetimecombo") {
                                    // handle datetime field
                                    apiParams.value = App.date(apiParams.value).formatUser();
                                }
                            }

                            app.api.call(
                                "create",
                                app.api.buildURL("UpdateRelatedField"),
                                apiParams,
                                null,
                                notifyRelatedModuleUpdated
                            );
                        }
                    }
                }
            }.bind(this)
        );
        // build the request params
        if (Object.keys(requestParameters).length > 0) {
            var evaluateExpressionsParams = {
                fieldsToBeUpdated : {},
                recordType        : this.model.module,
                recordId          : this.model.get("id")
            };

            _.each(requestParameters, function buildFieldsToBeUpdate(toBeUpdatedFieldData, toBeUpdatedActionId) {
                evaluateExpressionsParams.fieldsToBeUpdated[toBeUpdatedFieldData.targetField] = {
                    targetField : toBeUpdatedFieldData.targetField,
                    formula     : toBeUpdatedFieldData.formula
                };
            });

            App.api.call(
                "create",
                app.api.buildURL("EvaluateExpression/evaluate_expression"),
                evaluateExpressionsParams,
                null, {
                    success: function (expressionData) {
                        _.each(expressionData, function updateCurrentModel(fieldValue, fieldName) {
                            if (fieldName === "deleted" && fieldValue == true) {
                                self.destroyModel = true;
                            } else {
                                var targetFieldData = self.model.fields[fieldName];

                                if (targetFieldData && targetFieldData.type === "datetimecombo") {
                                    fieldValue = App.date(fieldValue).formatServer();
                                }
                                self.model.set(fieldName, fieldValue);
                            }
                        });

                        self.executeNextAction();
                    }
                }
            );
        } else if (currentModelNeedsSaving) {
            this.executeNextAction();
        }
    },

    saveCurrentModel: function (isValid) {
        if (isValid === true || this.module === "Products") {
            var self = this;
            //Show alerts for this request
            var alerts = {
                process: {
                    title    : "Saving",
                    messages : "Updating fields..."
                },
                success: {
                    messages: "Save successful."
                }
            };

            // save the model if we do not have to make an api call
            this.model.save(this.model.attributes, {
                showAlerts : alerts,
                success    : function notifySaveFinished() {
                    if (self.destroyModel === true) {
                        app.alert.show("alert_wrb_go_back", {
                            level          : "info",
                            title          : "Deleting current record...",
                            autoClose      : true,
                            autoCloseDelay : 2000
                        });

                        self.model.destroy({
                            success: function navigateToParentModule() {
                                app.alert.dismissAll();

                                if (self.view.type === "record") {
                                    app.router.navigate("#" + self.model.module, {
                                        trigger: true
                                    });
                                } else {
                                    self.refetchRelatedCollection();
                                }
                            }
                        });
                    }
                    self.executeNextAction();
                }
            });
        } else {
            var executeViewName = this.getExecuteViewName({
                actionParameters: {
                    executeView: "wrecord-button-edit-record"
                }
            });
            this.callExecuteFunction(executeViewName, [{
                actionParameters: {
                    recordAttributes: {}
                }
            }]);
        }
    },

    refetchRelatedCollection: function () {
        var parentModel = app.controller.context.get("model");
        var relateCollection = this.collection;
        if (this.view.type !== "recordlist" && this.model && this.model.link && this.model.link.name) {
            relateCollection = parentModel.getRelatedCollection(this.model.link.name);
            relateCollection.fetch({
                relate: true
            });
        } else {
            relateCollection.fetch();
            if (this.view.name === "dashablelist") {
                if (this.model.id === parentModel.id) {
                    app.router.navigate("#" + this.model.module, {
                        trigger: true
                    });
                } else {
                    app.controller.context.get("collection").fetch();

                    _.each(parentModel._relatedCollections, function refreshCollection(collection) {
                        if (collection.module === this.model.module) {
                            collection.fetch();
                        }
                    }.bind(this));
                }
            }
        }
    },

    getFields: function (module, model) {
        var fields = {};
        var fieldNames = this.getFieldNames(module);
        _.each(
            fieldNames,
            function stackFields(name) {
                var field = this.getField(name, model);
                if (field) {
                    fields[name] = field.def;
                }
            },
            this
        );
        return fields;
    },

    getFieldNames: function (module) {
        var fields = [];
        module = module || this.context.get("module");

        var fieldsMeta = {};

        if (this.view.meta.panels) {
            fieldsMeta = this.view.meta.panels;
        } else {
            _.each(this.view.layout._components, function getMetaPanels(componentData) {
                if (componentData.meta.panels) {
                    fieldsMeta = componentData.meta.panels;
                }
            });
        }

        if (fieldsMeta) {
            fields = _.reduce(
                _.map(fieldsMeta, function getValidFields(panel) {
                    var nestedFields = _.flatten(_.compact(_.pluck(panel.fields, "fields")));
                    return _.pluck(panel.fields, "name")
                        .concat(_.pluck(nestedFields, "name"))
                        .concat(_.flatten(_.compact(_.pluck(panel.fields, "related_fields"))));
                }),
                function concatTheseFields(memo, field) {
                    return memo.concat(field);
                },
                []
            );
        }

        fields = _.compact(_.uniq(fields));

        var fieldMetadata = SUGAR.App.metadata.getModule(module, "fields");
        if (fieldMetadata) {
            // Filter out all fields that are not actual bean fields
            fields = _.reject(fields, function filterOut(name) {
                return _.isUndefined(fieldMetadata[name]);
            });

            // we need to find the relates and add the actual id fields
            var relates = [];
            _.each(fields, function findRelates(name) {
                if (fieldMetadata[name].type == "relate") {
                    relates.push(fieldMetadata[name].id_name);
                } else if (fieldMetadata[name].type == "parent") {
                    relates.push(fieldMetadata[name].id_name);
                    relates.push(fieldMetadata[name].type_name);
                }
                if (_.isArray(fieldMetadata[name].fields)) {
                    relates = relates.concat(fieldMetadata[name].fields);
                }
            });

            fields = _.union(fields, relates);
        }

        return fields;
    },
    /**
     * Returns a field by name.
     *
     * @param {string} name Field name.
     * @param {Data/Bean} [model] Model to find the field for.
     * @return {View/Field} Instance of the field widget.
     * @memberOf View/View
     * @instance
     */
    getField: function (name, model) {
        var parentViewFields = {};

        if (this.view.meta.panels) {
            parentViewFields = this.view.fields;
        } else {
            _.each(
                this.view.layout._components,
                function getMetaPanels(componentData) {
                    if (componentData.meta.panels) {
                        parentViewFields = componentData.fields;
                    }
                }.bind(this)
            );
        }

        return _.find(parentViewFields, function returnField(field) {
            return field.name == name && (!model || field.model == model);
        });
    },

    trySaveModel: function () {
        var allFields = this.getFields(this.module, this.model);
        var fieldsToValidate = {};
        var erasedFields = this.model.get("_erased_fields");
        for (var fieldKey in allFields) {
            if (
                app.acl.hasAccessToModel("edit", this.model, fieldKey) &&
                (!_.contains(erasedFields, fieldKey) || this.model.get(fieldKey) || allFields[fieldKey].id_name)
            ) {
                _.extend(fieldsToValidate, _.pick(allFields, fieldKey));
            }
        }
        this.model.doValidate(fieldsToValidate, _.bind(this.saveCurrentModel, this));
    },

    convertLead: function (actionData) {
        if (this.model.get("converted") === true) {
            app.alert.show("alert_lead_converted", {
                level          : "error",
                title          : "This record is already converted!",
                autoClose      : true,
                autoCloseDelay : 5000
            });
            this.executeNextAction();
        } else if (this.model.get("converted") === false) {
            var model = app.data.createBean("Leads");

            model.set(app.utils.deepCopy(this.model));
            app.drawer.open({
                layout  : "convert",
                context : {
                    forceNew      : true,
                    skipFetch     : true,
                    module        : "Leads",
                    leadsModel    : model,
                    wRecordButton : this
                }
            },
            this.executeNextAction.bind(this)
            );
        } else {
            this.model.fetch({
                success: function getAllAttributes() {
                    this.convertLead();
                    this.executeNextAction();
                }.bind(this)
            });
        }
    },

    runJob: function (buttonData) {
        var requestParams = {
            jobName          : buttonData.actionParameters.jobName,
            jobFunction      : buttonData.actionParameters.jobField,
            recordModuleType : this.module,
            recordId         : this.model.get("id")
        };

        var message = buttonData.actionParameters.jobName + " job has started";

        app.alert.show("alert_run_job_started" + App.utils.generateUUID(), {
            level          : "info",
            title          : message,
            autoClose      : true,
            autoCloseDelay : 5000
        });

        var jobQueuedCallback = {
            success: function checkJobs(jobId) {
                this.activeJobs[jobId] = requestParams.jobName;
                this.checkJobsStatus();
                this.executeNextAction();
            }.bind(this)
        };

        app.api.call("create", app.api.buildURL("RunScheduleJob"), requestParams, null, jobQueuedCallback);
    },

    checkJobsStatus: function () {
        if (Object.keys(this.activeJobs).length > 0 && this.checkJobsStatusInProgress === false) {
            this.checkJobsStatusInProgress = true;
            var requestParams = {
                jobs: this.activeJobs
            };

            var jobStatusRetrievedCallback = {
                success: function checkStatus(jobsStatuses) {
                    this.checkJobsStatusInProgress = false;

                    // iterating through jobs in progress and showing feedback if the job status is done
                    _.each(
                        jobsStatuses,
                        function tryShowAlert(jobStatus, jobId) {
                            if (jobStatus.status === "done") {
                                var message =
                                    "The resolution of the " + jobStatus.jobName + " job is: " + jobStatus.resolution;

                                app.alert.show("alert_run_job_finished" + App.utils.generateUUID(), {
                                    level          : "info",
                                    title          : message,
                                    autoClose      : true,
                                    autoCloseDelay : 5000
                                });
                                delete this.activeJobs[jobId];
                            }
                        }.bind(this)
                    );

                    if (Object.keys(this.activeJobs).length > 0) {
                        var timeoutMiliseconds = 5000;
                        setTimeout(this.checkJobsStatus.bind(this), timeoutMiliseconds);
                    }
                }.bind(this)
            };

            app.api.call(
                "create",
                app.api.buildURL("CheckScheduleJobsStatus"),
                requestParams,
                null,
                jobStatusRetrievedCallback
            );
        }
    },

    updateField: function (buttonData, buttonId, actionId) {
        this.mustSaveModel = true;

        try {
            var fieldDefaultValue = buttonData.actionParameters.defaultValue;
            var fieldDefaultValueText = buttonData.actionParameters.defaultValueText;
            var isCalculated = buttonData.actionParameters.calculatedField;
            var formulaFunction = buttonData.actionParameters.formulaElement;
            formulaFunction = formulaFunction.replace(/'/g, "\"");
            var targetedField = buttonData.actionParameters.fieldType;
            var module = buttonData.actionParameters.moduleType;
            var uniqueIdentifier = App.utils.generateUUID();

            var accessModule = module === "1currentModule" ? this.view.model.module : module;

            if (app.acl.hasAccess("edit", accessModule)) {
                this.updateFieldParams[uniqueIdentifier] = {
                    calculated       : isCalculated,
                    formulaElement   : formulaFunction,
                    fieldToBeUpdated : targetedField,
                    defaultValue     : fieldDefaultValue,
                    defaultValueText : fieldDefaultValueText,
                    moduleType       : module
                };

                if (formulaFunction.indexOf("(") > -1) {
                    var params = {
                        formula     : formulaFunction,
                        model       : JSON.stringify(this.model),
                        targetField : targetedField
                    };

                    this.updateFieldParams[uniqueIdentifier].requestParams = params;
                }
                this.updateFieldAction(buttonData);
            } else {
                this.showNoAccessAlert();
            }
        } catch (e) {
            alert("Invalid formula! Check the formula in the Studio!");
        }
    },

    showNoAccessAlert: function () {
        app.alert.show("alert_no_access", {
            level          : "error",
            title          : "You do not have permission to perform this action or access this resource!",
            autoClose      : true,
            autoCloseDelay : 5000
        });

        this.executeNextAction();
    },

    runUrl: function (buttonData) {
        this.goToWebsite(buttonData);
    },

    goToWebsite: function (buttonData) {
        var self = this;

        if (buttonData.actionParameters.calculatedField === true) {
            var cleanFormula = this.replaceCharInFormula(buttonData.actionParameters.formulaElement, "'", "\"");

            var successCallback = {
                success: function (expressionData) {
                    if (buttonData.actionParameters.showAlert === true) {
                        app.alert.show("go-to-website", {
                            level     : "confirmation",
                            messages  : "This action will open a new tab.Do you want to proceed?",
                            autoClose : false,
                            onConfirm : function () {
                                var takeCalculatedUrl = expressionData.buildUrlTempField.value;
                                if (!takeCalculatedUrl || takeCalculatedUrl === "") {
                                    app.alert.show("alert_invalid_url", {
                                        level          : "error",
                                        title          : "This URL: " + takeCalculatedUrl + " is not valid!",
                                        autoClose      : true,
                                        autoCloseDelay : 5000
                                    });
                                } else {
                                    var win = window.open(takeCalculatedUrl, "_blank");
                                    win.focus();
                                    self.executeNextAction();
                                }
                            },
                            onCancel: function () {
                                self.executeNextAction();
                            }
                        });
                    } else {
                        var takeCalculatedUrl = expressionData.buildUrlTempField.value;
                        if (!takeCalculatedUrl || takeCalculatedUrl === "") {
                            app.alert.show("alert_invalid_url", {
                                level          : "error",
                                title          : "This URL: " + takeCalculatedUrl + " is not valid!",
                                autoClose      : true,
                                autoCloseDelay : 5000
                            });
                        } else {
                            var win = window.open(takeCalculatedUrl, "_blank");
                            win.focus();
                            self.executeNextAction();
                        }
                    }
                }
            };
            var apiUrl = app.api.buildURL("EvaluateCalculatedURL/evaluate_calculated_url", "create", {}, {});

            var takeCalculatedUrlFormula = {
                keepTempFieldForCalculatedURL: {
                    buildUrlTempField: {
                        targetField : "buildUrlTempField",
                        formula     : cleanFormula
                    }
                },
                recordType : this.model.module,
                recordId   : this.model.id
            };

            app.api.call("create", apiUrl, takeCalculatedUrlFormula, null, successCallback);
        } else {
            this.model.fetch({
                success: function () {
                    if (buttonData.actionParameters.showAlert === true) {
                        app.alert.show("go-to-website", {
                            level     : "confirmation",
                            messages  : "This action will open a new tab.Do you want to proceed?",
                            autoClose : false,
                            onConfirm : function () {
                                var completeUrl = buttonData.actionParameters.finalUrl;
                                var attributes = completeUrl.match(/\{.*?\}/g);
    
                                _.each(attributes, function replaceAttributes(attribute) {
                                    var attributeName = attribute.match(/\{([^)]+)\}/)[1];
                                    var fieldValue = "";
                                    if (self.model === null) {
                                        fieldValue = self.view.context.attributes.model.get(attributeName);
                                    } else {
                                        fieldValue = self.model.get(attributeName);
                                    }
    
                                    completeUrl = completeUrl.replace(/\{.*?\}/, fieldValue);
                                });
    
                                completeUrl.replace(/ /g, "%20");
    
                                if (!completeUrl || completeUrl === "") {
                                    app.alert.show("alert_invalid_url", {
                                        level          : "error",
                                        title          : "This URL: " + completeUrl + " is not valid!",
                                        autoClose      : true,
                                        autoCloseDelay : 5000
                                    });
                                } else {
                                    var protocol = completeUrl.match(/^\w+:/gi);
    
                                    if (!protocol) {
                                        completeUrl = "http://" + completeUrl;
                                    }
    
                                    self.openUrl(completeUrl);
                                }
                                self.executeNextAction();
                            },
                            onCancel: function () {
                                self.executeNextAction();
                            }
                        });
                    } else {
                        var completeUrl = buttonData.actionParameters.finalUrl;
                        var attributes = completeUrl.match(/\{.*?\}/g);

                        _.each(attributes, function replaceAttributes(attribute) {
                            var attributeName = attribute.match(/\{([^)]+)\}/)[1];
                            var fieldValue = "";
                            if (self.model === null) {
                                fieldValue = self.view.context.attributes.model.get(attributeName);
                            } else {
                                fieldValue = self.model.get(attributeName);
                            }

                            completeUrl = completeUrl.replace(/\{.*?\}/, fieldValue);
                        });

                        completeUrl.replace(/ /g, "%20");

                        if (!completeUrl || completeUrl === "") {
                            app.alert.show("alert_invalid_url", {
                                level          : "error",
                                title          : "This URL: " + completeUrl + " is not valid!",
                                autoClose      : true,
                                autoCloseDelay : 5000
                            });
                        } else {
                            var protocol = completeUrl.match(/^\w+:/gi);

                            if (!protocol) {
                                completeUrl = "http://" + completeUrl;
                            }

                            self.openUrl(completeUrl);
                        }
                        self.executeNextAction();
                    }
                }
            });
        }
    },

    openUrl: function (urlToOpen) {
        var win = window.open(urlToOpen, "_blank");
        win.focus();
    },

    mergeDocument: function (buttonData) {
        var documentData = _.clone(buttonData.actionParameters);
        var doc = documentData.document;

        var mergeDocOptions = {
            //eslint-disable-next-line camelcase
            doc_id       : doc.template.document_id,
            //eslint-disable-next-line camelcase
            doc_name     : doc.template.filename,
            mergeType    : documentData.mergeType,
            mergeOptions : {
                mergeType : documentData.mergeType,
                model     : this.options.model
            }
        };

        App.events.trigger("wDocs:merge_document", mergeDocOptions);

        this.executeNextAction();
    },

    _render: function (skipWireframeLoading) {
        this.isDashletOrPreview = this.isDashlet || this.view.tplName === "preview";

        if (this.isDashletOrPreview) {
            // in the dashlet we need to truncate the text in order to display it properly
            var parentWidth = this.$el.parent().width();
            var widthOffset = 0.6;
            this.forcedWidth = parentWidth * widthOffset;
        }

        this._super("_render");

        if (!this.buttonsPartiallyLoaded) {
            this.createWireframeLoading();
        }

        if (this.isDropdown === true) {
            // close dropdown when scrolling
            this.hideDropdownOnScroll(".main-pane");
            this.hideDropdownOnScroll(".dashboard");
            this.hideDropdownOnScroll(".sidebar-content");
            this.hideDropdownOnScroll(".flex-list-view-content");
            this.hideDropdownOnScroll(".list-view");

            $(window).scroll(
                function closeDropdown() {
                    this.closeDropdowns();
                }.bind(this)
            );

            var dropdownOptions = this.$el.find(".dropdownOption");
            dropdownOptions.click(this.buttonClicked.bind(this));

            $(window).on(
                "hide.bs.dropdown",
                function closeDropdownsFunc(e) {
                    if (
                        this.$el &&
                        e.target.children[0] &&
                        e.target.children[0].id !== "" &&
                        this.$el.find("#" + e.target.children[0].id).length > 0
                    ) {
                        this.closeDropdowns();
                    }
                }.bind(this)
            );
        }

        if (this.action === "noaccess") {
            this.$el.hide();
        }

        if (this.tplName === "detail") {
            this.$el.find(".buttonsContainerGroupClass").css("max-width", this.$el.width());
        }
    },

    closeDropdowns: function () {
        if (this.$el) {
            var dropdownParent = this.$el.find("#dropdownMenuParent");
            var dropdownEl = this.$el.find(".dropdown-menu." + this.buttonId);

            if (dropdownEl.length === 0) {
                dropdownEl = $("body").find(".dropdown-menu." + this.buttonId);
            }

            if (dropdownEl.length > 0 && dropdownEl.is(":visible")) {
                dropdownParent.append(dropdownEl.detach());
                dropdownParent.removeClass("open");
                dropdownEl.removeClass("open");
                dropdownEl.hide();
                $(".showDropdown").css("z-index", "inherit");
            }
        }
    },

    hideDropdownOnScroll: function (containerIdentifier) {
        var scrollingContainter = $(containerIdentifier);

        scrollingContainter.scroll(
            function closeDropdown() {
                this.closeDropdowns();
            }.bind(this)
        );
    },

    detachDropdown: function () {
        var dropdownParent = this.$el.find("#dropdownMenuParent");
        var dropdownElement = this.$el.find(".wrecordButtonDropdownMenu");

        $("body").append(dropdownElement.detach());

        // grab the new offset position
        var eOffset = dropdownParent.offset();

        // make sure to place it where it would normally go (this could be improved)
        dropdownElement.css({
            display : "block",
            top     : eOffset.top + dropdownParent.outerHeight(),
            left    : eOffset.left
        });

        dropdownParent.on("remove", function remoteDropdownParent() {
            dropdownElement.remove();
        });
    },

    positionDropdownMenu: function () {
        if (
            (this.isDashletOrPreview || this.view.tplName === "record" || this.view.tplName === "list") &&
            this.isDropdown === true
        ) {
            var dropdownParent = this.$el.find(".dropdownParent");
            var dropdownMenu = this.$el.find(".dropdown-menu." + this.buttonId);
            var heightOffset = 15;
            var endPageOffset = 35;

            if (dropdownMenu.length === 0) {
                dropdownMenu = $("body").find(".dropdown-menu." + this.buttonId);
            }

            var xPosition = dropdownParent.offset().left + "px";
            var yPosition = dropdownParent.offset().top + dropdownParent.height() + heightOffset + "px";

            if (
                dropdownParent.offset().top +
                dropdownParent.height() +
                dropdownMenu.height() +
                heightOffset +
                endPageOffset >=
                $(document).height()
            ) {
                yPosition = dropdownParent.offset().top - dropdownMenu.height() + "px";
            }

            dropdownMenu.css("left", xPosition);
            dropdownMenu.css("top", yPosition);
        }
    },

    format: function (value) {
        return this._super("format", [value]);
    },

    unformat: function (value) {
        return this._super("unformat", [value]);
    }
});