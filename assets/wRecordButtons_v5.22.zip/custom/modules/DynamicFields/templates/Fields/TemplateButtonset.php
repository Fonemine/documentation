<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (�MSA�), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/
require_once 'include/api/SugarApiException.php';
require_once 'modules/DynamicFields/templates/Fields/TemplateText.php';
class TemplateButtonset extends TemplateText
{
    public $type       = 'buttonset';
    public $defOptions = '';

    public function get_field_def()
    {
        $def             = parent::get_field_def();
        $def['studio']   = 'visible';
        $def['size']     = 50;
        $def['type']     = 'buttonset';
        $def['dbType']   = 'text';
        $def['readonly'] = true;

        if (isset($this->ext4)) {
            $extDecoded = json_decode($this->ext4);
            if ($extDecoded !== null) {
                $this->ext4 = base64_encode(gzdeflate($this->ext4));
            }

            $decodedExt4 = base64_decode($this->ext4);

            $deflated = @gzinflate($decodedExt4); // to avoid getting a warning

            if ($decodedExt4 != $deflated && $deflated !== false) {
                $inflatedButtonData = gzinflate($decodedExt4);
            } else {
                $inflatedButtonData = '{"buttonsSettings": {}, "buttons": {}}';
            }

            if ($inflatedButtonData) {
                $this->ext4 = $inflatedButtonData;
            }

            $def['options']   = addslashes($this->ext4);
            $this->defOptions = $def['options'];
        }

        return $def;
    }

    public function get_db_type()
    {
        $type = $GLOBALS['db']->getColumnType("varchar");

        return " $type({$this->len})";
    }

    public function save($df)
    {

        $this->ext4 = base64_encode(gzdeflate($this->ext4));

        parent::save($df);
    }
}
