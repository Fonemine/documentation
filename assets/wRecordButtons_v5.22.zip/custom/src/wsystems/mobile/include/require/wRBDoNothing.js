/*eslint-disable*/
class wRBDoNothing {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
    }
}

module.exports.wRBDoNothing = wRBDoNothing;