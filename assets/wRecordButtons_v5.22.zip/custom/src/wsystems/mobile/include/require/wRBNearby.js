/*eslint-disable*/
class wRBNearby {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        var self = this;
        SUGAR.customizationTools.dialog.showPrompt("Distance(1-250 Miles)", {
            defaultText: "",
            callback: function (response) {
                app.mobile.wMapsContextButtons.wMapsMobileButtonsManager.filterRecordsCustomDistance(response);
                self.manager.goToNextActionDelayed(self);
            }
        });
    }
}

module.exports.wRBNearby = wRBNearby;