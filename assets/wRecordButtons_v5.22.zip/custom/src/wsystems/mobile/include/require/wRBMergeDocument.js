/*eslint-disable*/
class wRBMergeDocument {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (app.acl.hasAccess("edit", actionData.recordType)) {
            var documentData = _.clone(actionData);
            var doc = documentData.document;

            var mergeDocOptions = {
                //eslint-disable-next-line camelcase
                doc_id: doc.template.document_id,
                //eslint-disable-next-line camelcase
                doc_name: doc.template.filename,
                mergeType: documentData.mergeType,
                mergeOptions: {
                    mergeType: documentData.mergeType,
                    model: model
                }
            };

            App.alert.show("merging-doc-mobile", {
                level: "load",
                messages: "Merging Document",
                autoClose: false
            });

            this.createMergedDoc(mergeDocOptions);
        } else {
            this.manager.showNoAccessAlert();
        }
    }

    createMergedDoc(options) {
        var model = options.model;
        var mergeOptions = options.mergeOptions;
        var docName = options.doc_name;
        var docId = options.doc_id;
        var mergeType = options.mergeType;
        var parentId = false;
        var parentModule = false;

        if (options.parent_id && options.parent_module) {
            parentId = options.parent_id;
            parentModule = options.parent_module;
        }
        if (model || (mergeOptions && mergeOptions.model)) {
            mergeOptions = mergeOptions || {};
            if (mergeOptions && mergeOptions.model) {
                mergeOptions.model = mergeOptions.model;
            } else {
                mergeOptions.model = model;
            }

            var mergeRecordsHtml = "";

            var rName =
                mergeOptions.model.get("name") ||
                mergeOptions.model.get("first_name") + " " + mergeOptions.model.get("last_name");

            mergeRecordsHtml =
                "<a href='#" + mergeOptions.model.module + "/" + mergeOptions.model.get("id") + "'>" + rName + "</a>";

            var wsData = {
                mergeType: mergeType,
                //eslint-disable-next-line camelcase
                model_module: mergeOptions.model.attributes._module,
                //eslint-disable-next-line camelcase
                model_id: mergeOptions.model.id,
                //eslint-disable-next-line camelcase
                doc_id: docId,
                //eslint-disable-next-line camelcase
                instance_url: app.loginManager.getTempSetting().siteUrl + "/",
                //eslint-disable-next-line camelcase
                user_prefs_hash: app.api.getUserprefHash(),
                //eslint-disable-next-line camelcase
                metadata_hash: app.metadata.getHash(),
                mergeRecordsHtml: mergeRecordsHtml,
                //eslint-disable-next-line camelcase
                merge_models_no: 1
            };

            if (parentId && parentModule) {
                //eslint-disable-next-line camelcase
                wsData.parent_id = parentId;
                //eslint-disable-next-line camelcase
                wsData.parent_module = parentModule;
            }

            if (mergeOptions.cloudServiceName) {
                wsData.cloudServiceName = mergeOptions.cloudServiceName;
            }
            wsData.docuSignFlow = mergeOptions.docuSignFlow;
            this.retrieveAdditionalSettings(wsData, docName, rName).then(this.sendDataToApi.bind(this));
        }
    }

    sendDataToApi(wsData) {
        //eslint-disable-next-line camelcase
        wsData.user_timezone = App.user.attributes.preferences.timezone;
        var cloudServiceName = wsData.cloudServiceName === undefined ? false : wsData.cloudServiceName;
        var docuSignFlow = wsData.docuSignFlow === undefined ? false : wsData.docuSignFlow;
        var cloudDriveParams = {
            cloudServiceName: cloudServiceName,
            docuSignFlow: docuSignFlow
        };
        app.api.call(
            "create",
            app.api.buildURL("wDocsMergeMobile"), {
                data: wsData,
                mobileUserId: app.user.id
            }, {
                success: _.partial(_.bind(this.mergeCallback, this), cloudDriveParams)
            }
        );
    }

    mergeCallback(cloudDriveParams, message) {
        var self = this;
        var timeoutTreshold = 2000;
        if (message) {
            this.timer = setInterval(
                function getMergedDocs() {
                    App.api.call(
                        "create",
                        app.api.buildURL("GetMergedDocumentsMobile"), {
                            mobileUserId: app.user.id
                        }, {
                            success: function successCallback(data) {
                                var docs = data[0];
                                var errMessages = data[1];
                                if (docs.length > 0) {
                                    clearInterval(this.timer);
                                    for (var docIndex = 0; docIndex < docs.length; docIndex++) {
                                        var id = docs[docIndex];
                                        App.data.createBean("Documents", {
                                            id: id
                                        }).fetch({
                                            success: function successCallback(docModel) {
                                                app.alert.dismiss("merging-doc-mobile");
                                                app.controller.trigger("wRBActionFinished", this);
                                            }.bind(this),
                                            error: function errorCallback() {
                                                app.controller.trigger("wRBActionFinished", this);
                                            }.bind(this)
                                        });
                                    }
                                }
                                if (errMessages.length > 0) {
                                    for (var i = 0; i < errMessages.length; i++) {
                                        if (errMessages[i] != "Server Error") errMessages[i] = "Template Error";
                                        App.alert.show("message-id", {
                                            level: "error",
                                            messages: errMessages[i],
                                            autoClose: true,
                                            autoCloseDelay: 5000
                                        });
                                    }
                                }
                            }.bind(this)
                        }
                    );
                }.bind(this),
                timeoutTreshold
            );
        }
    }

    retrieveAdditionalSettings(wsData, templateName, name) {
        return new Promise(function extendOptions(resolve, reject) {
            app.api.call(
                "create",
                app.api.buildURL("getwDocsConfigMobile"), {
                    mobileUserId: app.user.id
                }, {
                    success: function (config) {
                        config = JSON.parse(config);
                        if (config.error) {
                            reject(config);
                        }

                        if (config.prompt_for_filename) {
                            var docFilename = prompt(
                                "Please enter the document filename: ",
                                name + " - " + templateName
                            );
                            //eslint-disable-next-line camelcase
                            wsData.desired_filename_c = docFilename;
                            resolve(wsData);
                        } else {
                            resolve(wsData);
                        }
                    }
                }
            );
        });
    }
}

module.exports.wRBMergeDocument = wRBMergeDocument;