/*eslint-disable*/
class wRBHandleRoute {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (app.mobile.wMapsContextButtons.wMapsMobileButtonsVisibility.canShowAddToRouteButton()) {
            app.mobile.wMapsContextButtons.wMapsMobileButtonsManager.addRecordToRoute();
        } else {
            app.mobile.wMapsContextButtons.wMapsMobileButtonsManager.removeRecordFromRoute();
        }

        app.controller.trigger("wMaps-collection-route-changed");
        app.controller.trigger("wRBActionFinished", this);
    }
}

module.exports.wRBHandleRoute = wRBHandleRoute;