/*eslint-disable*/
class wRBMap {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        app.mobile.wMapsContextButtons.wMapsMobileMapManager.tryShowBingMap(false);

        this.manager.goToNextActionDelayed(this);
    }
}

module.exports.wRBMap = wRBMap;