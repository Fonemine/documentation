/*eslint-disable*/
class wRBRunJob {
    constructor(manager) {
        this.manager = manager;
        this.activeJobs = {};
        this.checkJobsStatusInProgress = false;
    }

    execute(actionData, model) {
        if (window.navigator.onLine === true) {
            var requestParams = {
                jobName: actionData.jobName,
                jobFunction: actionData.jobField,
                recordModuleType: model.module,
                recordId: model.get("id")
            };

            var message = actionData.jobName + " job has started";

            app.alert.show("alert_run_job_started" + App.utils.generateUUID(), {
                level: "info",
                title: message,
                messages: message,
                autoClose: true,
                autoCloseDelay: 5000
            });

            var jobQueuedCallback = {
                success: function checkJobs(jobId) {
                    this.activeJobs[jobId] = requestParams.jobName;

                    this.checkJobsStatus();

                    app.controller.trigger("wRBActionFinished", this);
                }.bind(this)
            };

            app.api.call("create", app.api.buildURL("RunScheduleJob"), requestParams, null, jobQueuedCallback);
        } else {
            app.alert.show("alert_invalid_url", {
                level: "error",
                title: "ErrorUrl",
                messages: "This functionality is not available while offline!",
                autoClose: true,
                autoCloseDelay: 5000
            });
        }
    }


    checkJobsStatus() {
        if (Object.keys(this.activeJobs).length > 0 && this.checkJobsStatusInProgress === false) {
            this.checkJobsStatusInProgress = true;
            var requestParams = {
                jobs: this.activeJobs
            };

            var jobStatusRetrievedCallback = {
                success: function checkStatus(jobsStatuses) {
                    this.checkJobsStatusInProgress = false;

                    // iterating through jobs in progress and showing feedback if the job status is done
                    _.each(
                        jobsStatuses,
                        function tryShowAlert(jobStatus, jobId) {
                            if (jobStatus.status === "done") {
                                var message =
                                    "The resolution of the " + jobStatus.jobName + " job is: " + jobStatus.resolution;

                                app.alert.show("alert_run_job_finished" + App.utils.generateUUID(), {
                                    level: "info",
                                    title: message,
                                    messages: message,
                                    autoClose: true,
                                    autoCloseDelay: 5000
                                });
                                delete this.activeJobs[jobId];
                            }
                        }.bind(this)
                    );

                    if (Object.keys(this.activeJobs).length > 0) {
                        var timeoutMiliseconds = 5000;
                        setTimeout(this.checkJobsStatus.bind(this), timeoutMiliseconds);
                    }
                }.bind(this)
            };

            app.api.call(
                "create",
                app.api.buildURL("CheckScheduleJobsStatus"),
                requestParams,
                null,
                jobStatusRetrievedCallback
            );
        }
    }
}

module.exports.wRBRunJob = wRBRunJob;