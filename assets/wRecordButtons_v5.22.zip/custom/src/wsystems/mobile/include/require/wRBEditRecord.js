/*eslint-disable*/
class wRBEditRecord {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (app.acl.hasAccess("edit", actionData.recordType)) {
            var loadScreenOptions = {
                action: "edit",
                module: model.module,
                modelId: model.id,
                root: ""
            };

            var views = app.controller._loadScreen(loadScreenOptions);
            var editView = _.filter(views, function getEditView(viewData) {
                return viewData.options.baseType === "edit";
            })[0];

            var recordAttributes = _.clone(actionData.recordAttributes);
            editView.model.on("sync", function applyCustomAttributes() {
                editView.model.set(recordAttributes);
            });

            this.manager.registerStepInHistory("#" + model.module + "/" + model.id + "/edit");

            app.controller.trigger("wRBActionFinished", this);
        } else {
            this.manager.showNoAccessAlert();
        }
    }
}

module.exports.wRBEditRecord = wRBEditRecord;