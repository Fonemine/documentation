/*eslint-disable*/
class wRBActionsManager {
    constructor() {
        this.actionsQueue = {};

        this.registerContextEvents();
    }

    registerContextEvents() {
        // we need to know when a queue of actions has been trigger and when an action has finished its execution
        app.controller.on("wRBActionFinished", this.wRBActionFinished.bind(this));
        app.controller.on("wRBActionsTriggered", this.wRBActionsTriggered.bind(this));
    }

    wRBActionsTriggered(actionsData, model) {
        // adding this actions queue to our internal list in order for us to process it
        var actionsQueueId = app.utils.generateUUID();
        this.actionsQueue[actionsQueueId] = {
            actionsData: actionsData,
            model: model,
            id: actionsQueueId
        };

        // executing the first action from the queue
        this.executeNextAction(actionsQueueId);
    }

    executeNextAction(actionsQueueId) {
        // getting all the data needed in order to run the action
        var targetActionQueue = this.actionsQueue[actionsQueueId];
        var actions = targetActionQueue.actionsData;
        var nextActionId = Object.keys(actions)[0];
        var nextActionData = actions[nextActionId];

        var skipActionFinishedEvent = this.checkFollowingActionExecution(actionsQueueId);

        // executing the action using the gathered data
        this.executeAction(nextActionData, nextActionId, targetActionQueue, skipActionFinishedEvent);
    }

    executeAction(actionData, actionId, actionsQueue, skipActionFinishedEvent) {
        actionData = actionData ? actionData : {
            action: ""
        };
        actionId = actionId ? actionId : "";

        // getting the action class and calling the execute function
        var action = this.getRequired(actionData.action);

        // setting a queue id and an action id in order for us to be able to 
        // get the action out of the queue after it's finished
        action.queueId = actionsQueue.id;
        action.actionId = actionId;
        action.skipActionFinishedEvent = skipActionFinishedEvent;

        action.execute(actionData.actionParameters, actionsQueue.model);

        if (skipActionFinishedEvent) {
            this.wRBActionFinished(action, true);
        }
    }

    wRBActionFinished(action, forceFinishAction) {
        // don't go to the next action unless I am allowed to
        if (forceFinishAction || !action.skipActionFinishedEvent) {
            // remove the action from its queue as it is finished
            this.removeCurrentActionFromQueue(action.queueId, action.actionId);

            // if we no longer have actions in the queue, remove the queue from the queues list
            if (Object.keys(this.actionsQueue[action.queueId].actionsData).length == 0) {
                delete this.actionsQueue[action.queueId];
                app.controller.trigger("wRBActionsQueueFinished");
            } else {
                // otherwise execute the next action from the queue
                this.executeNextAction(action.queueId);
            }
        }
    }

    removeCurrentActionFromQueue(queueId, actionId) {
        // get the executed action out of the queue
        delete this.actionsQueue[queueId].actionsData[actionId];
    }

    checkFollowingActionExecution(actionsQueueId) {
        // getting all the data needed in order to run the action
        var targetActionQueue = this.actionsQueue[actionsQueueId];
        var actions = targetActionQueue.actionsData;
        var nextActionId = Object.keys(actions)[1];
        var nextActionExecutesImmediately = nextActionId && actions[nextActionId] && actions[nextActionId].executeImmediately;

        return nextActionExecutesImmediately;
    }

    getRequired(actionName) {
        // building the name of the class from the name of the action
        var className = "wRB" + actionName.charAt(0).toUpperCase() + actionName.slice(1);
        var requiredClass = window.require("src/wsystems/mobile/include/require/" + className)[className];
        var actionClass = new requiredClass(this);

        return actionClass;
    }

    showNoAccessAlert() {
        // trigger this whenever we need to inform the user of the lack of access
        app.alert.show("alert_no_access", {
            level: "error",
            title: "You do not have permission to perform this action or access this resource!",
            messages: "You do not have permission to perform this action or access this resource!",
            autoClose: true,
            autoCloseDelay: 5000
        });

        this.executeNextAction();
    }

    registerStepInHistory(url) {
        // this is a function that needs to be called if you navigate to another screen
        // simply call this to store the start page url in history so that you could go back to it
        var historyParams = {
            initiator: {
                name: "GENERIC"
            },
            url: url
        };
        historyParams = _.extend(historyParams, app.navigation.manager._getUrlInfo(historyParams.url));
        historyParams = _.extend({}, historyParams, {
            id: ++app.navigation.manager._seedId,
            replaceCurrent: false
        });

        const upStepParams = app.navigation.manager._getUpStepParams(historyParams);

        _.extend(historyParams, upStepParams);

        app.navigation.history._previous = app.navigation.history._current;
        app.navigation.history._steps.push(app.navigation.history._current);
        app.navigation.history._current = _.omit(historyParams, "replaceCurrent");
        app.navigation.history._syncBrowserHistory();
    }

    goToNextActionDelayed(actionController, delayNextActionTime) {
        var defaultTimer = 2000;
        delayNextActionTime = delayNextActionTime ? delayNextActionTime : defaultTimer;

        setTimeout(function goToNextAction() {
            app.controller.trigger("wRBActionFinished", actionController);
        }.bind(this), delayNextActionTime);
    }
}

var actionsManager = new wRBActionsManager();
app.mobile.wRBActionsManager = actionsManager;

module.exports.wRBActionsManager = wRBActionsManager;