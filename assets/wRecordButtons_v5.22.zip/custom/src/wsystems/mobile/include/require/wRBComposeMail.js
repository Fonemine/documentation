/*eslint-disable*/
class wRBComposeMail {
    constructor(manager) {
        this.manager = manager;
    }

    execute(actionData, model) {
        if (actionData.emailTemplate && window.navigator.onLine === true) {
            var requestParams = this.getRequestParams(actionData.usePMSETemplates, model, actionData);
            var apiPath = actionData.usePMSETemplates ? "EnhancedEmailTemplates" : "GetEmailTemplateProcessedData/getEmailTemplateProcessedData";

            var apiUrl = app.api.buildURL(apiPath,
                "create",
                requestParams, {}
            );
            var successCallback = {
                success: function loadEmailDrawer(emailTemplateData) {
                    this.openComposeEmailDrawer(actionData, emailTemplateData, model);
                }.bind(this)
            };
            app.api.call("create", apiUrl, requestParams, null, successCallback);
        } else {
            this.openComposeEmailDrawer(actionData, false, model);
        }
    }

    getRequestParams(usePMSETemplates, model, actionData) {
        var requestParams = {};

        if (usePMSETemplates) {
            requestParams = {
                targetModule: model.module,
                targetRecordId: model.id,
                targetTemplateId: actionData.emailTemplate
            };
        } else {
            requestParams = {
                templateId: actionData.emailTemplate,
                recordType: model.module,
                recordId: model.id
            };
        }

        return requestParams;
    }

    openComposeEmailDrawer(actionData, emailTemplateData, model) {
        var emails = model.get("email");
        var emailAddresses = _.pluck(emails, "email_address");

        if (_.isEmpty(emailAddresses)) {
            app.alert.show("no-email-addresses", {
                level: "info",
                messages: "This record has no email addresses!",
                autoClose: true
            });
        } else {
            SUGAR.customizationTools.deviceFeatures.sendEmail(emailAddresses, emailTemplateData);
        }

        app.controller.trigger("wRBActionFinished", this);
    }
}


module.exports.wRBComposeMail = wRBComposeMail;