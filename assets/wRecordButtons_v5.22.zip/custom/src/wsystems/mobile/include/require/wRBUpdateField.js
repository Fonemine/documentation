/*eslint-disable*/
class wRBUpdateField {
    constructor(manager) {
        this.manager = manager;
        this.updateFieldParams = {};
        app.controller.off("wRBActionsQueueFinished");
        app.controller.on("wRBActionsQueueFinished", this.handleQueueFinished.bind(this));
    }

    execute(actionData, model) {
        this.updateFieldParams = {};
        this.model = model;

        var fieldDefaultValue = actionData.defaultValue;
        var fieldDefaultValueText = actionData.defaultValueText;
        var isCalculated = actionData.calculatedField;
        var formulaFunction = actionData.formulaElement;
        formulaFunction = formulaFunction.replace(/'/g, "\"");
        var targetedField = actionData.fieldType;
        var module = actionData.moduleType;
        var uniqueIdentifier = App.utils.generateUUID();

        var accessModule = (module === "1currentModule") ? model.module : module;

        if (app.acl.hasAccess("edit", accessModule)) {
            this.updateFieldParams[uniqueIdentifier] = {
                calculated: isCalculated,
                formulaElement: formulaFunction,
                fieldToBeUpdated: targetedField,
                defaultValue: fieldDefaultValue,
                defaultValueText: fieldDefaultValueText,
                moduleType: module
            };

            if (formulaFunction.indexOf("(") > -1) {
                var params = {
                    formula: formulaFunction,
                    model: JSON.stringify(model),
                    targetField: targetedField
                };

                this.updateFieldParams[uniqueIdentifier].requestParams = params;
            }
            this.updateFieldAction(actionData, model);
        } else {
            this.manager.showNoAccessAlert();
        }
    }

    updateFieldAction(actionData, model) {
        var self = this;
        var notifyRelatedModuleUpdated = {
            success: function (updated) {
                app.controller.trigger("wRBActionFinished", self);
                if (updated) {
                    // show related module updated alert
                    app.alert.show("related-record-to-be-updated", {
                        level: "success",
                        messages: "Save successful on Related Record.",
                        autoClose: true
                    });
                } else {
                    // show related module updated alert
                    app.alert.show("nothing-to-be-updated", {
                        level: "warning",
                        messages: "Nothing to be updated on the Related Record. ",
                        autoClose: true
                    });
                }
            }
        };

        var currentModelNeedsSaving = false;
        var requestParameters = {};

        // check wether we need an api call to get the new value or we can calculate it here
        _.each(
            this.updateFieldParams,
            function goThroughParams(fieldParams, uniqueIdentifier) {
                if (fieldParams.fieldToBeUpdated != null) {
                    var canExecute = true;
                    var fieldName = fieldParams.fieldToBeUpdated;
                    if (
                        model &&
                        model.fields &&
                        model.fields[fieldName] &&
                        model.fields[fieldName].id_name
                    ) {
                        fieldName = model.fields[fieldName].id_name;
                    }

                    fieldParams.calculated = fieldParams.calculated === true ? true : false;
                    // in case we have request params then we need to store the params in order to make an api call
                    if (
                        fieldParams.requestParams &&
                        fieldParams.calculated === true &&
                        fieldParams.moduleType === "1currentModule"
                    ) {
                        requestParameters[uniqueIdentifier] = fieldParams.requestParams;
                    } else {
                        fieldParams.formulaElement = fieldParams.formulaElement.replace(/"/g, "");
                        var relatedModuleType = model.module;
                        var paramToGet = "id";

                        var relatedRecordId = model.get(paramToGet);

                        var fieldValue =
                            fieldParams.calculated === true ? fieldParams.formulaElement : fieldParams.defaultValue;

                        if (fieldParams.moduleType !== "1currentModule") {
                            relatedModuleType = fieldParams.moduleType.substr(0, fieldParams.moduleType.indexOf("__"));
                            var stringIndexOffset = 2;
                            paramToGet = fieldParams.moduleType.substr(
                                fieldParams.moduleType.indexOf("__") + stringIndexOffset,
                                fieldParams.moduleType.length
                            );
                            if (model.fields[paramToGet] && model.fields[paramToGet].type === "relate") {
                                paramToGet = model.fields[paramToGet].id_name;
                            }
                            if (model.get(paramToGet) == undefined) {
                                app.alert.show("alert_run_updating_fields" + App.utils.generateUUID(), {
                                    level: "warning",
                                    title: "Updating Fields",
                                    messages: "The following module: " + relatedModuleType + " is not available on mobile!",
                                    autoClose: true,
                                    autoCloseDelay: 3000
                                });
                                canExecute = false;
                            } else {
                                relatedRecordId = model.get(paramToGet);
                            }
                        } else if (fieldParams.calculated === false) {
                            if (typeof fieldValue === "object") {
                                // eslint-disable-next-line max-depth
                                if (model.fields[fieldName].type === "currency") {
                                    fieldValue[fieldName] = App.utils.unformatNumberString(
                                        fieldValue[fieldName],
                                        App.user.getPreference("number_grouping_separator"),
                                        App.user.getPreference("decimal_separator"),
                                        true
                                    );
                                }
                                model.set(fieldValue);
                            } else {
                                // eslint-disable-next-line max-depth
                                if (model.fields[fieldName] && model.fields[fieldName].type === "relate") {
                                    fieldName = model.fields[fieldName].id_name;
                                }

                                // fixed team_id bug
                                // eslint-disable-next-line max-depth
                                if (fieldName === "team_id") {
                                    fieldName = "team_name";
                                    fieldValue = [{
                                        id: fieldValue,
                                        name: fieldParams.fieldValueText,
                                        primary: true,
                                        selected: false
                                    }];
                                }
                                if (fieldName === "deleted" && fieldValue == true) {
                                    this.destroyModel = true;
                                } else {
                                    model.set(fieldName, fieldValue);
                                }
                            }

                            currentModelNeedsSaving = true;
                        }

                        var apiParams = {
                            module: relatedModuleType,
                            recordId: relatedRecordId,
                            field: fieldName,
                            value: fieldValue
                        };

                        if (fieldParams.calculated === true && canExecute) {
                            apiParams.formula = apiParams.value;
                            // if we have custom fields in the formula we need to make the api call
                            if (fieldParams.formulaElement.indexOf("$") > -1) {
                                if (fieldParams.moduleType === "1currentModule") {
                                    requestParameters[uniqueIdentifier] = {
                                        formula: fieldParams.formulaElement,
                                        targetField: fieldName,
                                        recordId: relatedRecordId,
                                        moduleType: relatedModuleType
                                    };
                                } else {
                                    fieldValue = model.get(fieldName);
                                    apiParams.value = fieldValue;
                                    apiParams.formula = fieldParams.formulaElement;

                                    app.api.call(
                                        "create",
                                        app.api.buildURL("UpdateRelatedField"),
                                        apiParams,
                                        null,
                                        notifyRelatedModuleUpdated
                                    );
                                }
                            } else if (fieldParams.moduleType !== "1currentModule") {
                                app.api.call(
                                    "create",
                                    app.api.buildURL("UpdateRelatedField"),
                                    apiParams,
                                    null,
                                    notifyRelatedModuleUpdated
                                );
                            }
                        } else if (fieldParams.moduleType !== "1currentModule" && canExecute) {
                            if (fieldParams.calculated !== true) {
                                // getting fieldMetadata
                                var fieldsMetadata = app.metadata.getModule(apiParams.module).fields;
                                // handle fields that required expressionValue formatting
                                var targetFieldData = fieldsMetadata[apiParams.field];

                                if (targetFieldData && targetFieldData.type === "datetimecombo") {
                                    // handle datetime field
                                    apiParams.value = App.date(apiParams.value).formatUser();
                                }
                            }

                            app.api.call(
                                "create",
                                app.api.buildURL("UpdateRelatedField"),
                                apiParams,
                                null,
                                notifyRelatedModuleUpdated
                            );
                        }
                    }
                }
            }.bind(this)
        );
        // build the request params
        if (Object.keys(requestParameters).length > 0) {
            var evaluateExpressionsParams = {
                fieldsToBeUpdated: {},
                recordType: model.module,
                recordId: model.get("id")
            };

            _.each(requestParameters, function buildFieldsToBeUpdate(toBeUpdatedFieldData, toBeUpdatedActionId) {
                evaluateExpressionsParams.fieldsToBeUpdated[toBeUpdatedFieldData.targetField] = {
                    targetField: toBeUpdatedFieldData.targetField,
                    formula: toBeUpdatedFieldData.formula
                };
            });

            app.alert.show("alert_run_updating_fields" + App.utils.generateUUID(), {
                level: "info",
                title: "Updating Fields",
                messages: "Updating Fields",
                autoClose: true,
                autoCloseDelay: 1000
            });
            App.api.call(
                "create",
                app.api.buildURL("EvaluateExpressionsMobile/evaluate_expression_mobile"),
                evaluateExpressionsParams,
                null, {
                    success: function (expressionData) {
                        if (expressionData["deleted"] && expressionData["deleted"] == true) {
                            self.destroyModel = true;
                        } else {
                            model.set(expressionData);
                        }

                        model.save(null, {
                            success: function () {
                                app.controller.trigger("wRBActionFinished", self);
                            },

                            error: function () {
                                app.controller.trigger("wRBActionFinished", self);
                            },
                            fields: Object.keys(model.attributes)
                        });
                    }
                }
            );
        } else if (currentModelNeedsSaving) {
            model.save(null, {
                success: function () {
                    app.controller.trigger("wRBActionFinished", self);
                },

                error: function () {
                    app.controller.trigger("wRBActionFinished", self);
                },
                fields: Object.keys(model.attributes)
            });
        }
    }

    handleQueueFinished() {
        app.controller.off("wRBActionsQueueFinished");
        if (this.destroyModel === true) {
            this.model.destroy();
        }
    }
}

module.exports.wRBUpdateField = wRBUpdateField;