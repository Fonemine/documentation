<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
$manifest = array (
  'acceptable_sugar_versions' =>  
  array (
    0 => '7.*',
    1 => '8.*',
    2 => '9.*',
    3 => '10.*'
  ),
  'acceptable_sugar_flavors' =>  
  array (

  ),
  'readme' =>  'README.txt',
  'key' =>  'WSYS',
  'author' =>  'Richard Tinca, Mirel Ivan',
  'description' =>  'Customizable buttons that can control various actions.',
  'icon' =>  '',
  'is_uninstallable' =>  true,
  'name' =>  'wRecordButtons',
  'published_date' =>  '2020-09-25 15:11:36',
  'type' =>  'module',
  'version' =>  '5.22',
  'remove_tables' =>  'prompt'
);
$installdefs = array (
  'id' =>  'wRecordButtons',
  'copy' =>  
  array (
    0 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/FixDurationFieldOnWReportButton.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/FixDurationFieldOnWReportButton.php'
    ),
    1 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wHeaderRecordButtons.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wHeaderRecordButtons.php'
    ),
    2 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wRecordButtonComposeEmail.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wRecordButtonComposeEmail.php'
    ),
    3 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wRecordButtonsConvert.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wRecordButtonsConvert.php'
    ),
    4 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wRecordButtonsCreate.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wRecordButtonsCreate.php'
    ),
    5 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wRecordButtonsList.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wRecordButtonsList.php'
    ),
    6 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/Language/en_us.wRecordButtonLocalization.php',
      'to' =>  'custom/Extension/application/Ext/Language/en_us.wRecordButtonLocalization.php'
    ),
    7 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/DynamicFields/Ext/Language/en_us.helpForButtonSetParameterField.php',
      'to' =>  'custom/Extension/modules/DynamicFields/Ext/Language/en_us.helpForButtonSetParameterField.php'
    ),
    8 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/ModuleBuilder/Ext/Language/en_us.ButtonSet.php',
      'to' =>  'custom/Extension/modules/ModuleBuilder/Ext/Language/en_us.ButtonSet.php'
    ),
    9 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/CheckScheduleJobsStatusApi.php',
      'to' =>  'custom/clients/base/api/CheckScheduleJobsStatusApi.php'
    ),
    10 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/CreateDocumentRevisionApi.php',
      'to' =>  'custom/clients/base/api/CreateDocumentRevisionApi.php'
    ),
    11 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/EnhancedEmailTemplatesApi.php',
      'to' =>  'custom/clients/base/api/EnhancedEmailTemplatesApi.php'
    ),
    12 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/EvaluateExpressionsApi.php',
      'to' =>  'custom/clients/base/api/EvaluateExpressionsApi.php'
    ),
    13 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/GetEmailTemplateDataApi.php',
      'to' =>  'custom/clients/base/api/GetEmailTemplateDataApi.php'
    ),
    14 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/RunScheduleJobApi.php',
      'to' =>  'custom/clients/base/api/RunScheduleJobApi.php'
    ),
    15 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/SaveCustomButtonLabelsApi.php',
      'to' =>  'custom/clients/base/api/SaveCustomButtonLabelsApi.php'
    ),
    16 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/UpdateRelatedFieldApi.php',
      'to' =>  'custom/clients/base/api/UpdateRelatedFieldApi.php'
    ),
    17 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/buttonset/buttonset.js',
      'to' =>  'custom/clients/base/fields/buttonset/buttonset.js'
    ),
    18 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/buttonset/detail.hbs',
      'to' =>  'custom/clients/base/fields/buttonset/detail.hbs'
    ),
    19 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/buttonset/edit.hbs',
      'to' =>  'custom/clients/base/fields/buttonset/edit.hbs'
    ),
    20 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/buttonset/header.hbs',
      'to' =>  'custom/clients/base/fields/buttonset/header.hbs'
    ),
    21 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/buttonset/list.hbs',
      'to' =>  'custom/clients/base/fields/buttonset/list.hbs'
    ),
    22 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wRecord-button-create-document/wRecord-button-create-document.js',
      'to' =>  'custom/clients/base/layouts/wRecord-button-create-document/wRecord-button-create-document.js'
    ),
    23 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wRecord-button-create-document/wRecord-button-create-document.php',
      'to' =>  'custom/clients/base/layouts/wRecord-button-create-document/wRecord-button-create-document.php'
    ),
    24 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-customCreate/wrecord-button-customCreate.js',
      'to' =>  'custom/clients/base/layouts/wrecord-button-customCreate/wrecord-button-customCreate.js'
    ),
    25 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-customCreate/wrecord-button-customCreate.php',
      'to' =>  'custom/clients/base/layouts/wrecord-button-customCreate/wrecord-button-customCreate.php'
    ),
    26 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-preset-document-record/wrecord-button-preset-document-record.js',
      'to' =>  'custom/clients/base/layouts/wrecord-button-preset-document-record/wrecord-button-preset-document-record.js'
    ),
    27 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-preset-document-record/wrecord-button-preset-document-record.php',
      'to' =>  'custom/clients/base/layouts/wrecord-button-preset-document-record/wrecord-button-preset-document-record.php'
    ),
    28 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.hbs',
      'to' =>  'custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.hbs'
    ),
    29 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.js',
      'to' =>  'custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.js'
    ),
    30 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.php',
      'to' =>  'custom/clients/base/layouts/wrecord-button-preview-container/wrecord-button-preview-container.php'
    ),
    31 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.hbs',
      'to' =>  'custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.hbs'
    ),
    32 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.js',
      'to' =>  'custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.js'
    ),
    33 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.php',
      'to' =>  'custom/clients/base/layouts/wrecord-button-tips/wrecord-button-tips.php'
    ),
    34 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.hbs',
      'to' =>  'custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.hbs'
    ),
    35 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.js',
      'to' =>  'custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.js'
    ),
    36 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.php',
      'to' =>  'custom/clients/base/layouts/wrecord-buttons-actions-container/wrecord-buttons-actions-container.php'
    ),
    37 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.hbs',
      'to' =>  'custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.hbs'
    ),
    38 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.js',
      'to' =>  'custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.js'
    ),
    39 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.php',
      'to' =>  'custom/clients/base/layouts/wrecord-main-panel/wrecord-main-panel.php'
    ),
    40 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-settings/wrecord-settings.hbs',
      'to' =>  'custom/clients/base/layouts/wrecord-settings/wrecord-settings.hbs'
    ),
    41 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-settings/wrecord-settings.js',
      'to' =>  'custom/clients/base/layouts/wrecord-settings/wrecord-settings.js'
    ),
    42 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/wrecord-settings/wrecord-settings.php',
      'to' =>  'custom/clients/base/layouts/wrecord-settings/wrecord-settings.php'
    ),
    43 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/preview-header/preview-header.hbs',
      'to' =>  'custom/clients/base/views/preview-header/preview-header.hbs'
    ),
    44 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wRecord-button-create-document/wRecord-button-create-document.js',
      'to' =>  'custom/clients/base/views/wRecord-button-create-document/wRecord-button-create-document.js'
    ),
    45 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wRecord-button-create-document/wRecord-button-create-document.php',
      'to' =>  'custom/clients/base/views/wRecord-button-create-document/wRecord-button-create-document.php'
    ),
    46 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button/wrecord-button.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button/wrecord-button.hbs'
    ),
    47 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button/wrecord-button.js',
      'to' =>  'custom/clients/base/views/wrecord-button/wrecord-button.js'
    ),
    48 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-action/wrecord-button-action.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-action/wrecord-button-action.hbs'
    ),
    49 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-action/wrecord-button-action.js',
      'to' =>  'custom/clients/base/views/wrecord-button-action/wrecord-button-action.js'
    ),
    50 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-assign-record/wrecord-button-assign-record.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-assign-record/wrecord-button-assign-record.hbs'
    ),
    51 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-assign-record/wrecord-button-assign-record.js',
      'to' =>  'custom/clients/base/views/wrecord-button-assign-record/wrecord-button-assign-record.js'
    ),
    52 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-assignRecord-tip/wrecord-button-assignRecord-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-assignRecord-tip/wrecord-button-assignRecord-tip.hbs'
    ),
    53 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-assignRecord-tip/wrecord-button-assignRecord-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-assignRecord-tip/wrecord-button-assignRecord-tip.js'
    ),
    54 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-compose-mail/wrecord-button-compose-mail.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-compose-mail/wrecord-button-compose-mail.hbs'
    ),
    55 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-compose-mail/wrecord-button-compose-mail.js',
      'to' =>  'custom/clients/base/views/wrecord-button-compose-mail/wrecord-button-compose-mail.js'
    ),
    56 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-composeMail-tip/wrecord-button-composeMail-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-composeMail-tip/wrecord-button-composeMail-tip.hbs'
    ),
    57 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-composeMail-tip/wrecord-button-composeMail-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-composeMail-tip/wrecord-button-composeMail-tip.js'
    ),
    58 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-convertLead-tip/wrecord-button-convertLead-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-convertLead-tip/wrecord-button-convertLead-tip.hbs'
    ),
    59 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-convertLead-tip/wrecord-button-convertLead-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-convertLead-tip/wrecord-button-convertLead-tip.js'
    ),
    60 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-create-mergeDocument/wrecord-button-create-mergeDocument.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-create-mergeDocument/wrecord-button-create-mergeDocument.hbs'
    ),
    61 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-create-mergeDocument/wrecord-button-create-mergeDocument.js',
      'to' =>  'custom/clients/base/views/wrecord-button-create-mergeDocument/wrecord-button-create-mergeDocument.js'
    ),
    62 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-create-record/wrecord-button-create-record.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-create-record/wrecord-button-create-record.hbs'
    ),
    63 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-create-record/wrecord-button-create-record.js',
      'to' =>  'custom/clients/base/views/wrecord-button-create-record/wrecord-button-create-record.js'
    ),
    64 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-createRecord-tip/wrecord-button-createRecord-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-createRecord-tip/wrecord-button-createRecord-tip.hbs'
    ),
    65 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-createRecord-tip/wrecord-button-createRecord-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-createRecord-tip/wrecord-button-createRecord-tip.js'
    ),
    66 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-customCreate-view/wrecord-button-customCreate-view.js',
      'to' =>  'custom/clients/base/views/wrecord-button-customCreate-view/wrecord-button-customCreate-view.js'
    ),
    67 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-dependency-formula/wrecord-button-dependency-formula.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-dependency-formula/wrecord-button-dependency-formula.hbs'
    ),
    68 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-dependency-formula/wrecord-button-dependency-formula.js',
      'to' =>  'custom/clients/base/views/wrecord-button-dependency-formula/wrecord-button-dependency-formula.js'
    ),
    69 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-directions-tip/wrecord-button-directions-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-directions-tip/wrecord-button-directions-tip.hbs'
    ),
    70 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-directions-tip/wrecord-button-directions-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-directions-tip/wrecord-button-directions-tip.js'
    ),
    71 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-dropdown-preview/wrecord-button-dropdown-preview.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-dropdown-preview/wrecord-button-dropdown-preview.hbs'
    ),
    72 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-dropdown-preview/wrecord-button-dropdown-preview.js',
      'to' =>  'custom/clients/base/views/wrecord-button-dropdown-preview/wrecord-button-dropdown-preview.js'
    ),
    73 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-edit-record/wrecord-button-edit-record.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-edit-record/wrecord-button-edit-record.hbs'
    ),
    74 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-edit-record/wrecord-button-edit-record.js',
      'to' =>  'custom/clients/base/views/wrecord-button-edit-record/wrecord-button-edit-record.js'
    ),
    75 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-editRecord-tip/wrecord-button-editRecord-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-editRecord-tip/wrecord-button-editRecord-tip.hbs'
    ),
    76 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-editRecord-tip/wrecord-button-editRecord-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-editRecord-tip/wrecord-button-editRecord-tip.js'
    ),
    77 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-handleRoute-tip/wrecord-button-handleRoute-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-handleRoute-tip/wrecord-button-handleRoute-tip.hbs'
    ),
    78 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-handleRoute-tip/wrecord-button-handleRoute-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-handleRoute-tip/wrecord-button-handleRoute-tip.js'
    ),
    79 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-map-tip/wrecord-button-map-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-map-tip/wrecord-button-map-tip.hbs'
    ),
    80 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-map-tip/wrecord-button-map-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-map-tip/wrecord-button-map-tip.js'
    ),
    81 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-mergeDocument-tip/wrecord-button-mergeDocument-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-mergeDocument-tip/wrecord-button-mergeDocument-tip.hbs'
    ),
    82 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-mergeDocument-tip/wrecord-button-mergeDocument-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-mergeDocument-tip/wrecord-button-mergeDocument-tip.js'
    ),
    83 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-nearby-tip/wrecord-button-nearby-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-nearby-tip/wrecord-button-nearby-tip.hbs'
    ),
    84 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-nearby-tip/wrecord-button-nearby-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-nearby-tip/wrecord-button-nearby-tip.js'
    ),
    85 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-populate-from-parent/wrecord-button-populate-from-parent.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-populate-from-parent/wrecord-button-populate-from-parent.hbs'
    ),
    86 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-populate-from-parent/wrecord-button-populate-from-parent.js',
      'to' =>  'custom/clients/base/views/wrecord-button-populate-from-parent/wrecord-button-populate-from-parent.js'
    ),
    87 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-preset-document-record/wrecord-button-preset-document-record.js',
      'to' =>  'custom/clients/base/views/wrecord-button-preset-document-record/wrecord-button-preset-document-record.js'
    ),
    88 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-preset-document-record/wrecord-button-preset-document-record.php',
      'to' =>  'custom/clients/base/views/wrecord-button-preset-document-record/wrecord-button-preset-document-record.php'
    ),
    89 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-job/wrecord-button-run-job.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-run-job/wrecord-button-run-job.hbs'
    ),
    90 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-job/wrecord-button-run-job.js',
      'to' =>  'custom/clients/base/views/wrecord-button-run-job/wrecord-button-run-job.js'
    ),
    91 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-report/wrecord-button-run-report.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-run-report/wrecord-button-run-report.hbs'
    ),
    92 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-report/wrecord-button-run-report.js',
      'to' =>  'custom/clients/base/views/wrecord-button-run-report/wrecord-button-run-report.js'
    ),
    93 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-url/wrecord-button-run-url.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-run-url/wrecord-button-run-url.hbs'
    ),
    94 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-run-url/wrecord-button-run-url.js',
      'to' =>  'custom/clients/base/views/wrecord-button-run-url/wrecord-button-run-url.js'
    ),
    95 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runJob-tip/wrecord-button-runJob-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-runJob-tip/wrecord-button-runJob-tip.hbs'
    ),
    96 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runJob-tip/wrecord-button-runJob-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-runJob-tip/wrecord-button-runJob-tip.js'
    ),
    97 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runReport-tip/wrecord-button-runReport-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-runReport-tip/wrecord-button-runReport-tip.hbs'
    ),
    98 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runReport-tip/wrecord-button-runReport-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-runReport-tip/wrecord-button-runReport-tip.js'
    ),
    99 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runUrl-tip/wrecord-button-runUrl-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-runUrl-tip/wrecord-button-runUrl-tip.hbs'
    ),
    100 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-runUrl-tip/wrecord-button-runUrl-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-runUrl-tip/wrecord-button-runUrl-tip.js'
    ),
    101 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-save-record/wrecord-button-save-record.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-save-record/wrecord-button-save-record.hbs'
    ),
    102 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-save-record/wrecord-button-save-record.js',
      'to' =>  'custom/clients/base/views/wrecord-button-save-record/wrecord-button-save-record.js'
    ),
    103 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-saveRecord-tip/wrecord-button-saveRecord-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-saveRecord-tip/wrecord-button-saveRecord-tip.hbs'
    ),
    104 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-saveRecord-tip/wrecord-button-saveRecord-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-saveRecord-tip/wrecord-button-saveRecord-tip.js'
    ),
    105 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-tab-management/wrecord-button-tab-management.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-tab-management/wrecord-button-tab-management.hbs'
    ),
    106 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-tab-management/wrecord-button-tab-management.js',
      'to' =>  'custom/clients/base/views/wrecord-button-tab-management/wrecord-button-tab-management.js'
    ),
    107 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-tabsManagement-tip/wrecord-button-tabsManagement-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-tabsManagement-tip/wrecord-button-tabsManagement-tip.hbs'
    ),
    108 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-tabsManagement-tip/wrecord-button-tabsManagement-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-tabsManagement-tip/wrecord-button-tabsManagement-tip.js'
    ),
    109 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-update-field/wrecord-button-update-field.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-update-field/wrecord-button-update-field.hbs'
    ),
    110 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-update-field/wrecord-button-update-field.js',
      'to' =>  'custom/clients/base/views/wrecord-button-update-field/wrecord-button-update-field.js'
    ),
    111 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-updateField-tip/wrecord-button-updateField-tip.hbs',
      'to' =>  'custom/clients/base/views/wrecord-button-updateField-tip/wrecord-button-updateField-tip.hbs'
    ),
    112 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-button-updateField-tip/wrecord-button-updateField-tip.js',
      'to' =>  'custom/clients/base/views/wrecord-button-updateField-tip/wrecord-button-updateField-tip.js'
    ),
    113 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-buttons-container/wrecord-buttons-container.hbs',
      'to' =>  'custom/clients/base/views/wrecord-buttons-container/wrecord-buttons-container.hbs'
    ),
    114 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-buttons-container/wrecord-buttons-container.js',
      'to' =>  'custom/clients/base/views/wrecord-buttons-container/wrecord-buttons-container.js'
    ),
    115 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-buttons-preview/wrecord-buttons-preview.hbs',
      'to' =>  'custom/clients/base/views/wrecord-buttons-preview/wrecord-buttons-preview.hbs'
    ),
    116 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-buttons-preview/wrecord-buttons-preview.js',
      'to' =>  'custom/clients/base/views/wrecord-buttons-preview/wrecord-buttons-preview.js'
    ),
    117 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-headerpane/wrecord-headerpane.hbs',
      'to' =>  'custom/clients/base/views/wrecord-headerpane/wrecord-headerpane.hbs'
    ),
    118 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/wrecord-headerpane/wrecord-headerpane.js',
      'to' =>  'custom/clients/base/views/wrecord-headerpane/wrecord-headerpane.js'
    ),
    119 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/buttonset.js',
      'to' =>  'custom/clients/mobile/fields/buttonset/buttonset.js'
    ),
    120 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/detail.hbs',
      'to' =>  'custom/clients/mobile/fields/buttonset/detail.hbs'
    ),
    121 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/edit.hbs',
      'to' =>  'custom/clients/mobile/fields/buttonset/edit.hbs'
    ),
    122 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/header.hbs',
      'to' =>  'custom/clients/mobile/fields/buttonset/header.hbs'
    ),
    123 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/list.hbs',
      'to' =>  'custom/clients/mobile/fields/buttonset/list.hbs'
    ),
    124 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/fields/buttonset/readonly.hbs',
      'to' =>  'custom/clients/mobile/fields/buttonset/readonly.hbs'
    ),
    125 =>     array (
      'from' =>  '<basepath>/custom/include/generic/SugarWidgets/SugarWidgetFieldbuttonset.php',
      'to' =>  'custom/include/generic/SugarWidgets/SugarWidgetFieldbuttonset.php'
    ),
    126 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/FixDurationFieldOnWReportButton.js',
      'to' =>  'custom/include/javascript/FixDurationFieldOnWReportButton.js'
    ),
    127 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/addProperFieldHelper.js',
      'to' =>  'custom/include/javascript/addProperFieldHelper.js'
    ),
    128 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/wHeaderRecordButtons.js',
      'to' =>  'custom/include/javascript/wHeaderRecordButtons.js'
    ),
    129 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/wRecordButtonComposeEmail.js',
      'to' =>  'custom/include/javascript/wRecordButtonComposeEmail.js'
    ),
    130 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/wRecordButtonsConvert.js',
      'to' =>  'custom/include/javascript/wRecordButtonsConvert.js'
    ),
    131 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/wRecordButtonsCreate.js',
      'to' =>  'custom/include/javascript/wRecordButtonsCreate.js'
    ),
    132 =>     array (
      'from' =>  '<basepath>/custom/include/javascript/wRecordButtonsList.js',
      'to' =>  'custom/include/javascript/wRecordButtonsList.js'
    ),
    133 =>     array (
      'from' =>  '<basepath>/custom/modules/DynamicFields/templates/Fields/Forms/buttonset.php',
      'to' =>  'custom/modules/DynamicFields/templates/Fields/Forms/buttonset.php'
    ),
    134 =>     array (
      'from' =>  '<basepath>/custom/modules/DynamicFields/templates/Fields/Forms/buttonset.tpl',
      'to' =>  'custom/modules/DynamicFields/templates/Fields/Forms/buttonset.tpl'
    ),
    135 =>     array (
      'from' =>  '<basepath>/custom/modules/DynamicFields/templates/Fields/TemplateButtonset.php',
      'to' =>  'custom/modules/DynamicFields/templates/Fields/TemplateButtonset.php'
    ),
    136 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBActionsManager.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBActionsManager.js'
    ),
    137 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBAssignRecord.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBAssignRecord.js'
    ),
    138 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBComposeMail.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBComposeMail.js'
    ),
    139 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBConvertLead.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBConvertLead.js'
    ),
    140 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBCreateRecord.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBCreateRecord.js'
    ),
    141 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBDirections.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBDirections.js'
    ),
    142 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBDoNothing.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBDoNothing.js'
    ),
    143 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBEditRecord.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBEditRecord.js'
    ),
    144 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBHandleRoute.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBHandleRoute.js'
    ),
    145 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBMap.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBMap.js'
    ),
    146 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBMergeDocument.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBMergeDocument.js'
    ),
    147 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBNearby.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBNearby.js'
    ),
    148 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBRunJob.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBRunJob.js'
    ),
    149 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBRunUrl.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBRunUrl.js'
    ),
    150 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/require/wRBUpdateField.js',
      'to' =>  'custom/src/wsystems/mobile/include/require/wRBUpdateField.js'
    )
  )
);